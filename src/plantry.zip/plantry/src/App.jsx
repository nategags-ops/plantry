import { useState, useMemo, useRef, useCallback, useEffect } from 'react'
import { useSharedState } from './useSharedState.js'

const RECIPES = [
  { id:1, emoji:"🐟", title:"Honey Garlic Salmon", category:"Seafood", tags:["High Protein","Gluten-Free","Quick"], prep:"10 min", cook:"20 min", servings:5, calories:420, ingredients:["5 salmon fillets (6 oz each)","3 tbsp honey","4 cloves garlic, minced","3 tbsp soy sauce (low sodium)","1 tbsp butter","2 cups jasmine rice (dry)","1 lb green beans","1 tbsp olive oil","Salt & pepper","Garlic powder"], steps:["Preheat oven to 400°F. Line baking sheets with foil.","Cook jasmine rice per package directions.","Simmer butter, honey, garlic, and soy sauce 2–3 min until slightly thickened.","Pat salmon dry, season with salt & pepper. Glaze with sauce.","Bake 12–15 min until salmon flakes easily.","Toss green beans with olive oil and garlic powder. Roast 12–15 min alongside.","Cool fully, portion into containers with rice."], storage:"4 days refrigerated.", grocery:{ Protein:["5 salmon fillets (6 oz)"], Produce:["1 lb green beans","4 cloves garlic"], Grains:["2 cups jasmine rice"], Pantry:["3 tbsp honey","3 tbsp soy sauce","1 tbsp butter","1 tbsp olive oil","Salt & pepper","Garlic powder"] } },
  { id:2, emoji:"🌯", title:"Chicken Burrito Bowls", category:"Chicken", tags:["High Protein","Meal Prep","Family Favorite"], prep:"20 min", cook:"25 min", servings:5, calories:510, ingredients:["2 lbs chicken breasts","2 tbsp olive oil","1 tsp cumin","1 tsp chili powder","1 tsp garlic powder","1/2 tsp smoked paprika","2 cups white rice (dry)","Juice of 2 limes","1/4 cup cilantro","1 can black beans (15 oz)","1 cup corn","1 can diced green chilis (4 oz)","Salt & pepper"], steps:["Preheat oven to 425°F.","Coat chicken with olive oil and all spices. Bake 20–22 min until 165°F. Rest and dice.","Cook rice. Stir in lime juice, cilantro, and salt.","Warm black beans with a pinch of cumin. Mix green chilis into rice.","Layer containers: rice, chicken, beans, corn, chilis."], storage:"5 days. Add avocado fresh.", grocery:{ Protein:["2 lbs chicken breasts"], Produce:["2 limes","1/4 cup cilantro"], Grains:["2 cups white rice"], Canned:["1 can black beans","1 cup corn","1 can green chilis"], Pantry:["Olive oil","Cumin","Chili powder","Garlic powder","Smoked paprika","Salt & pepper"] } },
  { id:3, emoji:"🥩", title:"Beef & Broccoli Stir Fry", category:"Beef", tags:["High Protein","Asian-Inspired","Meal Prep"], prep:"15 min", cook:"20 min", servings:5, calories:480, ingredients:["1.5 lbs flank steak, thin sliced","4 cups broccoli florets","2 tbsp sesame oil","1 tbsp vegetable oil","4 cloves garlic, minced","1 tbsp fresh ginger, grated","2 cups brown rice (dry)","1/3 cup soy sauce","2 tbsp oyster sauce","1 tbsp brown sugar","1 tbsp cornstarch","1/2 cup beef broth"], steps:["Cook rice.","Whisk soy sauce, oyster sauce, brown sugar, cornstarch, and broth.","Slice steak thin. Sear in batches, 1–2 min/side. Set aside.","Stir fry broccoli 3–4 min. Add garlic and ginger 30 sec.","Return beef. Pour sauce. Toss 1–2 min.","Cool, portion over rice."], storage:"5 days refrigerated.", grocery:{ Protein:["1.5 lbs flank steak"], Produce:["4 cups broccoli","4 cloves garlic","Fresh ginger"], Grains:["2 cups brown rice"], Sauces:["Soy sauce","Oyster sauce","Sesame oil","Vegetable oil"], Pantry:["Brown sugar","Cornstarch","Beef broth"] } },
  { id:4, emoji:"🍗", title:"Lemon Herb Chicken Thighs", category:"Chicken", tags:["High Protein","Gluten-Free","Low Calorie"], prep:"10 min", cook:"35 min", servings:5, calories:390, ingredients:["10 bone-in chicken thighs","3 tbsp olive oil","Zest & juice of 2 lemons","4 cloves garlic, minced","1 tsp dried oregano","1 tsp thyme","1 tsp rosemary","Salt & pepper","2 cups quinoa (dry)","1 lb asparagus"], steps:["Preheat oven to 425°F.","Marinate chicken with olive oil, lemon, garlic, herbs, salt, pepper 10 min.","Roast 30–35 min until golden and 165°F.","Cook quinoa. Trim asparagus, toss with olive oil and salt.","Roast asparagus last 12 min.","Portion into containers."], storage:"4 days refrigerated.", grocery:{ Protein:["10 bone-in chicken thighs"], Produce:["2 lemons","4 cloves garlic","1 lb asparagus"], Grains:["2 cups quinoa"], Pantry:["Olive oil","Oregano","Thyme","Rosemary","Salt & pepper"] } },
  { id:5, emoji:"🍲", title:"Turkey & White Bean Chili", category:"Soups & Stews", tags:["High Protein","Low Calorie","Meal Prep"], prep:"15 min", cook:"35 min", servings:5, calories:360, ingredients:["1.5 lbs ground turkey","1 onion, diced","3 cloves garlic, minced","1 tbsp olive oil","2 cans white beans (15 oz)","1 can diced tomatoes (14 oz)","2 cups chicken broth","1 tsp cumin","1 tsp chili powder","1/2 tsp smoked paprika","Salt & pepper","1 cup frozen corn","2 tbsp lime juice"], steps:["Sauté onion and garlic 3 min.","Brown turkey 7 min.","Add beans, tomatoes, broth, and spices.","Simmer 20 min. Stir in corn and lime juice.","Season to taste. Cool and portion."], storage:"5 days. Freezes 3 months.", grocery:{ Protein:["1.5 lbs ground turkey"], Produce:["1 onion","3 cloves garlic","Lime"], Canned:["2 cans white beans","1 can diced tomatoes"], Pantry:["Olive oil","Cumin","Chili powder","Smoked paprika","Chicken broth","Frozen corn","Salt & pepper"] } },
  { id:6, emoji:"🥗", title:"Greek Quinoa Salad", category:"Salads", tags:["Vegetarian","Mediterranean","Low Calorie"], prep:"15 min", cook:"15 min", servings:5, calories:320, ingredients:["2 cups quinoa (dry)","1 cucumber, diced","1 cup cherry tomatoes, halved","1/2 red onion, diced","1 cup Kalamata olives","4 oz feta cheese, crumbled","3 tbsp olive oil","2 tbsp red wine vinegar","1 tsp dried oregano","Salt & pepper","2 tbsp fresh parsley"], steps:["Cook quinoa. Cool.","Dice cucumber, halve tomatoes, dice onion.","Whisk olive oil, vinegar, oregano, salt, pepper.","Toss quinoa with vegetables, olives, and feta.","Add dressing. Portion."], storage:"4 days. Dress before eating.", grocery:{ Produce:["1 cucumber","Cherry tomatoes","1/2 red onion","Fresh parsley"], Grains:["2 cups quinoa"], Dairy:["4 oz feta cheese"], Pantry:["Olive oil","Red wine vinegar","Oregano","Salt & pepper","Kalamata olives"] } },
  { id:7, emoji:"🍜", title:"Chicken Teriyaki Bowl", category:"Bowls", tags:["High Protein","Asian-Inspired","Meal Prep"], prep:"15 min", cook:"20 min", servings:5, calories:470, ingredients:["2 lbs chicken breast, cubed","2 cups jasmine rice (dry)","2 cups broccoli florets","1 cup edamame (shelled)","1/4 cup soy sauce","2 tbsp honey","1 tbsp rice vinegar","1 tsp sesame oil","2 cloves garlic, minced","1 tsp cornstarch","1 tbsp vegetable oil","Sesame seeds","Green onions"], steps:["Cook rice.","Whisk soy sauce, honey, rice vinegar, sesame oil, garlic, and cornstarch.","Sear chicken 5–6 min.","Add sauce. Cook 2 min until glossy.","Steam broccoli and edamame 4 min.","Layer bowls. Top with sesame seeds and green onions."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["2 cups broccoli","Green onions","2 cloves garlic"], Grains:["2 cups jasmine rice"], Pantry:["Soy sauce","Honey","Rice vinegar","Sesame oil","Cornstarch","Vegetable oil","Sesame seeds","Edamame"] } },
  { id:8, emoji:"🥦", title:"Vegetable Fried Rice", category:"Vegetarian", tags:["Vegetarian","Quick","Low Calorie"], prep:"10 min", cook:"15 min", servings:5, calories:340, ingredients:["4 cups cooked white rice (day-old)","3 eggs, beaten","1 cup frozen peas","1 cup frozen corn","1 cup carrots, diced","1/2 cup edamame","3 cloves garlic, minced","2 tbsp soy sauce","1 tbsp sesame oil","1 tbsp vegetable oil","Salt & pepper","Green onions"], steps:["Heat vegetable oil in large wok over high heat.","Scramble eggs, push aside. Add garlic 30 sec.","Add vegetables, stir fry 3–4 min.","Add rice. Stir fry 3 min.","Add soy sauce and sesame oil. Toss.","Garnish with green onions."], storage:"4 days refrigerated.", grocery:{ Produce:["Carrots","Green onions","3 cloves garlic"], Dairy:["3 eggs"], Grains:["4 cups white rice"], Pantry:["Frozen peas","Frozen corn","Edamame","Soy sauce","Sesame oil","Vegetable oil","Salt & pepper"] } },
  { id:9, emoji:"🫘", title:"Black Bean Sweet Potato Tacos", category:"Vegetarian", tags:["Vegan","High Fiber","Mexican"], prep:"15 min", cook:"25 min", servings:5, calories:380, ingredients:["2 large sweet potatoes, cubed","2 cans black beans (15 oz), drained","1 tbsp olive oil","1 tsp cumin","1 tsp chili powder","1/2 tsp smoked paprika","10 corn tortillas","1 cup salsa","1 avocado, sliced","2 cups shredded cabbage","Lime wedges","Fresh cilantro"], steps:["Preheat oven to 400°F.","Toss sweet potato with olive oil and spices. Roast 20–25 min.","Warm black beans with cumin.","Warm tortillas.","Assemble tacos. Pack components separately."], storage:"Components 4 days. Assemble fresh.", grocery:{ Produce:["2 sweet potatoes","1 avocado","2 cups cabbage","Fresh cilantro","Lime"], Canned:["2 cans black beans","1 cup salsa"], Pantry:["Olive oil","Cumin","Chili powder","Smoked paprika","10 corn tortillas"] } },
  { id:10, emoji:"🍝", title:"Turkey Bolognese Zucchini Noodles", category:"Turkey", tags:["Low Carb","High Protein","Italian"], prep:"15 min", cook:"30 min", servings:5, calories:350, ingredients:["1.5 lbs ground turkey","4 zucchini, spiralized","1 onion, diced","4 cloves garlic, minced","1 can crushed tomatoes (28 oz)","2 tbsp tomato paste","1/2 cup chicken broth","1 tbsp olive oil","1 tsp dried basil","1 tsp oregano","Salt & pepper","Parmesan for serving"], steps:["Sauté onion in olive oil 3 min. Add garlic.","Brown turkey 7–8 min.","Add tomato paste 2 min.","Add tomatoes, broth, basil, oregano, salt, pepper. Simmer 20 min.","Spiralize zucchini. Salt, rest 10 min, pat dry.","Serve bolognese over zucchini noodles."], storage:"Sauce 5 days. Make zucchini noodles fresh.", grocery:{ Protein:["1.5 lbs ground turkey"], Produce:["4 zucchini","1 onion","4 cloves garlic"], Canned:["1 can crushed tomatoes","Tomato paste"], Dairy:["Parmesan cheese"], Pantry:["Olive oil","Chicken broth","Basil","Oregano","Salt & pepper"] } },
  { id:11, emoji:"🍛", title:"Chicken Tikka Masala", category:"Chicken", tags:["High Protein","Meal Prep","Comfort Food"], prep:"20 min", cook:"30 min", servings:5, calories:490, ingredients:["2 lbs chicken breast, cubed","1 can coconut milk (14 oz)","1 can crushed tomatoes (14 oz)","1 onion, diced","3 cloves garlic, minced","1 tbsp ginger, grated","2 tbsp olive oil","2 tbsp tikka masala spice","1 tsp cumin","Salt & pepper","2 cups basmati rice","Fresh cilantro"], steps:["Cook basmati rice.","Sauté onion 4 min. Add garlic and ginger 1 min.","Add spices 1 min.","Add chicken, cook 5–6 min.","Add tomatoes and coconut milk. Simmer 20 min.","Serve over rice, garnish with cilantro."], storage:"5 days. Freezes well.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["1 onion","3 cloves garlic","Fresh ginger","Cilantro"], Grains:["2 cups basmati rice"], Canned:["1 can coconut milk","1 can crushed tomatoes"], Pantry:["Olive oil","Tikka masala spice","Cumin","Salt & pepper"] } },
  { id:12, emoji:"🫙", title:"Lentil Vegetable Soup", category:"Soups & Stews", tags:["Vegan","High Fiber","Low Calorie"], prep:"15 min", cook:"40 min", servings:5, calories:290, ingredients:["2 cups green lentils","1 onion, diced","3 carrots, diced","3 stalks celery, sliced","4 cloves garlic, minced","1 can diced tomatoes (14 oz)","6 cups vegetable broth","1 tbsp olive oil","1 tsp cumin","1 tsp turmeric","1/2 tsp smoked paprika","Salt & pepper","2 cups spinach"], steps:["Sauté onion, carrot, celery 5 min.","Add garlic and spices 1 min.","Add lentils, tomatoes, and broth. Boil.","Simmer 30–35 min.","Stir in spinach. Season.","Cool and portion."], storage:"5 days. Freezes 3 months.", grocery:{ Produce:["1 onion","3 carrots","3 stalks celery","4 cloves garlic","2 cups spinach"], Grains:["2 cups lentils"], Canned:["1 can diced tomatoes"], Pantry:["Olive oil","Cumin","Turmeric","Smoked paprika","6 cups vegetable broth","Salt & pepper"] } },
  { id:13, emoji:"🥩", title:"Sheet Pan Steak Fajitas", category:"Beef", tags:["High Protein","Low Calorie","Mexican"], prep:"15 min", cook:"20 min", servings:5, calories:420, ingredients:["1.5 lbs flank steak, sliced","3 bell peppers (mixed), sliced","1 large onion, sliced","2 tbsp olive oil","1 tsp cumin","1 tsp chili powder","1 tsp garlic powder","Salt & pepper","10 flour tortillas","Lime juice","Fresh cilantro","Salsa"], steps:["Preheat oven to 425°F.","Toss steak, peppers, and onion with olive oil and spices.","Spread on sheet pan.","Roast 15–20 min until slightly charred.","Squeeze lime. Serve with salsa and cilantro."], storage:"4 days. Store filling and tortillas separately.", grocery:{ Protein:["1.5 lbs flank steak"], Produce:["3 bell peppers","1 large onion","Lime","Cilantro"], Pantry:["Olive oil","Cumin","Chili powder","Garlic powder","10 flour tortillas","Salsa","Salt & pepper"] } },
  { id:14, emoji:"🍤", title:"Shrimp Fried Rice", category:"Seafood", tags:["High Protein","Quick","Asian-Inspired"], prep:"10 min", cook:"15 min", servings:5, calories:390, ingredients:["1.5 lbs shrimp, peeled","4 cups cooked jasmine rice (day-old)","2 eggs","1 cup frozen peas","1/2 cup carrots, diced","3 cloves garlic, minced","2 tbsp soy sauce","1 tbsp oyster sauce","1 tsp sesame oil","1 tbsp vegetable oil","Green onions","Salt & pepper"], steps:["Cook shrimp 2 min per side. Remove.","Scramble eggs. Add garlic, peas, carrots. Stir fry 3 min.","Add rice. Stir fry 3 min.","Add shrimp, soy sauce, oyster sauce, sesame oil. Toss.","Garnish with green onions."], storage:"3 days. Do not freeze.", grocery:{ Protein:["1.5 lbs shrimp"], Produce:["Carrots","Green onions","3 cloves garlic"], Dairy:["2 eggs"], Grains:["4 cups jasmine rice"], Pantry:["Frozen peas","Soy sauce","Oyster sauce","Sesame oil","Vegetable oil","Salt & pepper"] } },
  { id:15, emoji:"🫑", title:"Stuffed Bell Peppers", category:"Beef", tags:["High Protein","Low Calorie","Meal Prep"], prep:"20 min", cook:"35 min", servings:5, calories:400, ingredients:["5 large bell peppers","1 lb ground beef (93% lean)","1 cup white rice (dry)","1 can diced tomatoes (14 oz)","1/2 onion, diced","2 cloves garlic, minced","1 tsp Italian seasoning","1/2 tsp garlic powder","1/2 cup shredded mozzarella","Salt & pepper","1 tbsp olive oil"], steps:["Preheat oven to 375°F. Cook rice.","Sauté onion and garlic 3 min. Brown beef.","Stir in tomatoes, rice, seasoning, salt, pepper.","Fill peppers. Top with mozzarella.","Bake 30–35 min.","Cool before storing."], storage:"4 days refrigerated.", grocery:{ Protein:["1 lb ground beef (93% lean)"], Produce:["5 large bell peppers","1/2 onion","2 cloves garlic"], Grains:["1 cup white rice"], Canned:["1 can diced tomatoes"], Dairy:["1/2 cup shredded mozzarella"], Pantry:["Italian seasoning","Garlic powder","Olive oil","Salt & pepper"] } },
  { id:16, emoji:"🍣", title:"Tuna Poke Bowls", category:"Seafood", tags:["High Protein","Low Calorie","Quick"], prep:"15 min", cook:"15 min", servings:5, calories:410, ingredients:["1.5 lbs sushi-grade tuna, diced","2 cups brown rice (dry)","2 tbsp soy sauce","1 tbsp sesame oil","1 tsp rice vinegar","1 tsp sriracha","1 avocado","1 cucumber, diced","1 cup edamame, shelled","2 tbsp sesame seeds","Green onions","Pickled ginger"], steps:["Cook brown rice. Cool.","Toss tuna with soy sauce, sesame oil, rice vinegar, sriracha.","Dice avocado and cucumber.","Assemble bowls: rice, tuna, avocado, cucumber, edamame.","Garnish with sesame seeds, green onions, pickled ginger."], storage:"2 days max (raw fish). Keep tuna separate.", grocery:{ Protein:["1.5 lbs sushi-grade tuna"], Produce:["1 avocado","1 cucumber","Green onions"], Grains:["2 cups brown rice"], Pantry:["Soy sauce","Sesame oil","Rice vinegar","Sriracha","Sesame seeds","Edamame","Pickled ginger"] } },
  { id:17, emoji:"🍗", title:"Chicken Tortilla Soup", category:"Soups & Stews", tags:["High Protein","Meal Prep","Mexican"], prep:"15 min", cook:"30 min", servings:5, calories:360, ingredients:["1.5 lbs chicken breast","1 can black beans (15 oz)","1 can diced tomatoes (14 oz)","1 can corn (15 oz)","4 cups chicken broth","1 onion, diced","3 cloves garlic, minced","1 tbsp olive oil","1 tsp cumin","1 tsp chili powder","Salt & pepper","Lime juice","Tortilla strips"], steps:["Sauté onion and garlic 3 min.","Add chicken, broth, tomatoes, beans, corn, and spices.","Boil, reduce, simmer 20 min.","Remove chicken, shred, return to pot.","Add lime juice. Simmer 5 min.","Serve with tortilla strips."], storage:"5 days. Freezes well.", grocery:{ Protein:["1.5 lbs chicken breast"], Produce:["1 onion","3 cloves garlic","Lime"], Canned:["1 can black beans","1 can diced tomatoes","1 can corn"], Pantry:["Olive oil","Cumin","Chili powder","4 cups chicken broth","Tortilla strips","Salt & pepper"] } },
  { id:18, emoji:"🥗", title:"Asian Sesame Chicken Salad", category:"Salads", tags:["High Protein","Low Calorie","Asian-Inspired"], prep:"20 min", cook:"20 min", servings:5, calories:350, ingredients:["2 lbs chicken breast","6 cups mixed greens","1 cup shredded purple cabbage","1 cup edamame","1/2 cup shredded carrots","1/4 cup sliced almonds","3 tbsp soy sauce","2 tbsp rice vinegar","1 tbsp sesame oil","1 tbsp honey","1 tsp ginger, grated","Sesame seeds","Mandarin oranges (1 can)"], steps:["Bake chicken at 400°F 20–22 min. Slice.","Whisk soy sauce, rice vinegar, sesame oil, honey, ginger for dressing.","Combine greens, cabbage, carrots, edamame, oranges.","Top with chicken, almonds, sesame seeds.","Dress right before eating."], storage:"4 days undressed.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["6 cups mixed greens","Purple cabbage","Carrots","Fresh ginger"], Canned:["Mandarin oranges"], Pantry:["Soy sauce","Rice vinegar","Sesame oil","Honey","Sliced almonds","Sesame seeds","Edamame"] } },
  { id:19, emoji:"🍖", title:"BBQ Turkey Meatballs", category:"Turkey", tags:["High Protein","Meal Prep","Comfort Food"], prep:"20 min", cook:"25 min", servings:5, calories:430, ingredients:["1.5 lbs ground turkey","1/2 cup breadcrumbs","1 egg","3 cloves garlic, minced","1/2 onion, grated","1/2 tsp smoked paprika","Salt & pepper","1 cup BBQ sauce","2 cups brown rice (dry)","1 lb broccoli"], steps:["Preheat oven to 400°F.","Mix turkey, breadcrumbs, egg, garlic, onion, paprika, salt, pepper. Roll into balls.","Bake 18–20 min.","Brush with BBQ sauce, bake 5 more min.","Cook rice. Roast broccoli.","Portion."], storage:"4 days. Meatballs freeze well.", grocery:{ Protein:["1.5 lbs ground turkey"], Produce:["1/2 onion","3 cloves garlic","1 lb broccoli"], Dairy:["1 egg"], Grains:["2 cups brown rice"], Pantry:["Breadcrumbs","Smoked paprika","BBQ sauce","Olive oil","Salt & pepper"] } },
  { id:20, emoji:"🫘", title:"Chickpea Tikka Masala", category:"Vegetarian", tags:["Vegan","High Fiber","Indian"], prep:"10 min", cook:"25 min", servings:5, calories:370, ingredients:["3 cans chickpeas (15 oz each)","1 can coconut milk (14 oz)","1 can crushed tomatoes (14 oz)","1 onion, diced","4 cloves garlic, minced","1 tbsp ginger, grated","2 tbsp tikka masala spice","1 tbsp olive oil","2 cups basmati rice","Salt & pepper","Fresh cilantro"], steps:["Cook basmati rice.","Sauté onion 4 min. Add garlic and ginger 1 min. Add spices 1 min.","Add chickpeas, tomatoes, coconut milk.","Simmer 20 min. Season.","Serve over rice with cilantro."], storage:"5 days. Freezes well.", grocery:{ Produce:["1 onion","4 cloves garlic","Fresh ginger","Cilantro"], Grains:["2 cups basmati rice"], Canned:["3 cans chickpeas","1 can coconut milk","1 can crushed tomatoes"], Pantry:["Tikka masala spice","Olive oil","Salt & pepper"] } },
  { id:21, emoji:"🐓", title:"Pesto Chicken Quinoa Bowls", category:"Chicken", tags:["High Protein","Mediterranean","Low Carb"], prep:"10 min", cook:"25 min", servings:5, calories:400, ingredients:["2 lbs chicken breast","1/3 cup pesto","1 pint cherry tomatoes","2 cups quinoa (dry)","2 cups spinach","2 tbsp olive oil","Salt & pepper","Fresh basil","1/4 cup pine nuts"], steps:["Preheat oven to 400°F.","Spread pesto over chicken. Season.","Toss cherry tomatoes with olive oil, salt, pepper.","Bake chicken and tomatoes 22–25 min.","Cook quinoa. Stir in spinach until wilted.","Portion over quinoa with tomatoes. Top with pine nuts and basil."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["1 pint cherry tomatoes","2 cups spinach","Fresh basil"], Grains:["2 cups quinoa"], Pantry:["Pesto","Olive oil","Pine nuts","Salt & pepper"] } },
  { id:22, emoji:"🥣", title:"Overnight Oats Meal Prep", category:"Vegetarian", tags:["Low Calorie","Quick","High Fiber"], prep:"10 min", cook:"0 min", servings:5, calories:310, ingredients:["2.5 cups rolled oats","2.5 cups almond milk","5 tbsp chia seeds","5 tbsp honey or maple syrup","1 tsp vanilla extract","2.5 tsp cinnamon","5 tbsp peanut butter","2 cups mixed berries","5 bananas"], steps:["Divide oats into 5 mason jars.","Add almond milk, chia seeds, honey, vanilla, and cinnamon to each.","Stir well. Seal and refrigerate overnight.","Morning: top with peanut butter, berries, and banana.","Stir before eating."], storage:"5 days refrigerated (without toppings).", grocery:{ Produce:["2 cups mixed berries","5 bananas"], Pantry:["Rolled oats","Chia seeds","Honey or maple syrup","Vanilla extract","Cinnamon","Peanut butter","Almond milk"] } },
  { id:23, emoji:"🐟", title:"Baked Cod Mediterranean", category:"Seafood", tags:["Low Calorie","Gluten-Free","Mediterranean"], prep:"15 min", cook:"15 min", servings:5, calories:310, ingredients:["5 cod fillets (5 oz each)","1 cup cherry tomatoes, halved","1/2 cup Kalamata olives","1/4 cup capers","3 tbsp olive oil","2 cloves garlic, minced","1 lemon, zested & juiced","Salt & pepper","Fresh parsley","2 cups couscous (dry)"], steps:["Preheat oven to 400°F.","Place cod on oiled baking sheet. Season.","Mix tomatoes, olives, capers, garlic, lemon. Spoon over fish.","Bake 12–15 min.","Cook couscous. Fluff and portion."], storage:"3 days refrigerated.", grocery:{ Protein:["5 cod fillets (5 oz)"], Produce:["Cherry tomatoes","1 lemon","Parsley","2 cloves garlic"], Grains:["2 cups couscous"], Pantry:["Olive oil","Kalamata olives","Capers","Salt & pepper"] } },
  { id:24, emoji:"🌮", title:"Slow Cooker Carnitas Bowls", category:"Pork", tags:["High Protein","Meal Prep","Mexican"], prep:"15 min", cook:"4 hrs", servings:5, calories:510, ingredients:["2 lbs pork shoulder","1 orange, juiced","1 lime, juiced","4 cloves garlic","1 tbsp cumin","1 tsp oregano","Salt & pepper","2 cups white rice","1 can black beans","1 cup salsa","1 avocado","Fresh cilantro"], steps:["Season pork with cumin, oregano, salt, pepper.","Slow cook with orange juice, lime juice, garlic 4 hrs high / 8 hrs low.","Shred pork. Broil 5 min for crispy bits.","Cook rice. Warm black beans.","Build bowls: rice, carnitas, beans, salsa, avocado, cilantro."], storage:"5 days. Carnitas freeze very well.", grocery:{ Protein:["2 lbs pork shoulder"], Produce:["1 orange","1 lime","4 cloves garlic","1 avocado","Cilantro"], Grains:["2 cups white rice"], Canned:["1 can black beans","1 cup salsa"], Pantry:["Cumin","Oregano","Salt & pepper"] } },
  { id:25, emoji:"🥦", title:"Roasted Veggie & Farro Bowls", category:"Vegetarian", tags:["Vegan","High Fiber","Mediterranean"], prep:"15 min", cook:"30 min", servings:5, calories:360, ingredients:["2 cups farro","1 head cauliflower, florets","2 sweet potatoes, cubed","1 red onion, wedged","1 can chickpeas","3 tbsp olive oil","1 tsp cumin","1 tsp smoked paprika","Salt & pepper","2 tbsp tahini","2 tbsp lemon juice","Fresh parsley"], steps:["Preheat oven to 425°F.","Toss cauliflower, sweet potato, onion, chickpeas with olive oil and spices.","Roast 25–30 min, toss halfway.","Cook farro.","Whisk tahini with lemon juice, water, salt.","Bowl: farro, roasted veggies, tahini dressing."], storage:"5 days refrigerated.", grocery:{ Produce:["1 head cauliflower","2 sweet potatoes","1 red onion","Parsley","1 lemon"], Grains:["2 cups farro"], Canned:["1 can chickpeas"], Pantry:["Olive oil","Cumin","Smoked paprika","Tahini","Salt & pepper"] } },
  { id:26, emoji:"🍗", title:"Buffalo Chicken Bowls", category:"Chicken", tags:["High Protein","Low Carb","Quick"], prep:"10 min", cook:"25 min", servings:5, calories:420, ingredients:["2 lbs chicken breast","1/3 cup buffalo sauce","1 tbsp butter, melted","2 cups brown rice","5 cups romaine lettuce","1 cup cherry tomatoes","1/2 cup celery, sliced","1/4 cup blue cheese crumbles","1/4 cup ranch dressing","Salt & pepper"], steps:["Preheat oven to 425°F. Mix buffalo sauce and butter. Coat chicken.","Bake 20–22 min. Rest 5 min, slice.","Cook brown rice.","Layer bowls: rice, lettuce, tomatoes, celery, chicken, blue cheese, ranch."], storage:"4 days. Keep dressing separate.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["5 cups romaine","Cherry tomatoes","Celery"], Grains:["2 cups brown rice"], Dairy:["Blue cheese crumbles","Ranch dressing","1 tbsp butter"], Pantry:["Buffalo sauce","Salt & pepper"] } },
  { id:27, emoji:"🐠", title:"Garlic Butter Tilapia", category:"Seafood", tags:["Low Calorie","Gluten-Free","Quick"], prep:"10 min", cook:"15 min", servings:5, calories:310, ingredients:["5 tilapia fillets","3 tbsp butter","4 cloves garlic, minced","1 lemon, juiced","1 lb asparagus","1 tbsp olive oil","Salt & pepper","Fresh parsley","Red pepper flakes","2 cups jasmine rice"], steps:["Preheat oven to 400°F.","Place tilapia on lined sheet pan. Season.","Melt butter with garlic and lemon. Pour over fish.","Toss asparagus with olive oil, salt, red pepper flakes.","Bake 12–14 min.","Cook rice. Portion."], storage:"3 days refrigerated.", grocery:{ Protein:["5 tilapia fillets"], Produce:["1 lb asparagus","4 cloves garlic","1 lemon","Parsley"], Grains:["2 cups jasmine rice"], Pantry:["Butter","Olive oil","Salt & pepper","Red pepper flakes"] } },
  { id:28, emoji:"🥩", title:"Korean Bulgogi Beef Bowl", category:"Beef", tags:["High Protein","Asian-Inspired","Meal Prep"], prep:"20 min", cook:"15 min", servings:5, calories:460, ingredients:["1.5 lbs beef sirloin, thin sliced","1/4 cup soy sauce","2 tbsp brown sugar","1 tbsp sesame oil","4 cloves garlic, minced","1 tbsp ginger, grated","1 Asian pear, grated","1 tbsp vegetable oil","2 cups jasmine rice","2 cups spinach","1 cup shredded carrots","Sesame seeds","Green onions"], steps:["Combine soy sauce, brown sugar, sesame oil, garlic, ginger, pear. Marinate beef 30 min.","Cook jasmine rice.","Sear beef in batches over high heat 1–2 min per side.","Prep spinach and carrots.","Bowl: rice, spinach, carrots, bulgogi. Garnish."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs beef sirloin"], Produce:["1 Asian pear","4 cloves garlic","Ginger","2 cups spinach","Shredded carrots","Green onions"], Grains:["2 cups jasmine rice"], Pantry:["Soy sauce","Brown sugar","Sesame oil","Vegetable oil","Sesame seeds"] } },
  { id:29, emoji:"🍲", title:"Chicken & Wild Rice Soup", category:"Soups & Stews", tags:["High Protein","Comfort Food","Meal Prep"], prep:"15 min", cook:"45 min", servings:5, calories:380, ingredients:["1.5 lbs chicken breast","1 cup wild rice blend","3 carrots, diced","3 stalks celery, sliced","1 onion, diced","3 cloves garlic, minced","6 cups chicken broth","1 tbsp olive oil","1 tsp thyme","1 tsp rosemary","Salt & pepper","2 tbsp cornstarch","1 cup 2% milk"], steps:["Sauté onion, carrot, celery 5 min. Add garlic 1 min.","Add chicken, broth, rice, herbs. Boil.","Simmer 35–40 min.","Remove chicken, shred, return to pot.","Whisk cornstarch into milk, stir in. Simmer 5 min."], storage:"4 days. Add broth when reheating.", grocery:{ Protein:["1.5 lbs chicken breast"], Produce:["3 carrots","3 stalks celery","1 onion","3 cloves garlic"], Grains:["1 cup wild rice blend"], Dairy:["1 cup 2% milk"], Pantry:["Olive oil","Thyme","Rosemary","Cornstarch","6 cups chicken broth","Salt & pepper"] } },
  { id:30, emoji:"🫙", title:"Shakshuka", category:"Vegetarian", tags:["Vegetarian","Mediterranean","Quick"], prep:"10 min", cook:"25 min", servings:5, calories:280, ingredients:["10 eggs","2 cans crushed tomatoes (28 oz)","1 onion, diced","4 cloves garlic, minced","1 red bell pepper, diced","2 tbsp olive oil","1 tsp cumin","1 tsp smoked paprika","1/2 tsp chili flakes","Salt & pepper","Fresh parsley","Feta cheese","Pita bread"], steps:["Sauté onion and bell pepper 5 min. Add garlic and spices 1 min.","Add crushed tomatoes. Simmer 10 min.","Make wells. Crack eggs in.","Cover and cook 8–10 min until set.","Garnish with parsley and feta. Serve with pita."], storage:"3 days.", grocery:{ Produce:["1 onion","4 cloves garlic","1 red bell pepper","Parsley"], Dairy:["10 eggs","Feta cheese"], Canned:["2 cans crushed tomatoes"], Pantry:["Olive oil","Cumin","Smoked paprika","Chili flakes","Pita bread","Salt & pepper"] } },
  { id:31, emoji:"🍗", title:"Chicken Shawarma Bowls", category:"Chicken", tags:["High Protein","Mediterranean","Meal Prep"], prep:"15 min", cook:"25 min", servings:5, calories:450, ingredients:["2 lbs chicken thighs, boneless","2 tbsp olive oil","1 tsp cumin","1 tsp coriander","1 tsp smoked paprika","1/2 tsp turmeric","1/2 tsp cinnamon","Salt & pepper","2 cups couscous","1 cucumber, diced","1 cup cherry tomatoes","1/4 red onion, sliced","1/2 cup hummus","Lemon juice","Fresh parsley"], steps:["Mix olive oil and all spices. Marinate chicken 15 min.","Grill or pan-sear 5–6 min per side. Rest, slice.","Cook couscous.","Dice cucumber, halve tomatoes, slice onion.","Assemble bowls with couscous, chicken, vegetables, hummus. Drizzle with lemon."], storage:"4 days. Keep hummus separate.", grocery:{ Protein:["2 lbs boneless chicken thighs"], Produce:["1 cucumber","Cherry tomatoes","1/4 red onion","Lemon","Parsley"], Grains:["2 cups couscous"], Pantry:["Olive oil","Cumin","Coriander","Smoked paprika","Turmeric","Cinnamon","Hummus","Salt & pepper"] } },
  { id:32, emoji:"🥗", title:"Taco Salad Bowls", category:"Beef", tags:["High Protein","Low Calorie","Mexican"], prep:"15 min", cook:"15 min", servings:5, calories:390, ingredients:["1 lb ground beef (93% lean)","1 packet taco seasoning","1 can black beans","6 cups romaine, chopped","1 cup cherry tomatoes","1 cup corn","1 avocado, diced","1/2 cup shredded cheddar","1/4 cup sour cream","Lime juice","Cilantro","Baked tortilla chips"], steps:["Brown beef, drain, add taco seasoning.","Warm black beans.","Chop all vegetables.","Layer bowls: lettuce, beef, beans, corn, tomatoes, avocado.","Top with cheddar and sour cream. Add chips before eating."], storage:"4 days undressed. Keep chips and avocado separate.", grocery:{ Protein:["1 lb ground beef (93% lean)"], Produce:["6 cups romaine","Cherry tomatoes","1 avocado","Lime","Cilantro"], Dairy:["Shredded cheddar","Sour cream"], Canned:["1 can black beans","1 cup corn"], Pantry:["Taco seasoning","Baked tortilla chips"] } },
  { id:33, emoji:"🐷", title:"Pork Tenderloin & Sweet Potato Mash", category:"Pork", tags:["High Protein","Gluten-Free","Comfort Food"], prep:"15 min", cook:"30 min", servings:5, calories:440, ingredients:["2 lbs pork tenderloin","3 large sweet potatoes","2 tbsp olive oil","1 tbsp Dijon mustard","1 tbsp honey","1 tsp garlic powder","1 tsp thyme","Salt & pepper","2 tbsp butter","1/4 cup milk","1 lb green beans"], steps:["Preheat oven to 425°F.","Rub pork with mustard, honey, garlic powder, thyme, salt, pepper.","Roast 20–25 min until 145°F. Rest 10 min.","Boil sweet potatoes. Mash with butter and milk.","Roast green beans with olive oil and salt last 12 min.","Slice pork. Portion."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs pork tenderloin"], Produce:["3 sweet potatoes","1 lb green beans"], Dairy:["2 tbsp butter","1/4 cup milk"], Pantry:["Olive oil","Dijon mustard","Honey","Garlic powder","Thyme","Salt & pepper"] } },
  { id:34, emoji:"🌱", title:"Tofu Vegetable Stir Fry", category:"Vegetarian", tags:["Vegan","High Protein","Asian-Inspired"], prep:"15 min", cook:"20 min", servings:5, calories:320, ingredients:["2 blocks extra-firm tofu","2 cups broccoli","2 bell peppers, sliced","1 cup snap peas","2 cups carrots, sliced","4 cloves garlic, minced","1 tbsp ginger, grated","3 tbsp soy sauce","1 tbsp sesame oil","1 tbsp rice vinegar","1 tbsp cornstarch","2 cups brown rice","1 tbsp vegetable oil"], steps:["Press tofu 30 min. Cut into cubes. Pan fry until golden 8–10 min.","Stir fry all vegetables 4–5 min.","Add garlic and ginger 1 min.","Whisk soy sauce, sesame oil, rice vinegar, cornstarch. Pour over.","Add tofu. Toss 1–2 min.","Serve over brown rice."], storage:"4 days refrigerated.", grocery:{ Protein:["2 blocks extra-firm tofu"], Produce:["2 cups broccoli","2 bell peppers","1 cup snap peas","Carrots","4 cloves garlic","Ginger"], Grains:["2 cups brown rice"], Pantry:["Soy sauce","Sesame oil","Rice vinegar","Cornstarch","Vegetable oil"] } },
  { id:35, emoji:"🦃", title:"Turkey Meatball Pasta Bake", category:"Turkey", tags:["High Protein","Comfort Food","Meal Prep"], prep:"20 min", cook:"30 min", servings:5, calories:500, ingredients:["1.5 lbs ground turkey","12 oz whole wheat pasta","1/4 cup breadcrumbs","1 egg","3 cloves garlic, minced","1 tsp Italian seasoning","2 cups marinara sauce","1 cup shredded mozzarella","1/4 cup Parmesan","Salt & pepper","Fresh basil"], steps:["Preheat oven to 400°F. Cook pasta al dente.","Mix turkey, breadcrumbs, egg, garlic, seasoning, salt, pepper. Roll into balls.","Bake meatballs 15 min.","Toss pasta with marinara. Layer in baking dish.","Add meatballs. Top with mozzarella and Parmesan.","Bake 15 min until bubbly."], storage:"4 days. Freezes well.", grocery:{ Protein:["1.5 lbs ground turkey"], Grains:["12 oz whole wheat pasta"], Dairy:["1 egg","Shredded mozzarella","Parmesan cheese"], Canned:["2 cups marinara sauce"], Pantry:["Breadcrumbs","Garlic","Italian seasoning","Salt & pepper"] } },
  { id:36, emoji:"🥙", title:"Mediterranean Chicken Wraps", category:"Chicken", tags:["High Protein","Mediterranean","Low Calorie"], prep:"20 min", cook:"20 min", servings:5, calories:380, ingredients:["2 lbs chicken breast","1 tsp cumin","1 tsp oregano","Salt & pepper","5 whole wheat tortillas","1/2 cup hummus","1 cucumber, diced","1 cup cherry tomatoes","1/4 red onion, sliced","1/2 cup Kalamata olives","1/2 cup feta cheese","2 cups spinach","1/4 cup tzatziki"], steps:["Season chicken with cumin, oregano, salt, pepper. Grill until 165°F. Slice.","Spread hummus on tortillas.","Layer spinach, cucumber, tomatoes, onion, olives, feta.","Add chicken slices. Drizzle tzatziki.","Roll tightly. Wrap in parchment."], storage:"3 days wrapped in parchment.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["1 cucumber","Cherry tomatoes","1/4 red onion","2 cups spinach"], Dairy:["Feta cheese","Tzatziki"], Pantry:["Cumin","Oregano","5 whole wheat tortillas","Hummus","Kalamata olives","Salt & pepper"] } },
  { id:37, emoji:"🍛", title:"Coconut Curry Chickpea Soup", category:"Soups & Stews", tags:["Vegan","High Fiber","Quick"], prep:"10 min", cook:"25 min", servings:5, calories:340, ingredients:["3 cans chickpeas","1 can coconut milk","1 can diced tomatoes","4 cups vegetable broth","1 onion, diced","4 cloves garlic, minced","1 tbsp ginger, grated","2 tbsp curry powder","1 tsp turmeric","1 tbsp olive oil","2 cups spinach","Salt & pepper","Lime juice","Cilantro","2 cups basmati rice"], steps:["Cook basmati rice.","Sauté onion 4 min. Add garlic, ginger, curry powder, turmeric 1 min.","Add chickpeas, tomatoes, broth, coconut milk. Simmer 20 min.","Stir in spinach, lime juice, salt, pepper.","Serve over rice, garnish with cilantro."], storage:"5 days. Freezes well.", grocery:{ Produce:["1 onion","4 cloves garlic","Ginger","2 cups spinach","Lime","Cilantro"], Grains:["2 cups basmati rice"], Canned:["3 cans chickpeas","1 can coconut milk","1 can diced tomatoes"], Pantry:["Curry powder","Turmeric","Olive oil","4 cups vegetable broth","Salt & pepper"] } },
  { id:38, emoji:"🥩", title:"Mongolian Beef", category:"Beef", tags:["High Protein","Asian-Inspired","Quick"], prep:"15 min", cook:"15 min", servings:5, calories:450, ingredients:["1.5 lbs flank steak, thin sliced","1/4 cup cornstarch","1/4 cup vegetable oil","4 cloves garlic, minced","1 tsp ginger, grated","1/2 cup soy sauce","1/4 cup brown sugar","1/2 cup water","2 cups jasmine rice","Green onions","Red pepper flakes"], steps:["Toss steak with cornstarch.","Fry in batches in oil 1–2 min per side until crispy. Drain.","Cook garlic and ginger 30 sec in same pan.","Add soy sauce, brown sugar, and water. Simmer 3 min.","Add beef back. Toss to coat.","Serve over rice with green onions."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs flank steak"], Produce:["4 cloves garlic","Ginger","Green onions"], Grains:["2 cups jasmine rice"], Pantry:["Cornstarch","Vegetable oil","Soy sauce","Brown sugar","Red pepper flakes"] } },
  { id:39, emoji:"🫑", title:"Egg & Veggie Breakfast Burritos", category:"Vegetarian", tags:["High Protein","Meal Prep","Quick"], prep:"10 min", cook:"15 min", servings:5, calories:360, ingredients:["10 large eggs","1/2 cup milk","1 bell pepper, diced","1/2 onion, diced","1 cup black beans","1 cup corn","1/2 cup shredded cheddar","5 large flour tortillas","1/2 cup salsa","1 tbsp olive oil","Salt & pepper","Hot sauce"], steps:["Sauté bell pepper and onion 3 min.","Add black beans and corn 2 min.","Whisk eggs with milk, salt, pepper. Scramble until just set.","Divide among tortillas. Top with cheese and salsa.","Roll tightly. Wrap in foil."], storage:"4 days. Reheat in foil at 350°F 15 min.", grocery:{ Produce:["1 bell pepper","1/2 onion"], Dairy:["10 large eggs","1/2 cup milk","Shredded cheddar"], Canned:["1 cup black beans","1 cup corn"], Pantry:["5 large flour tortillas","Salsa","Olive oil","Hot sauce","Salt & pepper"] } },
  { id:40, emoji:"🐟", title:"Lemon Dill Salmon & Orzo", category:"Seafood", tags:["High Protein","Mediterranean","Meal Prep"], prep:"15 min", cook:"20 min", servings:5, calories:430, ingredients:["5 salmon fillets","2 tbsp olive oil","2 lemons (zest & juice)","2 tsp dried dill","3 cloves garlic, minced","Salt & pepper","2 cups orzo","2 cups cherry tomatoes","2 cups baby spinach","1/4 cup Parmesan, grated","2 tbsp butter"], steps:["Preheat oven to 400°F.","Season salmon with olive oil, lemon, dill, garlic, salt, pepper. Bake 12–15 min.","Cook orzo. Drain.","Toss hot orzo with butter, spinach, tomatoes, Parmesan.","Portion orzo and top with salmon."], storage:"3–4 days refrigerated.", grocery:{ Protein:["5 salmon fillets"], Produce:["2 lemons","2 cups cherry tomatoes","2 cups baby spinach","3 cloves garlic"], Grains:["2 cups orzo"], Dairy:["Parmesan cheese","2 tbsp butter"], Pantry:["Olive oil","Dried dill","Salt & pepper"] } },
  { id:41, emoji:"🥗", title:"Southwest Chicken Power Salad", category:"Salads", tags:["High Protein","Low Calorie","Mexican"], prep:"20 min", cook:"20 min", servings:5, calories:380, ingredients:["2 lbs chicken breast","6 cups romaine, chopped","1 can black beans, drained","1 cup corn","1 cup cherry tomatoes","1 avocado, diced","1/4 cup red onion, diced","1/2 cup shredded cheddar","3 tbsp olive oil","2 tbsp lime juice","1 tsp cumin","Salt & pepper","Cilantro"], steps:["Season and bake chicken at 400°F 20–22 min. Slice.","Whisk olive oil, lime juice, cumin, salt for dressing.","Assemble bowls: romaine, beans, corn, tomatoes, onion, avocado.","Top with chicken and cheddar.","Dress right before eating."], storage:"4 days undressed.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["6 cups romaine","Cherry tomatoes","1 avocado","Red onion","Lime","Cilantro"], Dairy:["Shredded cheddar"], Canned:["1 can black beans","1 cup corn"], Pantry:["Olive oil","Cumin","Salt & pepper"] } },
  { id:42, emoji:"🍖", title:"Honey Mustard Pork Chops", category:"Pork", tags:["High Protein","Gluten-Free","Quick"], prep:"10 min", cook:"20 min", servings:5, calories:410, ingredients:["5 thick pork chops","3 tbsp Dijon mustard","2 tbsp honey","1 tbsp olive oil","1 tsp garlic powder","Salt & pepper","2 cups white rice","1 lb Brussels sprouts, halved","2 tbsp balsamic vinegar"], steps:["Preheat oven to 400°F.","Mix Dijon, honey, garlic powder, salt, pepper. Coat pork chops.","Sear 2 min per side. Transfer to oven 10–12 min.","Toss Brussels with olive oil, balsamic, salt, pepper. Roast 20–25 min.","Cook rice. Portion."], storage:"4 days refrigerated.", grocery:{ Protein:["5 thick pork chops"], Produce:["1 lb Brussels sprouts"], Grains:["2 cups white rice"], Pantry:["Dijon mustard","Honey","Olive oil","Garlic powder","Balsamic vinegar","Salt & pepper"] } },
  { id:43, emoji:"🫘", title:"Red Beans, Rice & Turkey Sausage", category:"Turkey", tags:["High Protein","Comfort Food","Cajun"], prep:"10 min", cook:"30 min", servings:5, calories:450, ingredients:["1 lb turkey sausage, sliced","2 cans red kidney beans (15 oz)","2 cups long grain rice","1 onion, diced","2 stalks celery, sliced","1 green bell pepper, diced","3 cloves garlic, minced","1 tsp Cajun seasoning","1/2 tsp thyme","3 cups chicken broth","1 tbsp olive oil","Salt & pepper","Green onions"], steps:["Cook rice.","Sauté onion, celery, bell pepper 4 min.","Add garlic and sausage. Brown 4 min.","Add beans, broth, Cajun seasoning, thyme. Simmer 20 min.","Season. Serve over rice with green onions."], storage:"5 days. Freezes well.", grocery:{ Protein:["1 lb turkey sausage"], Produce:["1 onion","2 stalks celery","1 green bell pepper","3 cloves garlic","Green onions"], Grains:["2 cups long grain rice"], Canned:["2 cans red kidney beans"], Pantry:["Cajun seasoning","Thyme","Olive oil","3 cups chicken broth","Salt & pepper"] } },
  { id:44, emoji:"🥬", title:"Thai Peanut Noodle Bowls", category:"Vegetarian", tags:["Vegan","Asian-Inspired","Quick"], prep:"15 min", cook:"10 min", servings:5, calories:430, ingredients:["12 oz rice noodles","2 cups shredded purple cabbage","2 cups carrots, julienned","1 red bell pepper, sliced","1 cup edamame","1/2 cup peanut butter","3 tbsp soy sauce","2 tbsp lime juice","1 tbsp sesame oil","1 tbsp honey","1 tsp sriracha","1 tsp ginger, grated","Crushed peanuts","Cilantro"], steps:["Cook rice noodles. Rinse cold water.","Whisk peanut butter, soy sauce, lime juice, sesame oil, honey, sriracha, ginger. Thin with water.","Prep vegetables.","Toss noodles with sauce.","Top with vegetables, edamame, peanuts, cilantro."], storage:"4 days. Keep sauce separate for best texture.", grocery:{ Produce:["Purple cabbage","Carrots","1 red bell pepper","Lime","Cilantro","Ginger"], Grains:["12 oz rice noodles"], Pantry:["Peanut butter","Soy sauce","Sesame oil","Honey","Sriracha","Crushed peanuts","Edamame"] } },
  { id:45, emoji:"🐔", title:"White Chicken Enchiladas", category:"Chicken", tags:["High Protein","Comfort Food","Mexican"], prep:"20 min", cook:"30 min", servings:5, calories:490, ingredients:["2 lbs chicken breast, cooked & shredded","10 flour tortillas","2 cups Greek yogurt","1 cup green salsa","2 cups shredded Monterey Jack","1 can diced green chilis","1 tsp garlic powder","1 tsp cumin","Salt & pepper","1 tbsp butter","Cilantro"], steps:["Preheat oven to 375°F.","Mix yogurt, green salsa, chilis, garlic powder, cumin, salt, pepper.","Combine chicken with half the yogurt sauce.","Fill tortillas. Roll and place in buttered baking dish.","Pour remaining sauce over. Cover with cheese.","Bake 25–30 min. Garnish with cilantro."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["Cilantro"], Dairy:["2 cups Greek yogurt","Shredded Monterey Jack","1 tbsp butter"], Canned:["1 can diced green chilis","1 cup green salsa"], Pantry:["10 flour tortillas","Garlic powder","Cumin","Salt & pepper"] } },
  { id:46, emoji:"🍲", title:"Beef & Vegetable Stew", category:"Soups & Stews", tags:["High Protein","Comfort Food","Meal Prep"], prep:"20 min", cook:"1 hr", servings:5, calories:420, ingredients:["1.5 lbs beef chuck, cubed","3 carrots, sliced","3 potatoes, cubed","2 stalks celery, sliced","1 onion, diced","3 cloves garlic, minced","2 cups beef broth","1 can diced tomatoes","1 tbsp tomato paste","1 tbsp olive oil","1 tsp thyme","1 bay leaf","Salt & pepper","2 tbsp flour"], steps:["Toss beef in flour, salt, pepper. Brown in olive oil in batches.","Add onion and garlic 3 min.","Add tomato paste 2 min.","Add broth, tomatoes, thyme, bay leaf. Boil.","Add carrots, potatoes, celery. Simmer 45 min.","Remove bay leaf. Season."], storage:"5 days. Freezes 3 months.", grocery:{ Protein:["1.5 lbs beef chuck"], Produce:["3 carrots","3 potatoes","2 stalks celery","1 onion","3 cloves garlic"], Canned:["1 can diced tomatoes","Tomato paste"], Pantry:["Olive oil","Flour","Thyme","Bay leaf","2 cups beef broth","Salt & pepper"] } },
  { id:47, emoji:"🥣", title:"Protein Turkey Chili", category:"Turkey", tags:["High Protein","Low Calorie","Meal Prep"], prep:"15 min", cook:"35 min", servings:5, calories:370, ingredients:["1.5 lbs ground turkey","2 cans kidney beans","1 can diced tomatoes","1 can tomato sauce (15 oz)","1 onion, diced","3 cloves garlic, minced","1 tbsp olive oil","2 tbsp chili powder","1 tsp cumin","1 tsp smoked paprika","Salt & pepper","Green onions","Shredded cheddar","Sour cream"], steps:["Sauté onion 3 min. Add garlic 1 min.","Brown turkey 7–8 min.","Add all spices 1 min.","Add beans, tomatoes, tomato sauce.","Simmer 25 min. Adjust seasoning.","Top with cheese, sour cream, green onions."], storage:"5 days. Freezes 3 months.", grocery:{ Protein:["1.5 lbs ground turkey"], Produce:["1 onion","3 cloves garlic","Green onions"], Dairy:["Shredded cheddar","Sour cream"], Canned:["2 cans kidney beans","1 can diced tomatoes","1 can tomato sauce"], Pantry:["Olive oil","Chili powder","Cumin","Smoked paprika","Salt & pepper"] } },
  { id:48, emoji:"🫐", title:"Cottage Cheese Protein Bowls", category:"Vegetarian", tags:["High Protein","Low Calorie","Quick"], prep:"10 min", cook:"0 min", servings:5, calories:290, ingredients:["4 cups cottage cheese (low fat)","2 cups mixed berries","5 tbsp honey","1/4 cup granola","5 tbsp chia seeds","5 tbsp almond butter","1 tsp vanilla extract","1 tsp cinnamon","5 bananas"], steps:["Divide cottage cheese into 5 containers.","Stir in vanilla and cinnamon.","Top with berries and sliced banana.","Drizzle honey.","Add granola and almond butter.","Top with chia seeds."], storage:"4 days. Add granola fresh to keep crunch.", grocery:{ Produce:["2 cups mixed berries","5 bananas"], Dairy:["4 cups low fat cottage cheese"], Pantry:["Honey","Granola","Chia seeds","Almond butter","Vanilla extract","Cinnamon"] } },
  { id:49, emoji:"🐟", title:"Miso Glazed Salmon Bowls", category:"Seafood", tags:["High Protein","Asian-Inspired","Meal Prep"], prep:"15 min", cook:"15 min", servings:5, calories:440, ingredients:["5 salmon fillets","3 tbsp white miso paste","2 tbsp mirin","1 tbsp soy sauce","1 tbsp honey","2 cups brown rice","2 cups edamame (shelled)","1 cucumber, sliced","1 cup shredded purple cabbage","Sesame seeds","Green onions","Rice vinegar"], steps:["Whisk miso, mirin, soy sauce, honey. Coat salmon. Marinate 15 min.","Broil salmon 8–10 min until caramelized.","Cook brown rice.","Prep vegetables.","Bowl: rice, salmon, edamame, cucumber, cabbage. Top with sesame seeds and green onions."], storage:"3–4 days refrigerated.", grocery:{ Protein:["5 salmon fillets"], Produce:["1 cucumber","Purple cabbage","Green onions"], Grains:["2 cups brown rice"], Pantry:["White miso paste","Mirin","Soy sauce","Honey","Edamame","Sesame seeds","Rice vinegar"] } },
  { id:50, emoji:"🥗", title:"Cobb Salad Meal Prep", category:"Salads", tags:["High Protein","Low Carb","Gluten-Free"], prep:"25 min", cook:"20 min", servings:5, calories:430, ingredients:["2 lbs chicken breast","6 cups romaine, chopped","5 hard-boiled eggs","10 strips turkey bacon","1 avocado, diced","1 cup cherry tomatoes","1/2 cup blue cheese crumbles","1/4 cup red onion","1 cup corn","1/4 cup ranch dressing","Salt & pepper","1 tbsp olive oil"], steps:["Bake chicken at 400°F 20–22 min. Slice.","Hard boil eggs: cover with cold water, bring to boil, simmer 10 min, ice bath.","Cook turkey bacon until crispy. Crumble.","Prep all vegetables.","Layer containers: romaine, chicken, eggs, bacon, avocado, tomatoes, corn, onion, blue cheese.","Store dressing separately."], storage:"4 days. Add dressing fresh.", grocery:{ Protein:["2 lbs chicken breast","10 strips turkey bacon"], Produce:["6 cups romaine","1 avocado","Cherry tomatoes","Red onion","1 cup corn"], Dairy:["5 eggs","Blue cheese crumbles","Ranch dressing"], Pantry:["Olive oil","Salt & pepper"] } },
  { id:51, emoji:"🍜", title:"Ramen-Style Chicken Noodle Soup", category:"Soups & Stews", tags:["High Protein","Comfort Food","Asian-Inspired"], prep:"15 min", cook:"30 min", servings:5, calories:410, ingredients:["2 lbs chicken breast","10 oz ramen noodles (discard seasoning)","6 cups chicken broth","2 cups bok choy, chopped","1 cup shiitake mushrooms, sliced","3 cloves garlic, minced","1 tbsp ginger, grated","2 tbsp soy sauce","1 tbsp sesame oil","2 tbsp miso paste","4 soft-boiled eggs","Green onions","Sesame seeds","Chili oil"], steps:["Poach chicken in broth 20 min. Shred.","Add garlic, ginger, soy sauce, miso, and sesame oil to broth. Simmer 5 min.","Cook noodles separately per package.","Add bok choy and mushrooms. Simmer 3 min.","Soft-boil eggs: 6 min in boiling water, ice bath.","Portion: noodles, broth, chicken, veggies, halved egg. Top with green onions and sesame."], storage:"3 days. Keep noodles separate from broth.", grocery:{ Protein:["2 lbs chicken breast","4 eggs"], Produce:["2 cups bok choy","Shiitake mushrooms","3 cloves garlic","Ginger","Green onions"], Grains:["10 oz ramen noodles"], Pantry:["Chicken broth","Soy sauce","Sesame oil","Miso paste","Sesame seeds","Chili oil"] } },
  { id:52, emoji:"🍔", title:"Smash Burger Lettuce Wraps", category:"Beef", tags:["Low Carb","High Protein","Quick"], prep:"15 min", cook:"15 min", servings:5, calories:390, ingredients:["1.5 lbs ground beef (80/20)","10 large butter lettuce leaves","1 tbsp vegetable oil","1 tsp garlic powder","1 tsp onion powder","Salt & pepper","5 tbsp special sauce (mayo+ketchup+relish)","1 cup shredded cheddar","2 tomatoes, sliced","1 red onion, thinly sliced","Pickles","Mustard"], steps:["Mix ground beef with garlic powder, onion powder, salt, pepper. Form 10 thin patties.","Heat cast iron to high. Smash patties with spatula. Cook 2 min per side.","Add cheddar in last 30 sec to melt.","Lay lettuce cups flat. Add sauce, patty, tomato, onion, pickles.","Fold and serve.","For meal prep: wrap individually in parchment."], storage:"3 days. Reheat patties in skillet.", grocery:{ Protein:["1.5 lbs ground beef (80/20)"], Produce:["10 butter lettuce leaves","2 tomatoes","1 red onion","Pickles"], Dairy:["Shredded cheddar"], Pantry:["Vegetable oil","Garlic powder","Onion powder","Mayo","Ketchup","Relish","Mustard","Salt & pepper"] } },
  { id:53, emoji:"🍗", title:"Harissa Chicken & Couscous", category:"Chicken", tags:["High Protein","Mediterranean","Spicy"], prep:"15 min", cook:"25 min", servings:5, calories:430, ingredients:["2 lbs chicken thighs, boneless","3 tbsp harissa paste","2 tbsp olive oil","2 cups couscous","1 can chickpeas, drained","1 cup cherry tomatoes","1/2 cup cucumber, diced","1/4 cup red onion, diced","3 tbsp lemon juice","Fresh mint and parsley","Salt & pepper","2 cups vegetable broth (for couscous)"], steps:["Rub chicken with harissa, olive oil, salt. Marinate 15 min.","Grill or sear chicken 5–6 min per side until 165°F.","Cook couscous in vegetable broth 5 min covered. Fluff.","Warm chickpeas in same pan as chicken.","Toss couscous with chickpeas, tomatoes, cucumber, onion, lemon juice, herbs.","Slice chicken. Serve over couscous."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs boneless chicken thighs"], Produce:["Cherry tomatoes","1/2 cup cucumber","1/4 red onion","Lemon","Fresh mint","Fresh parsley"], Grains:["2 cups couscous"], Canned:["1 can chickpeas"], Pantry:["Harissa paste","Olive oil","Salt & pepper","2 cups vegetable broth"] } },
  { id:54, emoji:"🥓", title:"Korean BBQ Pork Rice Bowls", category:"Pork", tags:["High Protein","Asian-Inspired","Meal Prep"], prep:"20 min", cook:"15 min", servings:5, calories:480, ingredients:["1.5 lbs pork belly or shoulder, thin sliced","1/4 cup soy sauce","2 tbsp gochujang","2 tbsp sesame oil","3 tbsp brown sugar","4 cloves garlic, minced","1 tbsp ginger, grated","2 cups short-grain rice","2 cups shredded cabbage","1 cup shredded carrots","4 green onions","Sesame seeds","Kimchi (optional)"], steps:["Mix soy sauce, gochujang, sesame oil, brown sugar, garlic, ginger. Marinate pork 20 min.","Cook short-grain rice.","Sear pork in batches in hot pan 2–3 min per side.","Prep cabbage and carrots.","Build bowls: rice, pork, cabbage, carrots.","Top with green onions, sesame seeds, kimchi."], storage:"4 days. Kimchi separate.", grocery:{ Protein:["1.5 lbs pork belly or shoulder"], Produce:["2 cups cabbage","1 cup carrots","4 green onions","4 cloves garlic","Ginger"], Grains:["2 cups short-grain rice"], Pantry:["Soy sauce","Gochujang","Sesame oil","Brown sugar","Sesame seeds"] } },
  { id:55, emoji:"🥗", title:"Niçoise Salad Boxes", category:"Salads", tags:["High Protein","Mediterranean","Low Calorie"], prep:"25 min", cook:"15 min", servings:5, calories:370, ingredients:["3 cans tuna in olive oil (5 oz each)","10 small potatoes, halved","1 lb green beans","5 eggs, hard-boiled","1 cup Kalamata olives","1 cup cherry tomatoes","1/4 cup red onion, sliced","3 tbsp Dijon mustard","3 tbsp red wine vinegar","1/2 cup olive oil","1 tsp dried herbes de Provence","Salt & pepper"], steps:["Boil potatoes 10 min until tender. Drain, cool.","Blanch green beans 3 min. Shock in ice water.","Hard boil eggs 10 min. Peel and halve.","Whisk Dijon, vinegar, olive oil, herbes de Provence, salt, pepper.","Arrange in containers: tuna, potatoes, beans, eggs, olives, tomatoes, onion.","Drizzle dressing before serving."], storage:"4 days. Keep dressing separate.", grocery:{ Protein:["3 cans tuna in olive oil","5 eggs"], Produce:["10 small potatoes","1 lb green beans","Cherry tomatoes","1/4 red onion"], Pantry:["Kalamata olives","Dijon mustard","Red wine vinegar","Olive oil","Herbes de Provence","Salt & pepper"] } },
  { id:56, emoji:"🥚", title:"Turkey Sausage Egg Muffins", category:"Turkey", tags:["High Protein","Low Carb","Quick"], prep:"10 min", cook:"20 min", servings:5, calories:280, ingredients:["1 lb turkey sausage, crumbled","10 large eggs","1/2 cup shredded cheddar","1/2 cup diced bell pepper","1/4 cup diced onion","1 cup baby spinach, chopped","Salt & pepper","1/4 tsp garlic powder","Cooking spray"], steps:["Preheat oven to 375°F. Spray a 12-cup muffin tin.","Brown turkey sausage, breaking apart. Drain.","Whisk eggs with salt, pepper, and garlic powder.","Mix in sausage, bell pepper, onion, spinach, and cheddar.","Fill muffin cups 3/4 full.","Bake 18–20 min until set. Cool 5 min before removing."], storage:"5 days refrigerated. Freezes well.", grocery:{ Protein:["1 lb turkey sausage"], Produce:["1/2 cup bell pepper","1/4 cup onion","1 cup baby spinach"], Dairy:["10 large eggs","Shredded cheddar"], Pantry:["Garlic powder","Cooking spray","Salt & pepper"] } },
  { id:57, emoji:"🍝", title:"Lemon Garlic Shrimp Pasta", category:"Seafood", tags:["High Protein","Mediterranean","Quick"], prep:"10 min", cook:"20 min", servings:5, calories:420, ingredients:["1.5 lbs shrimp, peeled","12 oz linguine","5 cloves garlic, minced","3 tbsp olive oil","1 tbsp butter","Zest and juice of 2 lemons","1/2 cup white wine or chicken broth","1/4 tsp red pepper flakes","2 cups cherry tomatoes","2 cups baby spinach","1/4 cup Parmesan","Fresh parsley","Salt & pepper"], steps:["Cook linguine al dente. Reserve 1/2 cup pasta water.","Heat olive oil and butter in pan. Sauté garlic 1 min.","Add shrimp. Cook 2 min per side. Remove.","Add wine/broth, lemon juice, red pepper flakes. Simmer 3 min.","Add tomatoes and spinach. Wilt.","Toss pasta with sauce, shrimp, Parmesan, and parsley. Add pasta water to loosen."], storage:"3 days. Reheat gently with splash of broth.", grocery:{ Protein:["1.5 lbs shrimp"], Produce:["5 cloves garlic","2 lemons","Cherry tomatoes","2 cups baby spinach","Fresh parsley"], Grains:["12 oz linguine"], Dairy:["1 tbsp butter","Parmesan cheese"], Pantry:["Olive oil","White wine or chicken broth","Red pepper flakes","Salt & pepper"] } },
  { id:58, emoji:"🍚", title:"Ground Turkey Rice Bowl", category:"Turkey", tags:["High Protein","Meal Prep","Budget-Friendly"], prep:"10 min", cook:"20 min", servings:5, calories:400, ingredients:["1.5 lbs ground turkey","2 cups jasmine rice (dry)","3 cloves garlic, minced","1 tbsp soy sauce","1 tbsp oyster sauce","1 tsp sesame oil","1 tsp rice vinegar","1 cup frozen edamame","2 cups shredded cabbage","2 tbsp sriracha mayo (mayo + sriracha)","Green onions","Sesame seeds"], steps:["Cook jasmine rice.","Brown turkey in pan, breaking apart, 7–8 min.","Add garlic 1 min. Add soy sauce, oyster sauce, sesame oil, rice vinegar. Toss.","Steam edamame.","Build bowls: rice, turkey, edamame, shredded cabbage.","Top with sriracha mayo, green onions, sesame seeds."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs ground turkey"], Produce:["3 cloves garlic","2 cups shredded cabbage","Green onions"], Grains:["2 cups jasmine rice"], Pantry:["Soy sauce","Oyster sauce","Sesame oil","Rice vinegar","Edamame","Sriracha","Mayo","Sesame seeds"] } },
  { id:59, emoji:"🥑", title:"Salmon Avocado Rice Bowls", category:"Seafood", tags:["High Protein","Gluten-Free","Healthy Fats"], prep:"15 min", cook:"15 min", servings:5, calories:460, ingredients:["5 salmon fillets (5 oz each)","2 cups sushi rice (dry)","2 avocados, sliced","1 cucumber, sliced into half-moons","1 cup edamame","3 tbsp soy sauce","1 tbsp rice vinegar","1 tbsp sesame oil","1 tsp honey","Sesame seeds","Pickled ginger","Wasabi (optional)","Nori strips"], steps:["Cook sushi rice. Season with rice vinegar and a pinch of salt.","Season salmon with soy sauce and sesame oil. Pan sear 3–4 min per side.","Prep avocado, cucumber, edamame.","Whisk remaining soy sauce, sesame oil, rice vinegar, honey for drizzle.","Bowl: rice, salmon, avocado, cucumber, edamame.","Top with sesame seeds, ginger, nori."], storage:"2–3 days. Add avocado fresh.", grocery:{ Protein:["5 salmon fillets (5 oz)"], Produce:["2 avocados","1 cucumber","Pickled ginger"], Grains:["2 cups sushi rice"], Pantry:["Soy sauce","Rice vinegar","Sesame oil","Honey","Sesame seeds","Edamame","Wasabi","Nori strips"] } },
  { id:60, emoji:"🌿", title:"Green Goddess Grain Bowls", category:"Vegetarian", tags:["Vegan","High Fiber","Clean Eating"], prep:"20 min", cook:"25 min", servings:5, calories:380, ingredients:["2 cups farro","2 cups broccoli florets","1 cup snap peas","1 zucchini, sliced","1 cup edamame","1 avocado","1/2 cup fresh basil","1/4 cup fresh parsley","3 tbsp olive oil","2 tbsp lemon juice","1 clove garlic","2 tbsp nutritional yeast","Salt & pepper","Pepitas"], steps:["Cook farro per package. Cool slightly.","Roast broccoli and zucchini at 425°F with olive oil and salt, 20 min.","Blanch snap peas 2 min.","Blend basil, parsley, avocado, olive oil, lemon juice, garlic, nutritional yeast, salt, pepper into dressing.","Build bowls: farro, roasted veggies, snap peas, edamame.","Drizzle green goddess dressing. Top with pepitas."], storage:"4 days. Keep dressing separate.", grocery:{ Produce:["2 cups broccoli","1 cup snap peas","1 zucchini","1 avocado","Fresh basil","Fresh parsley","1 clove garlic"], Grains:["2 cups farro"], Pantry:["Olive oil","Lemon juice","Nutritional yeast","Salt & pepper","Pepitas","Edamame"] } },
  { id:61, emoji:"🥩", title:"Chimichurri Steak Bowls", category:"Beef", tags:["High Protein","Low Carb","South American"], prep:"20 min", cook:"15 min", servings:5, calories:450, ingredients:["1.5 lbs skirt steak","2 cups brown rice","2 cups roasted corn","1 cup cherry tomatoes, halved","1 avocado, sliced","1 cup fresh parsley","1/4 cup fresh cilantro","4 cloves garlic","1/2 cup olive oil","3 tbsp red wine vinegar","1/2 tsp red pepper flakes","Salt & pepper"], steps:["Blend parsley, cilantro, garlic, olive oil, vinegar, red pepper flakes, salt into chimichurri.","Season steak with salt and pepper. Grill or sear 3–4 min per side for medium-rare. Rest 5 min.","Cook brown rice.","Roast corn on sheet pan at 425°F until slightly charred.","Slice steak against grain.","Bowl: rice, steak, corn, tomatoes, avocado. Spoon chimichurri generously over top."], storage:"4 days. Keep chimichurri separate.", grocery:{ Protein:["1.5 lbs skirt steak"], Produce:["2 cups corn","Cherry tomatoes","1 avocado","Fresh parsley","Fresh cilantro","4 cloves garlic"], Grains:["2 cups brown rice"], Pantry:["Olive oil","Red wine vinegar","Red pepper flakes","Salt & pepper"] } },
  { id:62, emoji:"🍗", title:"Chicken & Sweet Potato Meal Prep", category:"Chicken", tags:["High Protein","Gluten-Free","Clean Eating"], prep:"10 min", cook:"35 min", servings:5, calories:440, ingredients:["2 lbs chicken breast","3 large sweet potatoes, cubed","2 cups broccoli","2 tbsp olive oil","1 tsp garlic powder","1 tsp onion powder","1 tsp smoked paprika","1 tsp Italian seasoning","Salt & pepper","Lemon wedges"], steps:["Preheat oven to 400°F.","Toss sweet potato with 1 tbsp olive oil, garlic powder, salt.","Season chicken with remaining olive oil, onion powder, smoked paprika, Italian seasoning, salt, pepper.","Roast sweet potato 15 min on sheet pan.","Add chicken and broccoli to sheet pan. Roast 20–22 min more.","Portion with lemon wedges."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["3 large sweet potatoes","2 cups broccoli","Lemon"], Pantry:["Olive oil","Garlic powder","Onion powder","Smoked paprika","Italian seasoning","Salt & pepper"] } },
  { id:63, emoji:"🍖", title:"Lamb & Vegetable Tagine", category:"Beef", tags:["High Protein","Mediterranean","Meal Prep"], prep:"20 min", cook:"1.5 hrs", servings:5, calories:490, ingredients:["1.5 lbs lamb shoulder, cubed","1 onion, diced","3 cloves garlic, minced","2 carrots, sliced","1 can chickpeas, drained","1 can diced tomatoes","1/2 cup dried apricots, halved","2 cups chicken broth","1 tbsp olive oil","1 tsp cumin","1 tsp cinnamon","1 tsp coriander","1 tsp turmeric","Salt & pepper","2 cups couscous","Fresh cilantro","Toasted almonds"], steps:["Brown lamb in olive oil in batches. Remove.","Sauté onion and garlic 4 min. Add spices 1 min.","Return lamb. Add carrots, tomatoes, broth, apricots, chickpeas.","Cover and simmer 1.5 hrs until lamb is very tender.","Cook couscous in vegetable broth 5 min.","Serve tagine over couscous. Top with cilantro and almonds."], storage:"5 days. Freezes well.", grocery:{ Protein:["1.5 lbs lamb shoulder"], Produce:["1 onion","3 cloves garlic","2 carrots","Fresh cilantro"], Canned:["1 can chickpeas","1 can diced tomatoes"], Grains:["2 cups couscous"], Pantry:["Olive oil","Cumin","Cinnamon","Coriander","Turmeric","Dried apricots","Toasted almonds","Chicken broth","Salt & pepper"] } },
  { id:64, emoji:"🌿", title:"Protein Egg Fried Cauliflower Rice", category:"Vegetarian", tags:["Low Carb","High Protein","Keto-Friendly"], prep:"15 min", cook:"15 min", servings:5, calories:300, ingredients:["2 heads cauliflower, riced","6 eggs","1 cup frozen peas","1 cup shredded carrots","1/2 cup edamame","3 cloves garlic, minced","2 tbsp soy sauce","1 tbsp sesame oil","1 tbsp vegetable oil","Green onions","Salt & pepper","Sesame seeds"], steps:["Grate or process cauliflower into rice-sized pieces. Squeeze out moisture.","Heat oil in wok over high heat. Stir fry cauliflower 4–5 min until slightly golden.","Push to side. Scramble eggs.","Add garlic, peas, carrots, edamame. Stir fry 3 min.","Add soy sauce and sesame oil. Toss everything.","Garnish with green onions and sesame seeds."], storage:"4 days refrigerated.", grocery:{ Produce:["2 heads cauliflower","Shredded carrots","3 cloves garlic","Green onions"], Dairy:["6 eggs"], Pantry:["Frozen peas","Edamame","Soy sauce","Sesame oil","Vegetable oil","Sesame seeds","Salt & pepper"] } },
  { id:65, emoji:"🐟", title:"Teriyaki Salmon Rice Bowls", category:"Seafood", tags:["High Protein","Asian-Inspired","Meal Prep"], prep:"15 min", cook:"20 min", servings:5, calories:450, ingredients:["5 salmon fillets (5 oz)","1/4 cup soy sauce","2 tbsp mirin","2 tbsp honey","1 clove garlic, minced","2 cups jasmine rice","2 cups steamed broccoli","1 cup shredded carrots","Sesame seeds","Green onions","Pickled ginger"], steps:["Whisk soy sauce, mirin, honey, and garlic for teriyaki sauce.","Cook jasmine rice.","Brush salmon with sauce. Bake at 400°F 12–15 min, glazing once halfway.","Steam broccoli 4 min.","Build bowls: rice, salmon, broccoli, carrots.","Drizzle extra teriyaki. Top with sesame seeds, green onions, ginger."], storage:"3–4 days refrigerated.", grocery:{ Protein:["5 salmon fillets (5 oz)"], Produce:["2 cups broccoli","Shredded carrots","Green onions","Pickled ginger","1 clove garlic"], Grains:["2 cups jasmine rice"], Pantry:["Soy sauce","Mirin","Honey","Sesame seeds"] } },
  { id:66, emoji:"🌯", title:"Falafel Power Bowls", category:"Vegetarian", tags:["Vegan","High Fiber","Mediterranean"], prep:"20 min", cook:"25 min", servings:5, calories:420, ingredients:["2 cans chickpeas (15 oz), drained","1/4 cup flour","3 cloves garlic","1/4 cup fresh parsley","1/4 cup fresh cilantro","1 tsp cumin","1 tsp coriander","Salt & pepper","3 tbsp olive oil","2 cups couscous","1 cucumber, diced","Cherry tomatoes","1/2 cup hummus","1/4 cup tahini sauce","Lemon juice"], steps:["Blend chickpeas, flour, garlic, parsley, cilantro, cumin, coriander, salt in food processor.","Form into small patties. Pan fry in olive oil 3–4 min per side until golden.","Cook couscous in vegetable broth.","Dice cucumber, halve tomatoes.","Build bowls: couscous, falafel, cucumber, tomatoes.","Drizzle hummus and tahini sauce. Squeeze lemon juice."], storage:"4 days. Falafel stays crispy if stored separately.", grocery:{ Produce:["3 cloves garlic","Fresh parsley","Fresh cilantro","1 cucumber","Cherry tomatoes","Lemon"], Grains:["2 cups couscous"], Canned:["2 cans chickpeas"], Pantry:["Flour","Cumin","Coriander","Olive oil","Hummus","Tahini sauce","Salt & pepper"] } },
  { id:67, emoji:"🥗", title:"Chicken Caesar Meal Prep Jars", category:"Salads", tags:["High Protein","Low Carb","Classic"], prep:"20 min", cook:"20 min", servings:5, calories:360, ingredients:["2 lbs chicken breast","8 cups romaine lettuce, chopped","1/2 cup Parmesan, shaved","1 cup croutons","1/2 cup Caesar dressing (light)","2 tsp Worcestershire sauce","1 lemon, juiced","1 tsp black pepper","Salt","2 tbsp olive oil"], steps:["Season chicken with olive oil, salt, pepper. Bake at 400°F 20–22 min. Slice into strips.","Chop romaine into bite-sized pieces.","Layer in mason jars: dressing at bottom, then chicken, Parmesan, romaine.","Add croutons on top. Seal.","When ready to eat, shake jar or dump into bowl."], storage:"4 days. Croutons separate to stay crunchy.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["8 cups romaine","1 lemon"], Dairy:["Parmesan cheese"], Pantry:["Caesar dressing","Croutons","Worcestershire sauce","Olive oil","Black pepper","Salt"] } },
  { id:68, emoji:"🥩", title:"Ground Beef & Cauliflower Fried Rice", category:"Beef", tags:["Low Carb","High Protein","Keto-Friendly"], prep:"15 min", cook:"20 min", servings:5, calories:380, ingredients:["1.5 lbs ground beef (90% lean)","2 heads cauliflower, riced","3 eggs","1 cup frozen peas","1 cup shredded carrots","3 cloves garlic, minced","1 tbsp ginger, grated","3 tbsp soy sauce","1 tbsp sesame oil","1 tbsp vegetable oil","Green onions","Sesame seeds","Salt & pepper"], steps:["Grate cauliflower. Pat dry with paper towels.","Brown beef in oil, breaking apart. Remove.","Scramble eggs in same pan. Push aside.","Stir fry garlic and ginger 30 sec. Add cauliflower, peas, carrots 4 min.","Return beef. Add soy sauce and sesame oil. Toss.","Garnish with green onions and sesame seeds."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs ground beef (90% lean)"], Produce:["2 heads cauliflower","Shredded carrots","3 cloves garlic","Ginger","Green onions"], Dairy:["3 eggs"], Pantry:["Frozen peas","Soy sauce","Sesame oil","Vegetable oil","Sesame seeds","Salt & pepper"] } },
  { id:69, emoji:"🍗", title:"Za'atar Chicken & Lemon Potatoes", category:"Chicken", tags:["High Protein","Mediterranean","Sheet Pan"], prep:"15 min", cook:"40 min", servings:5, calories:450, ingredients:["2 lbs chicken thighs, bone-in","1.5 lbs baby potatoes, halved","3 tbsp za'atar spice","3 tbsp olive oil","4 cloves garlic, minced","1 lemon, sliced","1 tsp salt","1/2 tsp black pepper","1 cup cherry tomatoes","1/2 cup Kalamata olives","Fresh parsley"], steps:["Preheat oven to 425°F.","Toss potatoes with 1 tbsp olive oil, salt. Spread on sheet pan.","Rub chicken with za'atar, 2 tbsp olive oil, garlic, salt, pepper.","Place chicken on potatoes. Add lemon slices, tomatoes, olives.","Roast 35–40 min until chicken is 165°F.","Garnish with fresh parsley."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs bone-in chicken thighs"], Produce:["1.5 lbs baby potatoes","1 lemon","Cherry tomatoes","Fresh parsley","4 cloves garlic"], Pantry:["Za'atar spice","Olive oil","Kalamata olives","Salt & pepper"] } },
  { id:70, emoji:"🫘", title:"Black Bean Soup with Lime Crema", category:"Soups & Stews", tags:["Vegan","High Fiber","Budget-Friendly"], prep:"10 min", cook:"30 min", servings:5, calories:310, ingredients:["3 cans black beans (15 oz)","1 onion, diced","4 cloves garlic, minced","1 jalapeno, diced","1 can diced tomatoes","4 cups vegetable broth","1 tbsp olive oil","1 tsp cumin","1 tsp chili powder","1/2 tsp smoked paprika","Salt & pepper","Juice of 2 limes","1/2 cup sour cream (for crema)","Cilantro"], steps:["Sauté onion, garlic, and jalapeno in olive oil 4 min.","Add cumin, chili powder, paprika. Cook 1 min.","Add beans, tomatoes, and broth. Bring to boil.","Simmer 20 min. Use an immersion blender to blend half the soup.","Stir in lime juice. Season.","Mix sour cream with lime juice for crema. Serve soup topped with crema and cilantro."], storage:"5 days. Freezes well.", grocery:{ Produce:["1 onion","4 cloves garlic","1 jalapeno","2 limes","Cilantro"], Canned:["3 cans black beans","1 can diced tomatoes"], Dairy:["Sour cream"], Pantry:["Olive oil","Cumin","Chili powder","Smoked paprika","Salt & pepper","4 cups vegetable broth"] } },
  { id:71, emoji:"🐷", title:"Balsamic Glazed Pork Loin", category:"Pork", tags:["High Protein","Gluten-Free","Elegant"], prep:"15 min", cook:"30 min", servings:5, calories:420, ingredients:["2 lbs pork loin","3 tbsp balsamic vinegar","2 tbsp honey","1 tbsp Dijon mustard","2 cloves garlic, minced","1 tbsp olive oil","Salt & pepper","1 tsp rosemary","2 cups wild rice blend","1 lb asparagus"], steps:["Preheat oven to 400°F.","Season pork with olive oil, rosemary, salt, and pepper.","Sear in oven-safe pan 3 min per side until golden.","Whisk balsamic, honey, Dijon, garlic. Pour over pork.","Roast 20–25 min until 145°F internal. Rest 10 min.","Cook wild rice. Roast asparagus last 12 min.","Slice pork. Drizzle pan drippings over."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs pork loin"], Produce:["2 cloves garlic","1 lb asparagus"], Grains:["2 cups wild rice blend"], Pantry:["Balsamic vinegar","Honey","Dijon mustard","Olive oil","Rosemary","Salt & pepper"] } },
  { id:72, emoji:"🍛", title:"Thai Green Curry Chicken", category:"Chicken", tags:["High Protein","Asian-Inspired","Spicy"], prep:"15 min", cook:"25 min", servings:5, calories:470, ingredients:["2 lbs chicken breast, sliced","2 cans coconut milk (14 oz)","3 tbsp green curry paste","1 cup chicken broth","1 zucchini, sliced","1 cup broccoli","1 cup snap peas","1 red bell pepper, sliced","1 tbsp fish sauce","1 tbsp brown sugar","1 lime, juiced","Fresh Thai basil","2 cups jasmine rice"], steps:["Cook jasmine rice.","Sauté curry paste in 2 tbsp coconut milk 1–2 min.","Add coconut milk and broth. Bring to simmer.","Add chicken. Cook 8–10 min.","Add vegetables. Cook 4 min.","Stir in fish sauce, brown sugar, lime juice.","Serve over rice. Garnish with Thai basil."], storage:"4 days. Freezes well.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["1 zucchini","1 cup broccoli","1 cup snap peas","1 red bell pepper","Fresh Thai basil","1 lime"], Grains:["2 cups jasmine rice"], Canned:["2 cans coconut milk"], Pantry:["Green curry paste","Chicken broth","Fish sauce","Brown sugar"] } },
  { id:73, emoji:"🐟", title:"Fish Tacos with Mango Slaw", category:"Seafood", tags:["High Protein","Low Calorie","Fresh"], prep:"20 min", cook:"15 min", servings:5, calories:380, ingredients:["1.5 lbs white fish (tilapia or cod)","10 corn tortillas","2 cups shredded cabbage","1 mango, diced","1/4 cup red onion, diced","1/4 cup cilantro","Juice of 2 limes","1 tbsp olive oil","1 tsp cumin","1 tsp chili powder","1/2 tsp garlic powder","Salt & pepper","1/4 cup sour cream","1 tbsp sriracha"], steps:["Mix cumin, chili powder, garlic powder, salt, pepper. Rub on fish.","Cook fish in olive oil 3–4 min per side until flaky.","Toss cabbage, mango, red onion, cilantro, and lime juice for slaw.","Mix sour cream and sriracha for sauce.","Warm tortillas.","Build tacos: fish, slaw, sriracha cream."], storage:"3 days. Keep components separate. Assemble fresh.", grocery:{ Protein:["1.5 lbs white fish"], Produce:["1 mango","2 cups cabbage","1/4 red onion","Cilantro","2 limes"], Dairy:["Sour cream"], Pantry:["10 corn tortillas","Olive oil","Cumin","Chili powder","Garlic powder","Sriracha","Salt & pepper"] } },
  { id:74, emoji:"🍃", title:"Kale & White Bean Soup", category:"Soups & Stews", tags:["Vegan","High Fiber","Low Calorie"], prep:"10 min", cook:"30 min", servings:5, calories:290, ingredients:["2 cans white beans (15 oz)","4 cups chopped kale","1 onion, diced","4 cloves garlic, minced","3 carrots, sliced","3 stalks celery, sliced","1 can diced tomatoes","5 cups vegetable broth","1 tbsp olive oil","1 tsp Italian seasoning","1/2 tsp red pepper flakes","Salt & pepper","1 lemon, juiced","Parmesan rind (optional for flavor)"], steps:["Sauté onion, garlic, carrots, celery in olive oil 5 min.","Add Italian seasoning and red pepper flakes.","Add beans, tomatoes, broth, and Parmesan rind if using.","Simmer 20 min. Remove rind.","Stir in kale. Cook 3–4 min until wilted.","Add lemon juice. Season."], storage:"5 days. Freezes well.", grocery:{ Produce:["4 cups kale","1 onion","4 cloves garlic","3 carrots","3 stalks celery","1 lemon"], Canned:["2 cans white beans","1 can diced tomatoes"], Pantry:["Olive oil","Italian seasoning","Red pepper flakes","Salt & pepper","5 cups vegetable broth"] } },
  { id:75, emoji:"🥣", title:"Cottage Cheese Breakfast Bowls", category:"Vegetarian", tags:["High Protein","Low Calorie","Quick"], prep:"5 min", cook:"0 min", servings:5, calories:270, ingredients:["4 cups cottage cheese (4% fat)","5 tbsp peanut butter","5 tbsp honey","1 tsp cinnamon","2 cups blueberries","5 tbsp hemp seeds","5 tbsp flax seeds","1 tsp vanilla extract","5 bananas, sliced"], steps:["Divide cottage cheese into 5 bowls or containers.","Stir vanilla and cinnamon into each.","Top with sliced banana and blueberries.","Drizzle with honey and peanut butter.","Sprinkle hemp seeds and flax seeds."], storage:"4 days refrigerated. Top with fresh fruit before eating.", grocery:{ Produce:["2 cups blueberries","5 bananas"], Dairy:["4 cups 4% cottage cheese"], Pantry:["Peanut butter","Honey","Cinnamon","Hemp seeds","Flax seeds","Vanilla extract"] } },
  { id:76, emoji:"🍜", title:"Hoisin Beef & Noodle Bowl", category:"Beef", tags:["High Protein","Asian-Inspired","Quick"], prep:"15 min", cook:"20 min", servings:5, calories:460, ingredients:["1.5 lbs beef sirloin, sliced thin","10 oz udon noodles","3 tbsp hoisin sauce","2 tbsp soy sauce","1 tbsp sesame oil","1 tbsp rice vinegar","2 cloves garlic, minced","1 cup shredded carrots","2 cups bok choy, chopped","1 cup snap peas","Green onions","Sesame seeds","Chili oil"], steps:["Cook udon noodles. Rinse with cold water.","Mix hoisin, soy sauce, sesame oil, rice vinegar, garlic for sauce.","Sear beef in hot pan in batches 1–2 min per side. Remove.","Stir fry bok choy and snap peas 3 min.","Add noodles and sauce. Toss.","Add beef back. Toss again. Serve with carrots, green onions, sesame seeds."], storage:"3 days. Reheat with a splash of water.", grocery:{ Protein:["1.5 lbs beef sirloin"], Produce:["Shredded carrots","2 cups bok choy","1 cup snap peas","2 cloves garlic","Green onions"], Grains:["10 oz udon noodles"], Pantry:["Hoisin sauce","Soy sauce","Sesame oil","Rice vinegar","Sesame seeds","Chili oil"] } },
  { id:77, emoji:"🍗", title:"Cilantro Lime Chicken Thighs", category:"Chicken", tags:["High Protein","Gluten-Free","Quick"], prep:"10 min", cook:"25 min", servings:5, calories:400, ingredients:["2 lbs boneless chicken thighs","Juice and zest of 3 limes","1/2 cup fresh cilantro, chopped","4 cloves garlic, minced","2 tbsp olive oil","1 tsp cumin","1/2 tsp chili powder","Salt & pepper","2 cups brown rice","1 lb asparagus"], steps:["Whisk lime juice, zest, cilantro, garlic, olive oil, cumin, chili powder, salt, pepper.","Marinate chicken 20–30 min.","Grill or bake at 400°F 20–25 min until 165°F.","Cook brown rice.","Roast asparagus at 400°F 12 min.","Portion chicken over rice with asparagus."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs boneless chicken thighs"], Produce:["3 limes","Fresh cilantro","4 cloves garlic","1 lb asparagus"], Grains:["2 cups brown rice"], Pantry:["Olive oil","Cumin","Chili powder","Salt & pepper"] } },
  { id:78, emoji:"🥢", title:"Soy Garlic Noodles with Edamame", category:"Vegetarian", tags:["Vegan","Quick","Asian-Inspired"], prep:"10 min", cook:"15 min", servings:5, calories:410, ingredients:["12 oz lo mein or spaghetti noodles","2 cups edamame, shelled","1 cup shredded cabbage","1 cup shredded carrots","4 cloves garlic, minced","2 tbsp ginger, grated","1/4 cup soy sauce","2 tbsp hoisin sauce","1 tbsp sesame oil","1 tbsp vegetable oil","1 tbsp rice vinegar","1 tbsp brown sugar","Green onions","Sesame seeds","Crushed peanuts"], steps:["Cook noodles al dente. Reserve 1/4 cup pasta water.","Whisk soy sauce, hoisin, sesame oil, rice vinegar, brown sugar.","Sauté garlic and ginger in vegetable oil 1 min.","Add edamame, cabbage, and carrots. Stir fry 3 min.","Add noodles and sauce. Toss with pasta water to coat.","Garnish with green onions, sesame seeds, and crushed peanuts."], storage:"4 days. Add splash of water when reheating.", grocery:{ Produce:["4 cloves garlic","Ginger","1 cup cabbage","1 cup carrots","Green onions"], Grains:["12 oz lo mein noodles"], Pantry:["Edamame","Soy sauce","Hoisin sauce","Sesame oil","Vegetable oil","Rice vinegar","Brown sugar","Sesame seeds","Crushed peanuts"] } },
  { id:79, emoji:"🐟", title:"Mahi-Mahi Rice Bowls", category:"Seafood", tags:["High Protein","Low Calorie","Tropical"], prep:"15 min", cook:"15 min", servings:5, calories:370, ingredients:["5 mahi-mahi fillets (5 oz)","2 cups white rice","1 mango, diced","1 cup pineapple, diced","1/2 red onion, diced","1/2 cup cilantro","Juice of 2 limes","1 tbsp olive oil","1 tsp cumin","1 tsp paprika","Salt & pepper","1 avocado","Lime wedges"], steps:["Season mahi-mahi with cumin, paprika, salt, and pepper.","Cook in olive oil 3–4 min per side until flaky.","Cook white rice.","Combine mango, pineapple, red onion, cilantro, lime juice for salsa.","Build bowls: rice, mahi-mahi, mango salsa, sliced avocado.","Serve with lime wedges."], storage:"3 days. Add avocado fresh.", grocery:{ Protein:["5 mahi-mahi fillets (5 oz)"], Produce:["1 mango","1 cup pineapple","1/2 red onion","Cilantro","2 limes","1 avocado"], Grains:["2 cups white rice"], Pantry:["Olive oil","Cumin","Paprika","Salt & pepper"] } },
  { id:80, emoji:"🍠", title:"Turkey Stuffed Sweet Potatoes", category:"Turkey", tags:["High Protein","Gluten-Free","Meal Prep"], prep:"10 min", cook:"55 min", servings:5, calories:410, ingredients:["5 large sweet potatoes","1 lb ground turkey","1 can black beans, drained","1 cup corn","1 tsp cumin","1 tsp chili powder","1/2 tsp garlic powder","Salt & pepper","1 tbsp olive oil","1/2 cup shredded cheddar","1/4 cup Greek yogurt","Cilantro","Lime"], steps:["Bake sweet potatoes at 400°F 45–50 min until tender.","Brown turkey in olive oil with cumin, chili powder, garlic powder, salt, and pepper.","Add black beans and corn. Heat through.","Split open sweet potatoes. Fluff inside with fork.","Fill with turkey mixture.","Top with cheddar, Greek yogurt, cilantro, and lime squeeze."], storage:"4 days refrigerated.", grocery:{ Protein:["1 lb ground turkey"], Produce:["5 large sweet potatoes","Cilantro","Lime"], Dairy:["Shredded cheddar","Greek yogurt"], Canned:["1 can black beans","1 cup corn"], Pantry:["Olive oil","Cumin","Chili powder","Garlic powder","Salt & pepper"] } },
  { id:81, emoji:"🥗", title:"Watermelon Feta Summer Salad", category:"Salads", tags:["Vegetarian","Low Calorie","Fresh"], prep:"15 min", cook:"0 min", servings:5, calories:240, ingredients:["6 cups watermelon, cubed","1/2 cup feta cheese, crumbled","1/4 red onion, thinly sliced","1/4 cup fresh mint","1/4 cup fresh basil","2 tbsp olive oil","1 tbsp lime juice","Salt & pepper","2 cups arugula","1/4 cup pepitas"], steps:["Cube watermelon into bite-sized pieces.","Thinly slice red onion.","Tear mint and basil leaves.","Combine watermelon, arugula, onion, mint, basil.","Drizzle olive oil and lime juice. Season lightly.","Top with feta and pepitas."], storage:"2 days (best same day). Keep dressing separate.", grocery:{ Produce:["6 cups watermelon","1/4 red onion","Fresh mint","Fresh basil","2 cups arugula","1 lime"], Dairy:["1/2 cup feta cheese"], Pantry:["Olive oil","Salt & pepper","Pepitas"] } },
  { id:82, emoji:"🍝", title:"Spaghetti Squash & Meat Sauce", category:"Beef", tags:["Low Carb","High Protein","Comfort Food"], prep:"15 min", cook:"50 min", servings:5, calories:390, ingredients:["3 medium spaghetti squash","1 lb ground beef (90% lean)","1 can crushed tomatoes (28 oz)","1/2 onion, diced","3 cloves garlic, minced","1 tbsp olive oil","1 tsp Italian seasoning","1 tsp dried basil","Salt & pepper","1/4 cup Parmesan","Fresh basil"], steps:["Preheat oven to 400°F.","Halve spaghetti squash, brush with olive oil, season. Roast 40–45 min cut side down.","Brown beef with onion and garlic. Drain fat.","Add crushed tomatoes, Italian seasoning, basil, salt, pepper. Simmer 20 min.","Scrape squash strands with fork.","Top squash with meat sauce. Garnish with Parmesan and fresh basil."], storage:"4 days refrigerated.", grocery:{ Protein:["1 lb ground beef (90% lean)"], Produce:["3 medium spaghetti squash","1/2 onion","3 cloves garlic","Fresh basil"], Canned:["1 can crushed tomatoes (28 oz)"], Dairy:["Parmesan cheese"], Pantry:["Olive oil","Italian seasoning","Dried basil","Salt & pepper"] } },
  { id:83, emoji:"🥪", title:"Turkey BLT Wraps", category:"Turkey", tags:["High Protein","Quick","Low Calorie"], prep:"10 min", cook:"5 min", servings:5, calories:330, ingredients:["1 lb sliced turkey breast (deli)","10 strips turkey bacon","5 large flour tortillas","5 cups romaine lettuce","2 tomatoes, sliced","1/2 avocado, sliced","3 tbsp mayo","2 tbsp Dijon mustard","Salt & pepper"], steps:["Cook turkey bacon until crispy. Drain on paper towels.","Mix mayo and Dijon.","Lay out tortillas. Spread sauce on each.","Layer romaine, tomato, avocado, turkey, and bacon.","Season with salt and pepper.","Roll tightly. Slice in half. Wrap in parchment."], storage:"3 days. Store wrapped in parchment in fridge.", grocery:{ Protein:["1 lb sliced turkey breast","10 strips turkey bacon"], Produce:["5 cups romaine","2 tomatoes","1/2 avocado"], Pantry:["5 large flour tortillas","Mayo","Dijon mustard","Salt & pepper"] } },
  { id:84, emoji:"🍗", title:"Classic Chicken Noodle Soup", category:"Soups & Stews", tags:["High Protein","Comfort Food","Meal Prep"], prep:"15 min", cook:"40 min", servings:5, calories:350, ingredients:["1.5 lbs chicken breast","8 oz egg noodles","3 carrots, sliced","3 stalks celery, sliced","1 onion, diced","3 cloves garlic, minced","7 cups chicken broth","1 tbsp olive oil","1 tsp thyme","1 bay leaf","Salt & pepper","Fresh parsley"], steps:["Sauté onion, carrot, celery in olive oil 5 min.","Add garlic 1 min.","Add chicken breasts, broth, thyme, and bay leaf. Bring to boil.","Reduce and simmer 25 min until chicken is cooked.","Remove chicken, shred, return to pot.","Add egg noodles. Cook 7–8 min.","Season. Garnish with parsley."], storage:"4 days. Noodles absorb liquid — add broth when reheating.", grocery:{ Protein:["1.5 lbs chicken breast"], Produce:["3 carrots","3 stalks celery","1 onion","3 cloves garlic","Fresh parsley"], Grains:["8 oz egg noodles"], Pantry:["Olive oil","Thyme","Bay leaf","Salt & pepper","7 cups chicken broth"] } },
  { id:85, emoji:"🥜", title:"Peanut Chicken Rice Bowls", category:"Chicken", tags:["High Protein","Asian-Inspired","Meal Prep"], prep:"15 min", cook:"25 min", servings:5, calories:470, ingredients:["2 lbs chicken breast, cubed","1/2 cup peanut butter","3 tbsp soy sauce","2 tbsp lime juice","1 tbsp sesame oil","1 tbsp honey","1 tsp ginger, grated","2 cloves garlic, minced","1/4 cup warm water","2 cups jasmine rice","2 cups steamed broccoli","Shredded carrots","Crushed peanuts","Cilantro"], steps:["Whisk peanut butter, soy sauce, lime juice, sesame oil, honey, ginger, garlic, and warm water.","Cook chicken in 1 tbsp oil 5–6 min until cooked. Toss with 1/3 of the sauce.","Cook jasmine rice.","Steam broccoli.","Build bowls: rice, chicken, broccoli, carrots.","Drizzle remaining peanut sauce. Top with crushed peanuts and cilantro."], storage:"4 days. Keep sauce separate if possible.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["2 cups broccoli","Shredded carrots","2 cloves garlic","Ginger","Cilantro","1 lime"], Grains:["2 cups jasmine rice"], Pantry:["Peanut butter","Soy sauce","Sesame oil","Honey","Crushed peanuts"] } },
  { id:86, emoji:"🐟", title:"Blackened Salmon Power Bowls", category:"Seafood", tags:["High Protein","Low Calorie","Cajun"], prep:"15 min", cook:"15 min", servings:5, calories:430, ingredients:["5 salmon fillets (5 oz)","2 cups brown rice","2 cups kale, massaged","1 cup cherry tomatoes, halved","1 avocado, sliced","1/4 cup red onion, diced","2 tsp paprika","1 tsp cumin","1 tsp garlic powder","1/2 tsp cayenne","Salt & pepper","2 tbsp olive oil","2 tbsp lemon juice","1 tbsp honey"], steps:["Mix paprika, cumin, garlic powder, cayenne, salt, pepper for blackening spice.","Coat salmon liberally in spice blend.","Sear in olive oil 3–4 min per side until cooked.","Cook brown rice.","Massage kale with lemon juice and a pinch of salt until tender.","Build bowls: rice, kale, salmon, tomatoes, avocado, onion.","Drizzle honey-lemon dressing."], storage:"3–4 days refrigerated.", grocery:{ Protein:["5 salmon fillets (5 oz)"], Produce:["2 cups kale","Cherry tomatoes","1 avocado","1/4 red onion","Lemon"], Grains:["2 cups brown rice"], Pantry:["Olive oil","Paprika","Cumin","Garlic powder","Cayenne","Honey","Salt & pepper"] } },
  { id:87, emoji:"🥗", title:"Roasted Beet & Goat Cheese Salad", category:"Salads", tags:["Vegetarian","Low Calorie","Elegant"], prep:"15 min", cook:"45 min", servings:5, calories:310, ingredients:["5 medium beets, roasted","5 cups arugula","1/2 cup goat cheese, crumbled","1/2 cup candied walnuts","1/4 red onion, thinly sliced","3 tbsp olive oil","2 tbsp balsamic vinegar","1 tsp honey","1 tsp Dijon mustard","Salt & pepper","Orange, segmented"], steps:["Wrap beets in foil. Roast at 400°F 45 min. Cool, peel, dice.","Whisk olive oil, balsamic, honey, Dijon, salt, pepper for dressing.","Arrange arugula in containers.","Top with beets, orange segments, red onion, goat cheese, and walnuts.","Dress right before eating."], storage:"4 days undressed. Add goat cheese fresh.", grocery:{ Produce:["5 medium beets","5 cups arugula","1/4 red onion","1 orange"], Dairy:["Goat cheese"], Pantry:["Candied walnuts","Olive oil","Balsamic vinegar","Honey","Dijon mustard","Salt & pepper"] } },
  { id:88, emoji:"🌶️", title:"Chicken Fajita Bowls", category:"Chicken", tags:["High Protein","Gluten-Free","Mexican"], prep:"15 min", cook:"20 min", servings:5, calories:430, ingredients:["2 lbs chicken breast, sliced","3 bell peppers (mixed), sliced","1 large onion, sliced","2 cups white rice","1 can black beans","2 tbsp olive oil","1 tsp cumin","1 tsp chili powder","1 tsp garlic powder","1/2 tsp smoked paprika","Salt & pepper","Lime juice","Cilantro","Sour cream","Shredded cheddar"], steps:["Toss chicken, peppers, and onion with olive oil and all spices.","Sear in hot pan in batches 5–6 min until chicken is 165°F.","Cook white rice.","Warm black beans.","Build bowls: rice, beans, fajita chicken and peppers.","Top with sour cream, cheddar, cilantro, and lime juice."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["3 bell peppers","1 large onion","Lime","Cilantro"], Grains:["2 cups white rice"], Canned:["1 can black beans"], Dairy:["Sour cream","Shredded cheddar"], Pantry:["Olive oil","Cumin","Chili powder","Garlic powder","Smoked paprika","Salt & pepper"] } },
  { id:89, emoji:"🍲", title:"Tuscan White Bean & Sausage Soup", category:"Pork", tags:["High Protein","Comfort Food","Italian"], prep:"15 min", cook:"30 min", servings:5, calories:420, ingredients:["1 lb Italian turkey sausage, sliced","2 cans white beans (15 oz)","4 cups kale, chopped","1 onion, diced","4 cloves garlic, minced","1 can diced tomatoes","5 cups chicken broth","1 tbsp olive oil","1 tsp Italian seasoning","1/4 tsp red pepper flakes","Salt & pepper","Parmesan rind","Fresh parsley"], steps:["Brown sausage in olive oil in large pot. Remove.","Sauté onion and garlic 4 min.","Add tomatoes, broth, beans, Italian seasoning, red pepper flakes, Parmesan rind.","Simmer 15 min.","Add sausage back and kale. Simmer 5 min until kale wilts.","Season. Remove rind. Garnish with parsley."], storage:"5 days. Freezes well.", grocery:{ Protein:["1 lb Italian turkey sausage"], Produce:["4 cups kale","1 onion","4 cloves garlic","Fresh parsley"], Canned:["2 cans white beans","1 can diced tomatoes"], Pantry:["Olive oil","Italian seasoning","Red pepper flakes","Salt & pepper","5 cups chicken broth"] } },
  { id:90, emoji:"🍚", title:"Pork Fried Rice", category:"Pork", tags:["High Protein","Asian-Inspired","Meal Prep"], prep:"10 min", cook:"20 min", servings:5, calories:440, ingredients:["1 lb pork tenderloin, diced","4 cups cooked jasmine rice (day-old)","3 eggs","1 cup frozen peas","1 cup shredded carrots","3 cloves garlic, minced","2 tbsp soy sauce","1 tbsp oyster sauce","1 tsp sesame oil","1 tbsp vegetable oil","Green onions","Salt & pepper","Sesame seeds"], steps:["Cook pork in vegetable oil until browned 5–6 min. Remove.","Scramble eggs in same pan. Push aside.","Add garlic, peas, carrots. Stir fry 3 min.","Add rice. Stir fry 3 min.","Return pork. Add soy sauce, oyster sauce, sesame oil. Toss.","Garnish with green onions and sesame seeds."], storage:"4 days refrigerated.", grocery:{ Protein:["1 lb pork tenderloin"], Produce:["Shredded carrots","3 cloves garlic","Green onions"], Dairy:["3 eggs"], Grains:["4 cups jasmine rice"], Pantry:["Frozen peas","Soy sauce","Oyster sauce","Sesame oil","Vegetable oil","Sesame seeds","Salt & pepper"] } },
  { id:91, emoji:"🍤", title:"Shrimp Tacos with Chipotle Slaw", category:"Seafood", tags:["High Protein","Low Calorie","Spicy"], prep:"20 min", cook:"10 min", servings:5, calories:360, ingredients:["1.5 lbs shrimp, peeled","10 corn tortillas","2 cups shredded cabbage","1/4 cup cilantro","Juice of 2 limes","1 chipotle pepper in adobo, minced","3 tbsp mayo","1 tsp honey","2 tsp olive oil","1 tsp cumin","1 tsp smoked paprika","Salt & pepper","1 avocado"], steps:["Season shrimp with cumin, smoked paprika, salt, and pepper.","Cook in olive oil 1–2 min per side. Remove from heat.","Mix mayo, chipotle, honey, and lime juice for sauce.","Toss cabbage and cilantro with half the chipotle sauce.","Warm tortillas.","Build tacos: cabbage slaw, shrimp, avocado, extra sauce."], storage:"3 days. Keep components separate. Assemble fresh.", grocery:{ Protein:["1.5 lbs shrimp"], Produce:["2 cups cabbage","Cilantro","2 limes","1 avocado"], Canned:["Chipotle peppers in adobo"], Pantry:["10 corn tortillas","Mayo","Honey","Olive oil","Cumin","Smoked paprika","Salt & pepper"] } },
  { id:92, emoji:"🥢", title:"Spring Roll Bowls with Peanut Sauce", category:"Vegetarian", tags:["Vegan","Low Calorie","Fresh"], prep:"20 min", cook:"15 min", servings:5, calories:350, ingredients:["2 cups brown rice","1 cup shredded purple cabbage","1 cup shredded carrots","1 cucumber, julienned","1 cup edamame","1 cup mango, sliced","Fresh mint and basil","1/2 cup peanut butter","3 tbsp soy sauce","2 tbsp lime juice","1 tbsp honey","1 tsp sesame oil","1 tsp sriracha","1 tsp ginger, grated","Crushed peanuts"], steps:["Cook brown rice. Cool.","Prep all vegetables and mango.","Whisk peanut butter, soy sauce, lime juice, honey, sesame oil, sriracha, ginger. Thin with warm water.","Build bowls: rice, cabbage, carrots, cucumber, edamame, mango.","Drizzle peanut sauce generously.","Garnish with fresh mint, basil, and crushed peanuts."], storage:"4 days. Keep sauce and fresh herbs separate.", grocery:{ Produce:["Purple cabbage","Carrots","1 cucumber","1 mango","Fresh mint","Fresh basil","1 lime","Ginger"], Grains:["2 cups brown rice"], Pantry:["Edamame","Peanut butter","Soy sauce","Honey","Sesame oil","Sriracha","Crushed peanuts"] } },
  { id:93, emoji:"🍋", title:"Greek Lemon Chicken Orzo", category:"Chicken", tags:["High Protein","Mediterranean","Comfort Food"], prep:"15 min", cook:"30 min", servings:5, calories:460, ingredients:["2 lbs chicken breast, cubed","2 cups orzo","1 onion, diced","4 cloves garlic, minced","3 cups chicken broth","2 cups baby spinach","Juice and zest of 2 lemons","3 tbsp olive oil","1 tsp dried oregano","Salt & pepper","1/2 cup Parmesan","Fresh parsley","Cherry tomatoes"], steps:["Season and sear chicken in olive oil 4–5 min per side. Remove.","Sauté onion and garlic 3 min.","Add orzo. Toast 2 min.","Add broth, lemon juice, zest, and oregano. Bring to boil.","Stir in chicken. Cook 10 min until orzo is done.","Stir in spinach until wilted. Add Parmesan and parsley."], storage:"4 days. Orzo absorbs liquid — add broth when reheating.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["1 onion","4 cloves garlic","2 lemons","2 cups baby spinach","Fresh parsley","Cherry tomatoes"], Grains:["2 cups orzo"], Dairy:["Parmesan cheese"], Pantry:["Olive oil","Dried oregano","Salt & pepper","3 cups chicken broth"] } },
  { id:94, emoji:"🫓", title:"Chicken Gyro Bowls", category:"Chicken", tags:["High Protein","Mediterranean","Meal Prep"], prep:"20 min", cook:"25 min", servings:5, calories:440, ingredients:["2 lbs chicken thighs, boneless","2 cups couscous","1 cucumber, diced","2 cups cherry tomatoes, halved","1/4 cup red onion, sliced","1/2 cup Kalamata olives","1/2 cup feta cheese","1/2 cup tzatziki","1 tbsp olive oil","1 tsp oregano","1 tsp garlic powder","1 tsp paprika","Salt & pepper","Lemon juice","Fresh dill"], steps:["Mix olive oil, oregano, garlic powder, paprika, salt, and pepper. Marinate chicken 15 min.","Grill or bake chicken 20–25 min until 165°F. Rest, then slice thin.","Cook couscous in vegetable broth.","Prep cucumber, tomatoes, red onion, olives.","Build bowls: couscous, chicken, vegetables, feta.","Drizzle tzatziki. Sprinkle fresh dill."], storage:"4 days. Keep tzatziki separate.", grocery:{ Protein:["2 lbs boneless chicken thighs"], Produce:["1 cucumber","Cherry tomatoes","1/4 red onion","Lemon","Fresh dill"], Grains:["2 cups couscous"], Dairy:["Feta cheese","Tzatziki"], Pantry:["Olive oil","Oregano","Garlic powder","Paprika","Kalamata olives","Salt & pepper"] } },
  { id:95, emoji:"🍤", title:"Shrimp & Cauliflower Grits", category:"Seafood", tags:["High Protein","Low Carb","Southern-Style"], prep:"15 min", cook:"25 min", servings:5, calories:340, ingredients:["1.5 lbs shrimp, peeled","2 heads cauliflower, riced","1/4 cup Parmesan, grated","2 tbsp butter","4 strips turkey bacon, diced","3 cloves garlic, minced","1/2 cup chicken broth","1 tsp paprika","1/2 tsp cayenne","Salt & pepper","Green onions","Lemon juice"], steps:["Steam or microwave riced cauliflower 5 min. Drain moisture.","Mix hot cauliflower with Parmesan and butter. Season. This is your 'grits'.","Cook bacon until crispy. Remove.","Sauté garlic in bacon fat 1 min.","Add shrimp with paprika, cayenne, salt. Cook 2 min per side.","Add broth and lemon juice. Simmer 2 min.","Serve shrimp over cauliflower grits. Top with bacon and green onions."], storage:"3 days refrigerated.", grocery:{ Protein:["1.5 lbs shrimp","4 strips turkey bacon"], Produce:["2 heads cauliflower","3 cloves garlic","Green onions","Lemon"], Dairy:["Parmesan cheese","2 tbsp butter"], Pantry:["Chicken broth","Paprika","Cayenne","Salt & pepper"] } },
  { id:96, emoji:"🌾", title:"Barley & Mushroom Risotto Bowl", category:"Vegetarian", tags:["Vegetarian","High Fiber","Comfort Food"], prep:"15 min", cook:"45 min", servings:5, calories:390, ingredients:["2 cups pearl barley","3 cups cremini mushrooms, sliced","1 onion, diced","3 cloves garlic, minced","1/2 cup white wine (or broth)","5 cups vegetable broth","2 tbsp olive oil","1 tbsp butter","1/2 cup Parmesan, grated","Fresh thyme","Salt & pepper","Truffle oil (optional)","Fresh parsley"], steps:["Sauté onion in olive oil 4 min.","Add mushrooms. Cook until golden, 6 min.","Add garlic and thyme 1 min.","Add barley. Toast 2 min.","Add wine, stir until absorbed.","Add broth one cup at a time, stirring, about 30–35 min.","Stir in butter and Parmesan. Season. Drizzle truffle oil if using."], storage:"4 days. Add broth when reheating.", grocery:{ Produce:["3 cups cremini mushrooms","1 onion","3 cloves garlic","Fresh thyme","Fresh parsley"], Grains:["2 cups pearl barley"], Dairy:["Parmesan cheese","1 tbsp butter"], Pantry:["Olive oil","White wine or broth","Truffle oil","Salt & pepper","5 cups vegetable broth"] } },
  { id:97, emoji:"🥩", title:"Slow Cooker Pulled Beef Bowls", category:"Beef", tags:["High Protein","Meal Prep","Comfort Food"], prep:"15 min", cook:"8 hrs", servings:5, calories:500, ingredients:["2 lbs beef chuck roast","1 onion, sliced","4 cloves garlic","1 cup beef broth","1/4 cup soy sauce","2 tbsp tomato paste","1 tbsp Worcestershire sauce","1 tsp smoked paprika","1 tsp cumin","Salt & pepper","2 cups white rice","2 cups broccoli","Pickled jalapeños"], steps:["Season beef with salt, pepper, smoked paprika, and cumin.","Place onion and garlic in slow cooker. Add beef on top.","Mix broth, soy sauce, tomato paste, and Worcestershire. Pour over.","Cook on low 8 hrs or high 4 hrs.","Shred beef with forks. Toss in juices.","Serve over rice with steamed broccoli and pickled jalapeños."], storage:"5 days. Freezes very well.", grocery:{ Protein:["2 lbs beef chuck roast"], Produce:["1 onion","4 cloves garlic","2 cups broccoli"], Grains:["2 cups white rice"], Pantry:["Beef broth","Soy sauce","Tomato paste","Worcestershire sauce","Smoked paprika","Cumin","Pickled jalapeños","Salt & pepper"] } },
  { id:98, emoji:"🌶️", title:"Spicy Italian Sausage & Peppers", category:"Pork", tags:["High Protein","Italian","Comfort Food"], prep:"10 min", cook:"25 min", servings:5, calories:450, ingredients:["1.5 lbs Italian turkey sausage links","3 bell peppers (mixed), sliced","1 onion, sliced","3 cloves garlic, minced","1 can diced tomatoes","1 tbsp olive oil","1 tsp Italian seasoning","1/2 tsp red pepper flakes","Salt & pepper","2 cups white rice","Fresh basil","Parmesan"], steps:["Brown sausage links in olive oil 4 min per side. Slice.","Sauté peppers and onion in same pan 5 min.","Add garlic 1 min.","Add tomatoes, Italian seasoning, red pepper flakes, salt, pepper. Simmer 10 min.","Return sausage to sauce. Simmer 5 more min.","Serve over rice. Garnish with basil and Parmesan."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs Italian turkey sausage"], Produce:["3 bell peppers","1 onion","3 cloves garlic","Fresh basil"], Canned:["1 can diced tomatoes"], Grains:["2 cups white rice"], Dairy:["Parmesan cheese"], Pantry:["Olive oil","Italian seasoning","Red pepper flakes","Salt & pepper"] } },
  { id:99, emoji:"🍋", title:"Chicken Piccata with Capers", category:"Chicken", tags:["High Protein","Italian","Low Carb"], prep:"15 min", cook:"20 min", servings:5, calories:390, ingredients:["2 lbs chicken breast, pounded thin","1/4 cup flour","2 tbsp olive oil","2 tbsp butter","4 cloves garlic, minced","1/2 cup white wine or broth","1/2 cup chicken broth","3 tbsp lemon juice","3 tbsp capers","Salt & pepper","Fresh parsley","2 cups couscous"], steps:["Season chicken with salt and pepper. Dredge in flour.","Sear in olive oil 3 min per side until golden. Remove.","Sauté garlic in butter 1 min.","Add wine, broth, lemon juice, and capers. Simmer 3 min.","Return chicken. Simmer 5 min.","Cook couscous. Serve chicken over couscous with sauce and parsley."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["4 cloves garlic","Lemon juice","Fresh parsley"], Grains:["2 cups couscous"], Dairy:["2 tbsp butter"], Pantry:["Flour","Olive oil","White wine or broth","Chicken broth","Capers","Salt & pepper"] } },
  { id:100, emoji:"🥦", title:"Ultimate Stir Fry Meal Prep", category:"Vegetarian", tags:["Vegan","Quick","High Fiber"], prep:"20 min", cook:"15 min", servings:5, calories:360, ingredients:["2 blocks firm tofu, cubed","2 cups broccoli","1 red bell pepper, sliced","1 cup snap peas","2 cups bok choy","3 cups shredded cabbage","3 cloves garlic, minced","1 tbsp ginger, grated","1/4 cup soy sauce","2 tbsp hoisin sauce","1 tbsp sesame oil","1 tbsp vegetable oil","2 cups brown rice","Sesame seeds","Green onions"], steps:["Cook brown rice.","Press and cube tofu. Pan fry in vegetable oil until golden on all sides, 8–10 min. Remove.","Stir fry all vegetables 4–5 min.","Add garlic and ginger 1 min.","Whisk soy sauce, hoisin, sesame oil. Pour over vegetables.","Add tofu. Toss. Serve over rice with sesame seeds and green onions."], storage:"4 days refrigerated.", grocery:{ Protein:["2 blocks firm tofu"], Produce:["2 cups broccoli","1 red bell pepper","1 cup snap peas","2 cups bok choy","3 cups cabbage","3 cloves garlic","Ginger","Green onions"], Grains:["2 cups brown rice"], Pantry:["Soy sauce","Hoisin sauce","Sesame oil","Vegetable oil","Sesame seeds"] } },

  { id:101, emoji:"🍤", title:"Cajun Shrimp & Rice", category:"Seafood", tags:["High Protein","Cajun","Spicy"], prep:"10 min", cook:"20 min", servings:5, calories:400, ingredients:["1.5 lbs shrimp, peeled","2 cups long grain rice","1 bell pepper, diced","1 onion, diced","3 cloves garlic, minced","2 tbsp olive oil","2 tsp Cajun seasoning","1 tsp smoked paprika","1/2 tsp cayenne","1 can diced tomatoes","2 cups chicken broth","Salt & pepper","Green onions","Parsley"], steps:["Cook rice in chicken broth for extra flavor.","Sauté onion and bell pepper in olive oil 4 min.","Add garlic 1 min.","Season shrimp with Cajun seasoning, paprika, cayenne.","Add shrimp to pan. Cook 2 min per side.","Add diced tomatoes. Simmer 5 min. Season.","Serve over rice. Top with green onions and parsley."], storage:"3 days refrigerated.", grocery:{ Protein:["1.5 lbs shrimp"], Produce:["1 bell pepper","1 onion","3 cloves garlic","Green onions","Parsley"], Grains:["2 cups long grain rice"], Canned:["1 can diced tomatoes"], Pantry:["Olive oil","Cajun seasoning","Smoked paprika","Cayenne","Chicken broth","Salt & pepper"] } },
  { id:102, emoji:"🌽", title:"Mexican Beef Bowls with Street Corn", category:"Beef", tags:["High Protein","Mexican","Meal Prep"], prep:"20 min", cook:"20 min", servings:5, calories:490, ingredients:["1.5 lbs ground beef (90% lean)","2 cups white rice","2 cans corn, drained","1/4 cup mayo","1/4 cup cotija cheese","1 tsp chili powder","1/4 cup cilantro","Juice of 1 lime","1 can black beans","1 tbsp olive oil","1 tsp cumin","1 tsp garlic powder","Salt & pepper","Lime crema: 3 tbsp sour cream + 1 tbsp lime juice"], steps:["Cook rice.","Brown beef with cumin, garlic powder, chili powder, salt, and pepper. Drain fat.","For street corn: toss corn with mayo, half the cotija, chili powder, cilantro, lime juice.","Char corn in dry pan 3–4 min.","Warm black beans.","Build bowls: rice, beef, beans, street corn.","Top with lime crema, remaining cotija, and cilantro."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs ground beef (90% lean)"], Produce:["Cilantro","1 lime"], Grains:["2 cups white rice"], Canned:["2 cans corn","1 can black beans"], Dairy:["Mayo","Cotija cheese","Sour cream"], Pantry:["Olive oil","Cumin","Garlic powder","Chili powder","Salt & pepper"] } },
  { id:103, emoji:"🫘", title:"Red Lentil Dal", category:"Vegetarian", tags:["Vegan","High Fiber","Indian"], prep:"10 min", cook:"35 min", servings:5, calories:320, ingredients:["2 cups red lentils","1 onion, diced","4 cloves garlic, minced","1 tbsp ginger, grated","1 can diced tomatoes","1 can coconut milk (lite)","3 cups vegetable broth","1 tbsp olive oil","1.5 tsp cumin","1 tsp turmeric","1 tsp coriander","1/2 tsp garam masala","Salt & pepper","2 cups basmati rice","Cilantro","Lime wedges"], steps:["Sauté onion in olive oil 4 min.","Add garlic and ginger 1 min.","Add all spices 1 min until fragrant.","Add lentils, tomatoes, coconut milk, and broth. Bring to boil.","Reduce and simmer 25–30 min until lentils break down.","Season with salt and pepper.","Cook basmati rice. Serve dal over rice. Garnish with cilantro and lime."], storage:"5 days. Freezes well.", grocery:{ Produce:["1 onion","4 cloves garlic","Ginger","Cilantro","Lime"], Grains:["2 cups red lentils","2 cups basmati rice"], Canned:["1 can diced tomatoes","1 can lite coconut milk"], Pantry:["Olive oil","Cumin","Turmeric","Coriander","Garam masala","Salt & pepper","3 cups vegetable broth"] } },
  { id:104, emoji:"🍖", title:"BBQ Pulled Pork Bowls", category:"Pork", tags:["High Protein","Meal Prep","Comfort Food"], prep:"15 min", cook:"8 hrs", servings:5, calories:520, ingredients:["2 lbs pork shoulder","1 cup BBQ sauce (low sugar)","1/2 cup apple cider vinegar","1 tsp smoked paprika","1 tsp garlic powder","1 tsp onion powder","Salt & pepper","2 cups white rice","2 cups coleslaw mix","2 tbsp mayo","1 tbsp apple cider vinegar (for slaw)","1 tsp honey"], steps:["Season pork with smoked paprika, garlic powder, onion powder, salt, and pepper.","Slow cook with apple cider vinegar 8 hrs low or 4 hrs high.","Shred pork. Mix with BBQ sauce.","Mix coleslaw with mayo, apple cider vinegar, honey, salt. Refrigerate.","Cook white rice.","Build bowls: rice, pulled pork, coleslaw."], storage:"5 days. Pork freezes very well.", grocery:{ Protein:["2 lbs pork shoulder"], Produce:["2 cups coleslaw mix"], Grains:["2 cups white rice"], Pantry:["BBQ sauce","Apple cider vinegar","Smoked paprika","Garlic powder","Onion powder","Mayo","Honey","Salt & pepper"] } },
  { id:105, emoji:"🥗", title:"Salmon Kale Caesar Salad", category:"Salads", tags:["High Protein","Low Carb","Omega-3 Rich"], prep:"20 min", cook:"15 min", servings:5, calories:410, ingredients:["5 salmon fillets (4 oz)","6 cups kale, massaged","1/2 cup Parmesan, shaved","1 cup croutons","1/2 cup light Caesar dressing","2 tbsp lemon juice","1 tsp black pepper","2 tbsp olive oil","Salt","1 tsp garlic powder"], steps:["Season salmon with olive oil, garlic powder, salt, and pepper.","Bake at 400°F 12–14 min.","Massage kale with lemon juice and a pinch of salt until tender.","Toss kale with Caesar dressing.","Top with salmon, Parmesan, and croutons."], storage:"4 days undressed. Add croutons before eating.", grocery:{ Protein:["5 salmon fillets (4 oz)"], Produce:["6 cups kale","Lemon"], Dairy:["Parmesan cheese"], Pantry:["Light Caesar dressing","Croutons","Olive oil","Garlic powder","Black pepper","Salt"] } },
  { id:106, emoji:"🍝", title:"Chicken Alfredo Pasta Prep", category:"Chicken", tags:["High Protein","Comfort Food","Creamy"], prep:"15 min", cook:"25 min", servings:5, calories:530, ingredients:["2 lbs chicken breast","12 oz fettuccine","2 tbsp butter","3 cloves garlic, minced","1.5 cups 2% milk","3/4 cup Parmesan, grated","2 tbsp flour","1 tbsp olive oil","Salt & pepper","1 tsp garlic powder","2 cups broccoli florets","Fresh parsley"], steps:["Season chicken with olive oil, garlic powder, salt, and pepper. Bake at 400°F 22 min.","Cook fettuccine al dente. Reserve 1 cup pasta water.","In a pan, melt butter. Add garlic 1 min.","Whisk in flour 1 min. Slowly add milk whisking constantly.","Stir in Parmesan. Season. Thin with pasta water.","Steam broccoli. Slice chicken.","Toss pasta with sauce, broccoli, and chicken. Top with parsley."], storage:"4 days. Sauce thickens — add milk when reheating.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["3 cloves garlic","2 cups broccoli","Fresh parsley"], Grains:["12 oz fettuccine"], Dairy:["2 tbsp butter","1.5 cups 2% milk","Parmesan cheese"], Pantry:["Olive oil","Flour","Garlic powder","Salt & pepper"] } },
  { id:107, emoji:"🥩", title:"Steak & Chimichurri Wraps", category:"Beef", tags:["High Protein","Low Carb","Quick"], prep:"20 min", cook:"15 min", servings:5, calories:430, ingredients:["1.5 lbs flank steak","5 large whole wheat tortillas","1 cup arugula","1 cup cherry tomatoes, halved","1/2 avocado, sliced","1/2 cup fresh parsley","1/4 cup fresh cilantro","4 cloves garlic","1/2 cup olive oil","3 tbsp red wine vinegar","1/2 tsp red pepper flakes","Salt & pepper"], steps:["Blend parsley, cilantro, garlic, olive oil, red wine vinegar, red pepper flakes, salt for chimichurri.","Season steak with salt and pepper.","Grill or sear steak 3–4 min per side for medium-rare. Rest 5 min. Slice thin.","Warm tortillas.","Layer: arugula, tomatoes, avocado, steak slices.","Drizzle chimichurri generously. Roll tightly."], storage:"3 days. Keep chimichurri separate. Assemble fresh.", grocery:{ Protein:["1.5 lbs flank steak"], Produce:["1 cup arugula","Cherry tomatoes","1/2 avocado","Fresh parsley","Fresh cilantro","4 cloves garlic"], Pantry:["5 whole wheat tortillas","Olive oil","Red wine vinegar","Red pepper flakes","Salt & pepper"] } },
  { id:108, emoji:"🦃", title:"Herb Turkey Meatloaf Slices", category:"Turkey", tags:["High Protein","Comfort Food","Meal Prep"], prep:"20 min", cook:"55 min", servings:5, calories:380, ingredients:["1.5 lbs ground turkey","1/2 cup breadcrumbs","1 egg","1/2 onion, finely grated","3 cloves garlic, minced","1/4 cup milk","1 tbsp Worcestershire sauce","1 tsp Italian seasoning","1 tsp thyme","Salt & pepper","3 tbsp ketchup","1 tbsp brown sugar","1 tbsp apple cider vinegar","2 cups mashed sweet potato","1 cup green beans"], steps:["Preheat oven to 375°F.","Mix turkey, breadcrumbs, egg, onion, garlic, milk, Worcestershire, Italian seasoning, thyme, salt, pepper.","Form into loaf in a baking dish.","Mix ketchup, brown sugar, and vinegar for glaze. Spread on top.","Bake 50–55 min until 165°F internal.","Let rest 10 min. Slice. Portion with mashed sweet potato and green beans."], storage:"4 days refrigerated. Meatloaf freezes well.", grocery:{ Protein:["1.5 lbs ground turkey"], Produce:["1/2 onion","3 cloves garlic","2 cups sweet potato","1 cup green beans"], Dairy:["1 egg","1/4 cup milk"], Pantry:["Breadcrumbs","Worcestershire sauce","Italian seasoning","Thyme","Ketchup","Brown sugar","Apple cider vinegar","Salt & pepper"] } },
  { id:109, emoji:"🧀", title:"French Onion Chicken Bake", category:"Chicken", tags:["High Protein","Comfort Food","Low Carb"], prep:"20 min", cook:"45 min", servings:5, calories:460, ingredients:["2 lbs chicken breast","2 large onions, thinly sliced","2 tbsp butter","1 tbsp olive oil","1/2 cup beef broth","1/4 cup white wine (or more broth)","1 tbsp Worcestershire sauce","1 tsp thyme","1 cup Gruyère or Swiss, shredded","Salt & pepper","Fresh thyme for garnish","2 cups wild rice blend"], steps:["Caramelize onions in butter and olive oil over low heat 25–30 min.","Add wine, broth, Worcestershire, thyme. Simmer 5 min.","Season chicken with salt and pepper. Place in baking dish.","Top with caramelized onions.","Cover with Gruyère.","Bake at 375°F 25–30 min until bubbly. Cook wild rice. Serve together."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["2 large onions","Fresh thyme"], Grains:["2 cups wild rice blend"], Dairy:["2 tbsp butter","Gruyère or Swiss cheese"], Pantry:["Olive oil","Beef broth","White wine or broth","Worcestershire sauce","Thyme","Salt & pepper"] } },
  { id:110, emoji:"🍜", title:"Beef Pho-Inspired Bowls", category:"Beef", tags:["High Protein","Asian-Inspired","Comfort Food"], prep:"20 min", cook:"30 min", servings:5, calories:420, ingredients:["1.5 lbs beef sirloin, paper thin sliced","8 oz rice noodles","6 cups beef broth","1 onion, halved","3 cloves garlic","2 inches ginger","3 star anise","2 cinnamon sticks","1 tbsp fish sauce","1 tbsp soy sauce","Bean sprouts","Fresh basil","Cilantro","Lime wedges","Sriracha","Hoisin sauce"], steps:["Char onion and ginger under broiler 5 min for smoky flavor.","Add to broth with garlic, star anise, cinnamon sticks. Simmer 25 min. Strain.","Season broth with fish sauce and soy sauce.","Cook rice noodles. Divide among bowls.","Pour hot broth over noodles. The heat will cook the raw beef.","Lay beef slices on top. Add sprouts, basil, cilantro, lime.","Serve with sriracha and hoisin."], storage:"3 days. Keep broth separate from noodles and toppings.", grocery:{ Protein:["1.5 lbs beef sirloin, thin sliced"], Produce:["1 onion","3 cloves garlic","Ginger","Bean sprouts","Fresh basil","Cilantro","Lime"], Grains:["8 oz rice noodles"], Pantry:["Beef broth","Fish sauce","Soy sauce","Star anise","Cinnamon sticks","Sriracha","Hoisin sauce"] } },
  { id:111, emoji:"🥦", title:"Ground Turkey Veggie Skillet", category:"Turkey", tags:["High Protein","Low Carb","Quick"], prep:"10 min", cook:"20 min", servings:5, calories:360, ingredients:["1.5 lbs ground turkey","2 cups broccoli florets","1 zucchini, diced","1 red bell pepper, diced","1/2 onion, diced","3 cloves garlic, minced","2 tbsp soy sauce","1 tbsp sesame oil","1 tsp garlic powder","1 tsp onion powder","Salt & pepper","1 tbsp olive oil","2 cups brown rice","Sesame seeds"], steps:["Cook brown rice.","Brown turkey in olive oil, breaking apart, 7–8 min.","Add onion and bell pepper 3 min.","Add garlic 1 min.","Add broccoli and zucchini 4 min.","Add soy sauce, sesame oil, garlic powder, onion powder. Toss.","Serve over rice with sesame seeds."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs ground turkey"], Produce:["2 cups broccoli","1 zucchini","1 red bell pepper","1/2 onion","3 cloves garlic"], Grains:["2 cups brown rice"], Pantry:["Soy sauce","Sesame oil","Garlic powder","Onion powder","Olive oil","Sesame seeds","Salt & pepper"] } },
  { id:112, emoji:"🐟", title:"Citrus Glazed Cod Bowls", category:"Seafood", tags:["Low Calorie","Gluten-Free","Bright Flavor"], prep:"15 min", cook:"15 min", servings:5, calories:330, ingredients:["5 cod fillets (5 oz)","Juice of 2 oranges","Juice of 1 lemon","2 tbsp honey","1 tbsp soy sauce","1 clove garlic, minced","1 tbsp olive oil","Salt & pepper","2 cups jasmine rice","2 cups bok choy","1 cup shredded carrots","Sesame seeds","Green onions"], steps:["Whisk orange juice, lemon juice, honey, soy sauce, and garlic.","Season cod with salt and pepper.","Cook cod in olive oil 3–4 min per side.","Pour citrus glaze over cod. Simmer 2 min until glossy.","Cook jasmine rice. Sauté bok choy in sesame oil until wilted.","Bowl: rice, bok choy, cod, carrots. Drizzle extra glaze. Top with sesame seeds and green onions."], storage:"3 days refrigerated.", grocery:{ Protein:["5 cod fillets (5 oz)"], Produce:["2 oranges","1 lemon","2 cups bok choy","Shredded carrots","1 clove garlic","Green onions"], Grains:["2 cups jasmine rice"], Pantry:["Honey","Soy sauce","Olive oil","Sesame seeds","Salt & pepper"] } },
  { id:113, emoji:"🇰🇷", title:"Bibimbap-Inspired Rice Bowls", category:"Beef", tags:["High Protein","Asian-Inspired","Colorful"], prep:"25 min", cook:"20 min", servings:5, calories:470, ingredients:["1 lb ground beef (90% lean)","2 cups short-grain rice","2 cups spinach","1 cup shredded carrots","1 cup bean sprouts","1 zucchini, julienned","5 eggs","3 tbsp gochujang","2 tbsp soy sauce","1 tbsp sesame oil","1 tbsp brown sugar","2 cloves garlic, minced","Sesame seeds","Vegetable oil"], steps:["Cook rice.","Season beef with soy sauce, sesame oil, garlic, and brown sugar. Cook 7 min.","Quickly sauté each vegetable separately with a little oil and salt. Keep colorful.","Fry or soft cook eggs.","Assemble bowls: rice, arrange veggies in sections around the edge, beef in center.","Add fried egg on top. Dollop gochujang. Drizzle sesame oil.","Mix everything together before eating."], storage:"4 days. Add egg fresh.", grocery:{ Protein:["1 lb ground beef (90% lean)","5 eggs"], Produce:["2 cups spinach","Shredded carrots","Bean sprouts","1 zucchini","2 cloves garlic"], Grains:["2 cups short-grain rice"], Pantry:["Gochujang","Soy sauce","Sesame oil","Brown sugar","Vegetable oil","Sesame seeds"] } },
  { id:114, emoji:"🐔", title:"Baked Chicken Parmesan", category:"Chicken", tags:["High Protein","Italian","Comfort Food"], prep:"15 min", cook:"30 min", servings:5, calories:490, ingredients:["2 lbs chicken breast, pounded thin","1 cup Italian breadcrumbs","1/2 cup Parmesan, grated","2 eggs","2 cups marinara sauce","1 cup shredded mozzarella","1 tbsp olive oil","1 tsp garlic powder","1 tsp Italian seasoning","Salt & pepper","12 oz spaghetti","Fresh basil"], steps:["Preheat oven to 400°F.","Beat eggs. Mix breadcrumbs with Parmesan, garlic powder, Italian seasoning.","Dip chicken in egg then breadcrumb mixture.","Bake on oiled sheet pan 20 min. Flip halfway.","Top with marinara and mozzarella. Bake 10 more min.","Cook spaghetti. Serve chicken over pasta with sauce. Garnish with fresh basil."], storage:"4 days refrigerated. Reheat in oven to keep crispy.", grocery:{ Protein:["2 lbs chicken breast"], Grains:["12 oz spaghetti"], Dairy:["2 eggs","Parmesan cheese","Shredded mozzarella"], Canned:["2 cups marinara sauce"], Pantry:["Italian breadcrumbs","Olive oil","Garlic powder","Italian seasoning","Salt & pepper"] } },
  { id:115, emoji:"🥚", title:"Breakfast Taco Meal Prep", category:"Vegetarian", tags:["High Protein","Quick","Meal Prep"], prep:"10 min", cook:"15 min", servings:5, calories:340, ingredients:["12 eggs","1/2 cup milk","1 cup black beans, warmed","1 cup salsa","10 small corn or flour tortillas","1/2 cup shredded cheddar","1/4 cup diced red onion","1/4 cup cilantro","2 tbsp olive oil","Salt & pepper","1 avocado (for serving)","Hot sauce"], steps:["Whisk eggs with milk, salt, and pepper.","Scramble in olive oil over medium heat until just set.","Warm black beans with a pinch of cumin.","Warm tortillas.","Layer: eggs, black beans, cheddar, red onion, salsa.","Top with cilantro. Avocado and hot sauce to serve."], storage:"4 days. Reheat in foil. Keep avocado separate.", grocery:{ Produce:["1/4 red onion","Cilantro","1 avocado"], Dairy:["12 eggs","1/2 cup milk","Shredded cheddar"], Canned:["1 cup black beans","1 cup salsa"], Pantry:["10 small tortillas","Olive oil","Hot sauce","Salt & pepper"] } },
  { id:116, emoji:"🍗", title:"Chicken Minestrone", category:"Soups & Stews", tags:["High Protein","High Fiber","Meal Prep"], prep:"15 min", cook:"35 min", servings:5, calories:380, ingredients:["1.5 lbs chicken breast, diced","1 can white beans (15 oz)","1 can diced tomatoes","1 cup ditalini pasta","3 carrots, diced","3 stalks celery, sliced","1 zucchini, diced","1 onion, diced","3 cloves garlic, minced","5 cups chicken broth","1 tbsp olive oil","1 tsp Italian seasoning","2 cups spinach","Salt & pepper","Parmesan for serving"], steps:["Sauté onion, carrot, celery in olive oil 5 min.","Add garlic and chicken. Brown chicken 5 min.","Add tomatoes, broth, Italian seasoning, beans. Simmer 15 min.","Add zucchini and pasta. Cook 10 min.","Stir in spinach. Season.","Serve with Parmesan."], storage:"4 days. Pasta absorbs liquid — add broth when reheating.", grocery:{ Protein:["1.5 lbs chicken breast"], Produce:["3 carrots","3 stalks celery","1 zucchini","1 onion","3 cloves garlic","2 cups spinach"], Grains:["1 cup ditalini pasta"], Canned:["1 can white beans","1 can diced tomatoes"], Dairy:["Parmesan cheese"], Pantry:["Olive oil","Italian seasoning","Salt & pepper","5 cups chicken broth"] } },
  { id:117, emoji:"🔥", title:"Spicy Honey Glazed Chicken Wings", category:"Chicken", tags:["High Protein","Spicy","Snack-Meal"], prep:"10 min", cook:"45 min", servings:5, calories:410, ingredients:["3 lbs chicken wings, split","3 tbsp honey","3 tbsp hot sauce (Frank's)","1 tbsp butter, melted","1 tsp garlic powder","1 tsp onion powder","1 tsp smoked paprika","Salt & pepper","Celery sticks","Ranch dressing","Blue cheese dressing"], steps:["Preheat oven to 425°F.","Toss wings with garlic powder, onion powder, smoked paprika, salt, and pepper.","Spread in single layer on wire rack over sheet pan.","Bake 40–45 min until crispy, flipping halfway.","Mix honey, hot sauce, and butter for glaze.","Toss wings in glaze. Serve with celery and dressing."], storage:"4 days refrigerated. Re-crisp in oven at 400°F 10 min.", grocery:{ Protein:["3 lbs chicken wings"], Produce:["Celery sticks"], Dairy:["1 tbsp butter"], Pantry:["Honey","Hot sauce","Garlic powder","Onion powder","Smoked paprika","Ranch dressing","Blue cheese dressing","Salt & pepper"] } },
  { id:118, emoji:"🥙", title:"Greek Beef Gyro Plates", category:"Beef", tags:["High Protein","Mediterranean","Meal Prep"], prep:"20 min", cook:"20 min", servings:5, calories:450, ingredients:["1.5 lbs ground beef","1 tsp oregano","1 tsp garlic powder","1 tsp cumin","1/2 tsp cinnamon","Salt & pepper","2 cups couscous","1 cucumber, diced","Cherry tomatoes","1/4 red onion, sliced","1/2 cup feta cheese","1/2 cup tzatziki","Pita bread","Lemon juice","Fresh dill"], steps:["Mix beef with oregano, garlic powder, cumin, cinnamon, salt, and pepper.","Form into oval patties or skewers. Grill or broil 4–5 min per side.","Cook couscous in vegetable broth.","Prep cucumber, tomatoes, onion.","Plate: couscous, gyro meat, salad, feta.","Drizzle tzatziki and lemon juice. Garnish with dill."], storage:"4 days. Keep tzatziki separate.", grocery:{ Protein:["1.5 lbs ground beef"], Produce:["1 cucumber","Cherry tomatoes","1/4 red onion","Lemon","Fresh dill"], Grains:["2 cups couscous"], Dairy:["Feta cheese","Tzatziki"], Pantry:["Oregano","Garlic powder","Cumin","Cinnamon","Pita bread","Salt & pepper"] } },
  { id:119, emoji:"🍜", title:"Chicken Pad Thai", category:"Chicken", tags:["High Protein","Asian-Inspired","Meal Prep"], prep:"20 min", cook:"20 min", servings:5, calories:470, ingredients:["2 lbs chicken breast, sliced thin","10 oz flat rice noodles","3 tbsp fish sauce","2 tbsp soy sauce","2 tbsp brown sugar","1 tbsp oyster sauce","1 tbsp lime juice","1 tbsp vegetable oil","4 cloves garlic, minced","3 eggs","2 cups bean sprouts","4 green onions","1/2 cup crushed peanuts","Lime wedges","Cilantro","Red pepper flakes"], steps:["Soak rice noodles in warm water 20 min. Drain.","Whisk fish sauce, soy sauce, brown sugar, oyster sauce, lime juice for sauce.","Sear chicken in oil 5–6 min. Remove.","Scramble eggs in same pan. Push aside.","Add garlic 30 sec. Add noodles and sauce. Toss 2 min.","Return chicken. Add bean sprouts. Toss.","Plate with green onions, peanuts, lime, cilantro."], storage:"4 days. Noodles may stick — separate portions and reheat with water.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["4 cloves garlic","2 cups bean sprouts","4 green onions","Lime","Cilantro"], Grains:["10 oz flat rice noodles"], Dairy:["3 eggs"], Pantry:["Fish sauce","Soy sauce","Brown sugar","Oyster sauce","Vegetable oil","Crushed peanuts","Red pepper flakes"] } },
  { id:120, emoji:"🐟", title:"Mediterranean Tuna Power Bowl", category:"Seafood", tags:["High Protein","Low Calorie","Quick"], prep:"15 min", cook:"15 min", servings:5, calories:370, ingredients:["3 cans tuna in olive oil (5 oz)","2 cups farro","1 cucumber, diced","1 cup cherry tomatoes, halved","1/4 cup red onion, diced","1/2 cup Kalamata olives","1/2 cup feta cheese","3 tbsp olive oil","2 tbsp lemon juice","1 tsp dried oregano","Salt & pepper","Fresh parsley","Capers"], steps:["Cook farro per package directions. Cool slightly.","Drain tuna.","Dice cucumber, halve tomatoes, dice onion.","Whisk olive oil, lemon juice, oregano, salt, pepper for dressing.","Build bowls: farro, tuna, cucumber, tomatoes, onion, olives, feta.","Drizzle dressing. Top with parsley and capers."], storage:"4 days. Great served cold.", grocery:{ Protein:["3 cans tuna in olive oil"], Produce:["1 cucumber","Cherry tomatoes","1/4 red onion","Lemon","Fresh parsley"], Grains:["2 cups farro"], Dairy:["Feta cheese"], Pantry:["Kalamata olives","Capers","Olive oil","Dried oregano","Salt & pepper"] } },
  { id:121, emoji:"🍗", title:"Chicken & Mushroom Wild Rice Pilaf", category:"Chicken", tags:["High Protein","Comfort Food","Elegant"], prep:"15 min", cook:"45 min", servings:5, calories:440, ingredients:["2 lbs chicken breast, diced","2 cups wild rice blend","3 cups cremini mushrooms, sliced","1 onion, diced","3 cloves garlic, minced","4 cups chicken broth","2 tbsp butter","1 tbsp olive oil","1 tsp thyme","Salt & pepper","Fresh parsley","1/4 cup white wine (optional)"], steps:["Sauté onion in olive oil 4 min.","Add mushrooms. Cook until golden, 6 min.","Add garlic and thyme 1 min.","Add chicken. Sear 4 min.","Add wild rice, broth, and wine. Bring to boil.","Cover, reduce, simmer 40–45 min until rice is cooked.","Stir in butter. Season. Garnish with parsley."], storage:"5 days refrigerated.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["3 cups cremini mushrooms","1 onion","3 cloves garlic","Fresh parsley"], Grains:["2 cups wild rice blend"], Dairy:["2 tbsp butter"], Pantry:["Olive oil","Thyme","White wine","Salt & pepper","4 cups chicken broth"] } },
  { id:122, emoji:"🐷", title:"Teriyaki Pork & Veggie Stir Fry", category:"Pork", tags:["High Protein","Asian-Inspired","Quick"], prep:"15 min", cook:"20 min", servings:5, calories:430, ingredients:["1.5 lbs pork tenderloin, sliced thin","2 cups broccoli","1 cup snap peas","1 red bell pepper, sliced","1 cup carrots, sliced","3 cloves garlic, minced","1 tbsp ginger, grated","1/4 cup soy sauce","2 tbsp mirin","2 tbsp honey","1 tbsp cornstarch","1 tbsp vegetable oil","2 cups jasmine rice","Sesame seeds","Green onions"], steps:["Whisk soy sauce, mirin, honey, and cornstarch for teriyaki sauce.","Cook jasmine rice.","Stir fry pork in vegetable oil 4–5 min. Remove.","Stir fry all vegetables 4 min.","Add garlic and ginger 1 min.","Return pork. Pour sauce. Toss 1–2 min until glossy.","Serve over rice. Top with sesame seeds and green onions."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs pork tenderloin"], Produce:["2 cups broccoli","1 cup snap peas","1 red bell pepper","Carrots","3 cloves garlic","Ginger","Green onions"], Grains:["2 cups jasmine rice"], Pantry:["Soy sauce","Mirin","Honey","Cornstarch","Vegetable oil","Sesame seeds"] } },
  { id:123, emoji:"🥦", title:"Keto Chicken & Cauliflower", category:"Chicken", tags:["Low Carb","High Protein","Keto-Friendly"], prep:"15 min", cook:"30 min", servings:5, calories:380, ingredients:["2 lbs chicken thighs, boneless","1 large head cauliflower, florets","2 cups broccoli","4 cloves garlic, minced","2 tbsp olive oil","1 tsp smoked paprika","1 tsp garlic powder","1 tsp Italian seasoning","Salt & pepper","2 tbsp butter","1/4 cup Parmesan","Fresh rosemary"], steps:["Preheat oven to 425°F.","Toss cauliflower and broccoli with olive oil, garlic, smoked paprika, salt.","Season chicken with garlic powder, Italian seasoning, salt, pepper.","Place everything on sheet pan. Roast 25–30 min.","Toss hot cauliflower with butter and Parmesan.","Portion: chicken with cauliflower-broccoli medley. Garnish with rosemary."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs boneless chicken thighs"], Produce:["1 large head cauliflower","2 cups broccoli","4 cloves garlic","Fresh rosemary"], Dairy:["2 tbsp butter","Parmesan cheese"], Pantry:["Olive oil","Smoked paprika","Garlic powder","Italian seasoning","Salt & pepper"] } },
  { id:124, emoji:"🍛", title:"Coconut Curry Shrimp", category:"Seafood", tags:["High Protein","Asian-Inspired","Spicy"], prep:"10 min", cook:"20 min", servings:5, calories:410, ingredients:["1.5 lbs shrimp, peeled","2 cans coconut milk (14 oz)","2 tbsp red curry paste","1 onion, diced","3 cloves garlic, minced","1 tbsp ginger, grated","1 cup cherry tomatoes","1 cup snap peas","1 tbsp fish sauce","1 tbsp brown sugar","1 lime, juiced","Fresh basil","2 cups jasmine rice"], steps:["Cook jasmine rice.","Sauté onion in 1 tbsp coconut milk 3 min.","Add curry paste, garlic, ginger. Cook 1 min.","Add remaining coconut milk. Bring to simmer.","Add tomatoes and snap peas 3 min.","Add shrimp. Cook 3 min until pink.","Stir in fish sauce, brown sugar, lime juice.","Serve over rice. Garnish with basil."], storage:"3 days refrigerated.", grocery:{ Protein:["1.5 lbs shrimp"], Produce:["1 onion","3 cloves garlic","Ginger","Cherry tomatoes","1 cup snap peas","1 lime","Fresh basil"], Grains:["2 cups jasmine rice"], Canned:["2 cans coconut milk"], Pantry:["Red curry paste","Fish sauce","Brown sugar"] } },
  { id:125, emoji:"🥩", title:"Philly Cheesesteak Rice Bowls", category:"Beef", tags:["High Protein","Comfort Food","Crowd Pleaser"], prep:"15 min", cook:"20 min", servings:5, calories:480, ingredients:["1.5 lbs beef sirloin, shaved or thin sliced","2 cups white rice","2 bell peppers, sliced","1 large onion, sliced","1 cup mushrooms, sliced","2 tbsp butter","1 tbsp olive oil","1 cup shredded provolone or white cheddar","1 tsp garlic powder","1 tsp onion powder","Salt & pepper","1 tbsp Worcestershire sauce"], steps:["Cook white rice.","Sauté peppers, onion, and mushrooms in butter 7–8 min until soft.","Push vegetables aside. Add beef. Season with garlic powder, onion powder, Worcestershire, salt, pepper.","Cook beef 3–4 min.","Mix beef and vegetables. Top with cheese. Cover pan 1 min to melt.","Serve over rice."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs beef sirloin"], Produce:["2 bell peppers","1 large onion","1 cup mushrooms"], Grains:["2 cups white rice"], Dairy:["2 tbsp butter","Provolone or white cheddar"], Pantry:["Olive oil","Garlic powder","Onion powder","Worcestershire sauce","Salt & pepper"] } },
  { id:126, emoji:"🌮", title:"Roasted Cauliflower Tacos", category:"Vegetarian", tags:["Vegan","Low Calorie","Mexican"], prep:"15 min", cook:"25 min", servings:5, calories:310, ingredients:["2 heads cauliflower, cut into florets","2 tbsp olive oil","1 tsp cumin","1 tsp chili powder","1 tsp smoked paprika","Salt & pepper","10 corn tortillas","2 cups purple cabbage, shredded","1 avocado, sliced","1/2 cup salsa verde","1/4 cup cilantro","Juice of 2 limes","1/4 cup pepitas"], steps:["Preheat oven to 425°F.","Toss cauliflower with olive oil, cumin, chili powder, smoked paprika, salt.","Roast 20–25 min until golden and slightly charred.","Toss cabbage with lime juice and a pinch of salt.","Warm tortillas.","Build tacos: cabbage, cauliflower, avocado, salsa verde, cilantro, pepitas."], storage:"3 days components. Assemble fresh.", grocery:{ Produce:["2 heads cauliflower","2 cups purple cabbage","1 avocado","Cilantro","2 limes"], Pantry:["Olive oil","Cumin","Chili powder","Smoked paprika","10 corn tortillas","Salsa verde","Pepitas","Salt & pepper"] } },
  { id:127, emoji:"🐟", title:"Smoked Salmon Egg White Wraps", category:"Seafood", tags:["High Protein","Low Calorie","Quick"], prep:"10 min", cook:"10 min", servings:5, calories:290, ingredients:["12 oz smoked salmon","12 egg whites","5 large flour tortillas","1 cup spinach","1/2 cup cream cheese (light)","1/4 cup capers","1/4 red onion, thinly sliced","1 lemon, sliced","Fresh dill","Everything bagel seasoning","Salt & pepper"], steps:["Whisk egg whites with salt and pepper.","Cook in olive oil as thin omelets or scramble.","Spread cream cheese on tortillas.","Layer egg whites, spinach, smoked salmon, capers, red onion, lemon.","Sprinkle with dill and everything bagel seasoning.","Roll tightly. Slice in half."], storage:"3 days. Assemble fresh for best texture.", grocery:{ Protein:["12 oz smoked salmon"], Produce:["1 cup spinach","1/4 red onion","1 lemon","Fresh dill"], Dairy:["12 egg whites","Light cream cheese"], Pantry:["5 large flour tortillas","Capers","Everything bagel seasoning","Olive oil","Salt & pepper"] } },
  { id:128, emoji:"🧆", title:"Chicken Kofta Bowls", category:"Chicken", tags:["High Protein","Middle Eastern","Meal Prep"], prep:"20 min", cook:"20 min", servings:5, calories:440, ingredients:["2 lbs ground chicken","1/4 cup fresh parsley, minced","3 cloves garlic, minced","1 tsp cumin","1 tsp coriander","1 tsp smoked paprika","1/2 tsp cinnamon","Salt & pepper","2 cups couscous","1 cucumber, diced","Cherry tomatoes","1/2 cup hummus","1/4 cup tzatziki","Lemon juice","Pita bread"], steps:["Mix ground chicken with parsley, garlic, cumin, coriander, paprika, cinnamon, salt, pepper.","Form into oval kofta logs around skewers or free-form.","Grill or bake at 400°F 15–20 min, turning once.","Cook couscous in vegetable broth.","Dice cucumber, halve tomatoes.","Bowl: couscous, kofta, cucumber, tomatoes. Serve with hummus, tzatziki, and lemon."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs ground chicken"], Produce:["Fresh parsley","3 cloves garlic","1 cucumber","Cherry tomatoes","Lemon"], Grains:["2 cups couscous"], Pantry:["Cumin","Coriander","Smoked paprika","Cinnamon","Hummus","Tzatziki","Pita bread","Salt & pepper"] } },
  { id:129, emoji:"🥩", title:"Cuban Ropa Vieja Bowls", category:"Beef", tags:["High Protein","Cuban-Inspired","Meal Prep"], prep:"20 min", cook:"8 hrs", servings:5, calories:460, ingredients:["2 lbs flank steak","1 onion, sliced","1 green bell pepper, sliced","4 cloves garlic, minced","1 can diced tomatoes","1/2 cup beef broth","2 tbsp tomato paste","1 tsp cumin","1 tsp oregano","1/2 tsp smoked paprika","Salt & pepper","2 cups white rice","1/2 cup green olives","Cilantro","Lime"], steps:["Place steak in slow cooker with onion, pepper, garlic, tomatoes, broth, tomato paste, spices.","Cook on low 8 hrs or high 4 hrs.","Shred beef with forks. Stir in olives.","Cook white rice.","Serve beef over rice. Garnish with cilantro and lime."], storage:"5 days. Freezes very well.", grocery:{ Protein:["2 lbs flank steak"], Produce:["1 onion","1 green bell pepper","4 cloves garlic","Cilantro","Lime"], Grains:["2 cups white rice"], Canned:["1 can diced tomatoes","Tomato paste"], Pantry:["Beef broth","Cumin","Oregano","Smoked paprika","Green olives","Salt & pepper"] } },
  { id:130, emoji:"🍛", title:"Lightened-Up Butter Chicken", category:"Chicken", tags:["High Protein","Indian","Comfort Food"], prep:"15 min", cook:"30 min", servings:5, calories:460, ingredients:["2 lbs chicken breast, cubed","1 can lite coconut milk","1 can crushed tomatoes","1 onion, diced","4 cloves garlic, minced","1 tbsp ginger, grated","2 tbsp butter","1 tsp cumin","1 tsp garam masala","1 tsp turmeric","1 tsp paprika","1/2 tsp chili powder","Salt & pepper","2 cups basmati rice","Cilantro"], steps:["Sauté onion in butter 5 min until golden.","Add garlic and ginger 1 min.","Add all spices 1 min.","Add crushed tomatoes. Simmer 10 min.","Add coconut milk and chicken. Simmer 15–18 min.","Season. Serve over basmati rice. Garnish with cilantro."], storage:"5 days. Freezes well.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["1 onion","4 cloves garlic","Ginger","Cilantro"], Grains:["2 cups basmati rice"], Canned:["1 can lite coconut milk","1 can crushed tomatoes"], Dairy:["2 tbsp butter"], Pantry:["Cumin","Garam masala","Turmeric","Paprika","Chili powder","Salt & pepper"] } },
  { id:131, emoji:"🐟", title:"Pan-Seared Trout with Almonds", category:"Seafood", tags:["High Protein","Gluten-Free","Elegant"], prep:"10 min", cook:"15 min", servings:5, calories:400, ingredients:["5 trout fillets (5 oz)","1/3 cup slivered almonds","3 tbsp butter","2 tbsp olive oil","2 cloves garlic, minced","3 tbsp lemon juice","1 tbsp capers","Fresh parsley","Salt & pepper","2 cups wild rice blend","1 lb green beans"], steps:["Cook wild rice.","Roast green beans at 400°F with olive oil, salt, 12 min.","Season trout with salt and pepper.","Cook in olive oil skin-side down 4 min. Flip 2 min.","In same pan, toast almonds in butter 2 min.","Add garlic 30 sec. Add lemon juice and capers.","Plate trout over rice with green beans. Spoon almond butter sauce over fish. Garnish with parsley."], storage:"3 days refrigerated.", grocery:{ Protein:["5 trout fillets (5 oz)"], Produce:["2 cloves garlic","Lemon","Fresh parsley","1 lb green beans"], Grains:["2 cups wild rice blend"], Dairy:["3 tbsp butter"], Pantry:["Slivered almonds","Olive oil","Capers","Salt & pepper"] } },
  { id:132, emoji:"🍝", title:"Roasted Veggie Pasta Salad", category:"Vegetarian", tags:["Vegan","High Fiber","Mediterranean"], prep:"20 min", cook:"25 min", servings:5, calories:400, ingredients:["12 oz penne pasta","1 zucchini, diced","1 bell pepper, diced","1 cup cherry tomatoes","1 red onion, wedged","1/2 cup Kalamata olives","3 tbsp olive oil","2 tbsp red wine vinegar","1 tsp dried oregano","1 tsp garlic powder","Salt & pepper","1/2 cup feta cheese","Fresh basil"], steps:["Preheat oven to 425°F.","Toss zucchini, bell pepper, tomatoes, and onion with olive oil, garlic powder, salt.","Roast 20–25 min until slightly charred.","Cook penne. Rinse with cold water.","Whisk olive oil, red wine vinegar, oregano, salt, pepper for dressing.","Toss pasta with roasted veggies, olives, feta, dressing.","Garnish with fresh basil."], storage:"4 days. Great cold.", grocery:{ Produce:["1 zucchini","1 bell pepper","Cherry tomatoes","1 red onion","Fresh basil"], Grains:["12 oz penne pasta"], Dairy:["Feta cheese"], Pantry:["Olive oil","Red wine vinegar","Dried oregano","Garlic powder","Kalamata olives","Salt & pepper"] } },
  { id:133, emoji:"🍄", title:"Turkey & Spinach Stuffed Portobello", category:"Turkey", tags:["Low Carb","High Protein","Elegant"], prep:"15 min", cook:"25 min", servings:5, calories:340, ingredients:["10 large portobello mushrooms","1 lb ground turkey","2 cups baby spinach","1/2 onion, finely diced","3 cloves garlic, minced","1/2 cup ricotta cheese","1/4 cup Parmesan, grated","1 cup shredded mozzarella","1 tsp Italian seasoning","Salt & pepper","2 tbsp olive oil","Fresh basil"], steps:["Preheat oven to 375°F.","Remove mushroom stems and scrape gills. Brush with olive oil. Season.","Brown turkey with onion and garlic 7 min.","Add spinach until wilted.","Mix in ricotta, Parmesan, Italian seasoning, salt, and pepper.","Fill mushroom caps generously.","Top with mozzarella. Bake 20 min until bubbly.","Garnish with fresh basil."], storage:"4 days refrigerated.", grocery:{ Protein:["1 lb ground turkey"], Produce:["10 portobello mushrooms","2 cups baby spinach","1/2 onion","3 cloves garlic","Fresh basil"], Dairy:["Ricotta cheese","Parmesan cheese","Shredded mozzarella"], Pantry:["Olive oil","Italian seasoning","Salt & pepper"] } },
  { id:134, emoji:"🌾", title:"Ancient Grain Buddha Bowls", category:"Vegetarian", tags:["Vegan","High Fiber","Nutrient-Dense"], prep:"20 min", cook:"30 min", servings:5, calories:420, ingredients:["1 cup farro","1 cup quinoa","2 cups roasted chickpeas","2 cups kale, massaged","1 cup shredded purple cabbage","1 cup roasted sweet potato","1 avocado, sliced","1/4 cup tahini","3 tbsp lemon juice","2 cloves garlic, minced","1 tbsp olive oil","Salt & pepper","Pepitas","Hemp seeds"], steps:["Cook farro and quinoa separately.","Roast chickpeas at 400°F 25 min with olive oil, cumin, and salt.","Roast sweet potato at 400°F 25 min.","Massage kale with lemon juice and salt.","Blend tahini, lemon juice, garlic, 2–3 tbsp water, salt into dressing.","Arrange bowls: grains, kale, cabbage, sweet potato, chickpeas, avocado.","Drizzle tahini dressing. Top with pepitas and hemp seeds."], storage:"4 days. Keep dressing and avocado separate.", grocery:{ Produce:["2 cups kale","1 cup purple cabbage","1 cup sweet potato","1 avocado","2 cloves garlic","Lemon"], Grains:["1 cup farro","1 cup quinoa"], Canned:["2 cups chickpeas"], Pantry:["Tahini","Olive oil","Cumin","Pepitas","Hemp seeds","Salt & pepper"] } },
  { id:135, emoji:"🥩", title:"Steak & Eggs Meal Prep", category:"Beef", tags:["High Protein","Low Carb","Keto-Friendly"], prep:"10 min", cook:"20 min", servings:5, calories:450, ingredients:["1.5 lbs flank or sirloin steak","10 eggs","2 cups roasted potatoes (optional)","1 cup cherry tomatoes","2 cups spinach","2 tbsp olive oil","1 tsp garlic powder","1 tsp smoked paprika","Salt & pepper","Hot sauce","Salsa"], steps:["Season steak with garlic powder, smoked paprika, salt, and pepper.","Grill or sear 3–4 min per side for medium-rare. Rest 5 min.","Scramble or fry eggs in olive oil. Season.","Roast potatoes at 400°F 25 min (if using).","Portion: sliced steak, eggs, tomatoes, spinach.","Serve with hot sauce and salsa."], storage:"4 days refrigerated.", grocery:{ Protein:["1.5 lbs flank or sirloin steak"], Produce:["Cherry tomatoes","2 cups spinach"], Dairy:["10 eggs"], Pantry:["Olive oil","Garlic powder","Smoked paprika","Hot sauce","Salsa","Salt & pepper"] } },
  { id:136, emoji:"🍗", title:"One-Pan Ranch Chicken Bake", category:"Chicken", tags:["High Protein","Family Favorite","Easy"], prep:"10 min", cook:"35 min", servings:5, calories:430, ingredients:["2 lbs chicken breast","1 packet ranch seasoning mix","1.5 lbs baby potatoes, halved","1 lb broccoli florets","2 tbsp olive oil","Salt & pepper","Shredded cheddar (optional)","Fresh parsley"], steps:["Preheat oven to 400°F.","Toss potatoes with 1 tbsp olive oil and half the ranch seasoning.","Spread on large sheet pan. Roast 15 min.","Rub chicken with 1 tbsp olive oil and remaining ranch seasoning.","Add chicken and broccoli to pan. Roast 20–22 min more.","Optionally top chicken with cheddar last 3 min.","Garnish with parsley."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["1.5 lbs baby potatoes","1 lb broccoli","Fresh parsley"], Dairy:["Shredded cheddar (optional)"], Pantry:["Ranch seasoning mix","Olive oil","Salt & pepper"] } },
  { id:137, emoji:"🍲", title:"Cauliflower Soup with Turkey", category:"Turkey", tags:["Low Carb","High Protein","Creamy"], prep:"15 min", cook:"35 min", servings:5, calories:330, ingredients:["1 lb ground turkey","1 large head cauliflower, florets","1 onion, diced","4 cloves garlic, minced","3 cups chicken broth","1 cup 2% milk","2 tbsp olive oil","1 tsp garlic powder","Salt & pepper","1/2 cup shredded cheddar","Green onions","Turkey bacon bits"], steps:["Brown turkey in olive oil. Season with garlic powder, salt, pepper. Remove.","Sauté onion and garlic 4 min.","Add cauliflower and broth. Bring to boil. Simmer 20 min until tender.","Blend soup until smooth with immersion blender.","Stir in milk. Season.","Add turkey back. Heat through.","Serve topped with cheddar, green onions, and turkey bacon bits."], storage:"4 days. Freezes well.", grocery:{ Protein:["1 lb ground turkey"], Produce:["1 large head cauliflower","1 onion","4 cloves garlic","Green onions"], Dairy:["1 cup 2% milk","Shredded cheddar"], Pantry:["Olive oil","Garlic powder","Turkey bacon bits","Salt & pepper","3 cups chicken broth"] } },
  { id:138, emoji:"🌮", title:"Crispy Baked Chicken Tacos", category:"Chicken", tags:["High Protein","Family Favorite","Meal Prep"], prep:"15 min", cook:"30 min", servings:5, calories:420, ingredients:["2 lbs chicken breast, shredded","10 hard taco shells","1 packet taco seasoning","1/2 cup chicken broth","1 cup shredded cheddar","1 cup shredded lettuce","1 cup cherry tomatoes, diced","1/2 cup sour cream","1/2 cup salsa","1 avocado","Cilantro","Lime"], steps:["Cook chicken with taco seasoning and broth in pan 20 min. Shred with forks.","Preheat oven to 400°F.","Fill taco shells with chicken and cheddar.","Stand upright in baking dish. Bake 8–10 min until shells are crispy.","Top with lettuce, tomatoes, sour cream, salsa, avocado.","Serve with cilantro and lime."], storage:"3 days. Keep shells and toppings separate.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["Shredded lettuce","Cherry tomatoes","1 avocado","Cilantro","Lime"], Dairy:["Shredded cheddar","Sour cream"], Pantry:["10 hard taco shells","Taco seasoning","Chicken broth","Salsa"] } },
  { id:139, emoji:"🍛", title:"Beef & Sweet Potato Curry", category:"Beef", tags:["High Protein","Comfort Food","Spicy"], prep:"20 min", cook:"50 min", servings:5, calories:470, ingredients:["1.5 lbs beef chuck, cubed","2 sweet potatoes, cubed","1 can coconut milk","1 can diced tomatoes","1 onion, diced","3 cloves garlic, minced","1 tbsp ginger, grated","2 tbsp curry powder","1 tsp cumin","1 tsp turmeric","1 tbsp olive oil","Salt & pepper","2 cups basmati rice","Cilantro","Lime"], steps:["Brown beef in olive oil in batches. Remove.","Sauté onion, garlic, ginger 3 min.","Add curry powder, cumin, turmeric 1 min.","Add beef back. Add tomatoes, coconut milk.","Simmer 30 min. Add sweet potato.","Simmer 20 more min until potato is tender and beef is soft.","Cook basmati rice. Serve curry over rice. Garnish with cilantro and lime."], storage:"5 days. Freezes well.", grocery:{ Protein:["1.5 lbs beef chuck"], Produce:["2 sweet potatoes","1 onion","3 cloves garlic","Ginger","Cilantro","Lime"], Grains:["2 cups basmati rice"], Canned:["1 can coconut milk","1 can diced tomatoes"], Pantry:["Olive oil","Curry powder","Cumin","Turmeric","Salt & pepper"] } },
  { id:140, emoji:"🌾", title:"Smoked Turkey Grain Bowl", category:"Turkey", tags:["High Protein","Clean Eating","Meal Prep"], prep:"20 min", cook:"30 min", servings:5, calories:400, ingredients:["1 lb smoked turkey breast, sliced","2 cups farro","2 cups arugula","1 cup cherry tomatoes, halved","1/2 cup dried cranberries","1/2 cup pecans, toasted","1/4 cup red onion, diced","3 tbsp olive oil","2 tbsp apple cider vinegar","1 tbsp honey","1 tsp Dijon mustard","Salt & pepper","Fresh thyme"], steps:["Cook farro per package.","Whisk olive oil, apple cider vinegar, honey, Dijon, salt, pepper for dressing.","Slice smoked turkey.","Toast pecans in dry pan 3 min.","Build bowls: farro, arugula, turkey, tomatoes, onion, cranberries, pecans.","Drizzle dressing. Garnish with fresh thyme."], storage:"4 days undressed.", grocery:{ Protein:["1 lb smoked turkey breast"], Produce:["2 cups arugula","Cherry tomatoes","1/4 red onion","Fresh thyme"], Grains:["2 cups farro"], Pantry:["Dried cranberries","Pecans","Olive oil","Apple cider vinegar","Honey","Dijon mustard","Salt & pepper"] } },
  { id:141, emoji:"🍗", title:"Peruvian-Style Chicken", category:"Chicken", tags:["High Protein","Latin","Meal Prep"], prep:"20 min", cook:"40 min", servings:5, calories:440, ingredients:["2 lbs chicken thighs, bone-in","3 tbsp olive oil","2 tbsp soy sauce","1 tbsp lime juice","3 cloves garlic, minced","1 tsp cumin","1 tsp smoked paprika","1/2 tsp turmeric","1/2 tsp oregano","Salt & pepper","2 cups white rice","1 lb green beans","Aji verde: 1/4 cup mayo + 1 jalapeño + cilantro + lime"], steps:["Blend all marinade ingredients. Coat chicken. Marinate 30 min+.","Roast chicken at 425°F 35–40 min until skin is golden and 165°F.","Cook white rice.","Roast green beans with olive oil and salt 12 min.","Blend mayo, jalapeño, cilantro, and lime for aji verde sauce.","Serve chicken over rice with green beans and aji verde."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs bone-in chicken thighs"], Produce:["3 cloves garlic","1 lime","1 jalapeño","Cilantro","1 lb green beans"], Grains:["2 cups white rice"], Dairy:["Mayo"], Pantry:["Olive oil","Soy sauce","Cumin","Smoked paprika","Turmeric","Oregano","Salt & pepper"] } },
  { id:142, emoji:"🐟", title:"Herb-Crusted Halibut Bowls", category:"Seafood", tags:["High Protein","Elegant","Low Calorie"], prep:"15 min", cook:"20 min", servings:5, calories:380, ingredients:["5 halibut fillets (5 oz)","1/2 cup panko breadcrumbs","2 tbsp fresh dill","2 tbsp fresh parsley","1 tbsp lemon zest","2 tbsp olive oil","Salt & pepper","2 cups quinoa","2 cups roasted asparagus","1 cup cherry tomatoes","Lemon wedges"], steps:["Preheat oven to 400°F.","Mix panko, dill, parsley, and lemon zest.","Brush halibut with olive oil. Press herb crust on top.","Bake 12–15 min until fish flakes and crust is golden.","Cook quinoa. Roast asparagus at 400°F 12 min.","Bowl: quinoa, asparagus, halibut, tomatoes. Serve with lemon wedges."], storage:"3 days refrigerated.", grocery:{ Protein:["5 halibut fillets (5 oz)"], Produce:["Fresh dill","Fresh parsley","Lemon","1 lb asparagus","Cherry tomatoes"], Grains:["2 cups quinoa"], Pantry:["Panko breadcrumbs","Olive oil","Salt & pepper"] } },
  { id:143, emoji:"🌿", title:"Edamame Protein Bowls", category:"Vegetarian", tags:["Vegan","High Protein","Quick"], prep:"15 min", cook:"15 min", servings:5, calories:400, ingredients:["3 cups edamame, shelled","2 cups brown rice","1 cup shredded purple cabbage","1 cup shredded carrots","1 cucumber, sliced","1 avocado, sliced","3 tbsp soy sauce","2 tbsp sesame oil","1 tbsp rice vinegar","1 tbsp honey","1 tsp ginger, grated","Sesame seeds","Nori strips","Sriracha"], steps:["Cook brown rice. Cool slightly.","Whisk soy sauce, sesame oil, rice vinegar, honey, and ginger for dressing.","Prep all vegetables.","Arrange bowls: rice, edamame, cabbage, carrots, cucumber, avocado.","Drizzle dressing generously.","Top with sesame seeds, nori strips, and sriracha."], storage:"4 days. Keep dressing and avocado separate.", grocery:{ Produce:["1 cup purple cabbage","1 cup carrots","1 cucumber","1 avocado","Ginger"], Grains:["2 cups brown rice"], Pantry:["3 cups edamame","Soy sauce","Sesame oil","Rice vinegar","Honey","Sesame seeds","Nori strips","Sriracha"] } },
  { id:144, emoji:"🌴", title:"Jerk Chicken & Coconut Rice", category:"Chicken", tags:["High Protein","Caribbean","Spicy"], prep:"20 min", cook:"30 min", servings:5, calories:480, ingredients:["2 lbs chicken thighs, boneless","3 tbsp jerk seasoning","1 tbsp olive oil","2 cups jasmine rice","1 can coconut milk","1 cup water","1/2 tsp salt","1 cup black beans","1 mango, diced","1/4 cup red onion, diced","1/4 cup cilantro","Lime juice","1 jalapeño, minced"], steps:["Coat chicken in jerk seasoning and olive oil. Marinate 20 min+.","Cook jasmine rice in coconut milk, water, and salt.","Grill or bake chicken at 400°F 25–28 min until 165°F.","Make mango salsa: mango, red onion, cilantro, jalapeño, lime juice.","Warm black beans.","Plate: coconut rice, chicken, beans, mango salsa."], storage:"4 days refrigerated.", grocery:{ Protein:["2 lbs boneless chicken thighs"], Produce:["1 mango","1/4 red onion","Cilantro","Lime","1 jalapeño"], Grains:["2 cups jasmine rice"], Canned:["1 can coconut milk","1 cup black beans"], Pantry:["Jerk seasoning","Olive oil","Salt"] } },
  { id:145, emoji:"🥤", title:"High-Protein Smoothie Jars", category:"Vegetarian", tags:["High Protein","Low Calorie","Quick"], prep:"10 min", cook:"0 min", servings:5, calories:260, ingredients:["5 cups Greek yogurt (2%)","2.5 cups frozen mixed berries","5 tbsp almond butter","5 tbsp honey","5 tbsp chia seeds","5 cups spinach (raw, won't taste it)","2.5 cups almond milk","5 tsp vanilla extract","Granola for topping"], steps:["Blend 1 cup Greek yogurt, 1/2 cup berries, 1 tbsp almond butter, 1 tbsp honey, 1 tbsp chia, 1 cup spinach, 1/2 cup almond milk, 1 tsp vanilla.","Pour into mason jar.","Repeat for all 5 jars.","Seal and refrigerate.","Top with granola right before drinking or eating with a spoon."], storage:"3 days refrigerated.", grocery:{ Produce:["5 cups spinach"], Dairy:["5 cups 2% Greek yogurt"], Pantry:["Frozen mixed berries","Almond butter","Honey","Chia seeds","Almond milk","Vanilla extract","Granola"] } },
  { id:146, emoji:"🥙", title:"Chicken Souvlaki Plates", category:"Chicken", tags:["High Protein","Mediterranean","Clean Eating"], prep:"20 min", cook:"15 min", servings:5, calories:430, ingredients:["2 lbs chicken breast, cubed","3 tbsp olive oil","Juice and zest of 1 lemon","3 cloves garlic, minced","1 tbsp dried oregano","Salt & pepper","2 cups couscous","1 cucumber, diced","2 cups cherry tomatoes","1/4 red onion, sliced","1/2 cup tzatziki","Fresh dill","Pita bread (optional)"], steps:["Mix olive oil, lemon juice, zest, garlic, oregano, salt, pepper for marinade.","Marinate chicken 20 min.","Thread onto skewers. Grill 3–4 min per side until 165°F.","Cook couscous in vegetable broth.","Dice cucumber, halve tomatoes, slice onion.","Plate: couscous, souvlaki, salad. Serve with tzatziki and dill."], storage:"4 days. Keep tzatziki separate.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["1 lemon","3 cloves garlic","1 cucumber","Cherry tomatoes","1/4 red onion","Fresh dill"], Grains:["2 cups couscous"], Pantry:["Olive oil","Dried oregano","Tzatziki","Pita bread","Salt & pepper"] } },
  { id:147, emoji:"🫙", title:"Navy Bean & Ham Soup", category:"Pork", tags:["High Protein","Comfort Food","Budget-Friendly"], prep:"15 min", cook:"45 min", servings:5, calories:380, ingredients:["2 cups dried navy beans, soaked overnight","1 lb diced ham (low sodium)","1 onion, diced","3 carrots, sliced","3 stalks celery, sliced","3 cloves garlic, minced","6 cups chicken broth","1 tbsp olive oil","1 bay leaf","1 tsp thyme","Salt & pepper","Fresh parsley"], steps:["Sauté onion, carrot, celery in olive oil 5 min.","Add garlic 1 min.","Add soaked beans, ham, broth, bay leaf, and thyme.","Bring to boil. Reduce and simmer 40 min until beans are very tender.","Remove bay leaf. Use potato masher to mash some beans for creaminess.","Season. Garnish with parsley."], storage:"5 days. Freezes very well.", grocery:{ Protein:["1 lb diced ham (low sodium)"], Produce:["1 onion","3 carrots","3 stalks celery","3 cloves garlic","Fresh parsley"], Grains:["2 cups dried navy beans"], Pantry:["Olive oil","Bay leaf","Thyme","Salt & pepper","6 cups chicken broth"] } },
  { id:148, emoji:"🐟", title:"Walnut-Crusted Tilapia", category:"Seafood", tags:["High Protein","Omega-3 Rich","Low Calorie"], prep:"15 min", cook:"15 min", servings:5, calories:370, ingredients:["5 tilapia fillets (5 oz)","1/2 cup walnuts, finely chopped","2 tbsp Parmesan, grated","1 tsp garlic powder","1 tsp dried herbs (thyme + rosemary)","Salt & pepper","2 tbsp olive oil","1 egg","2 cups quinoa","1 lb asparagus","Lemon wedges"], steps:["Preheat oven to 400°F.","Mix walnuts, Parmesan, garlic powder, dried herbs, salt, and pepper.","Brush tilapia with beaten egg. Press walnut crust on top.","Place on oiled baking sheet. Drizzle with olive oil.","Bake 12–15 min until fish flakes.","Cook quinoa. Roast asparagus 12 min.","Serve tilapia over quinoa with asparagus and lemon wedges."], storage:"3 days refrigerated.", grocery:{ Protein:["5 tilapia fillets (5 oz)"], Produce:["1 lb asparagus","Lemon"], Grains:["2 cups quinoa"], Dairy:["1 egg","Parmesan cheese"], Pantry:["Walnuts","Olive oil","Garlic powder","Dried thyme","Dried rosemary","Salt & pepper"] } },
  { id:149, emoji:"🌮", title:"Loaded Chicken Nachos Meal Prep", category:"Chicken", tags:["High Protein","Family Favorite","Crowd Pleaser"], prep:"20 min", cook:"25 min", servings:5, calories:500, ingredients:["2 lbs chicken breast, shredded","1 packet taco seasoning","1/2 cup chicken broth","2 cups shredded cheddar-jack","1 can black beans, drained","1 cup corn","1/2 cup sour cream","1/2 cup guacamole","1/2 cup salsa","1/4 cup pickled jalapeños","Cilantro","Lime","Tortilla chips (packed separately)"], steps:["Cook chicken with taco seasoning and broth 20 min. Shred.","Preheat oven to 375°F.","Spread tortilla chips on sheet pan (ovenproof).","Layer chicken, beans, corn, and cheese.","Bake 8–10 min until cheese is melted.","Top with sour cream, guacamole, salsa, jalapeños.","Serve immediately with cilantro and lime."], storage:"Prep components 4 days. Assemble and bake fresh.", grocery:{ Protein:["2 lbs chicken breast"], Produce:["Cilantro","Lime"], Dairy:["Shredded cheddar-jack","Sour cream"], Canned:["1 can black beans","1 cup corn","Pickled jalapeños"], Pantry:["Taco seasoning","Chicken broth","Guacamole","Salsa","Tortilla chips"] } },
  { id:150, emoji:"🏆", title:"5-Day Performance Meal Pack", category:"Bowls", tags:["High Protein","Balanced","Athlete-Approved"], prep:"30 min", cook:"40 min", servings:5, calories:520, ingredients:["2 lbs chicken breast","1 lb salmon fillets (2 portions)","1 cup brown rice","1 cup quinoa","2 cups broccoli","1 cup sweet potato, cubed","1 cup Brussels sprouts","1 avocado","5 eggs, hard-boiled","2 tbsp olive oil","1 tsp garlic powder","1 tsp smoked paprika","Salt & pepper","Lemon","Hot sauce"], steps:["Cook rice and quinoa. Mix together.","Roast all vegetables at 425°F 25 min: broccoli, sweet potato, Brussels sprouts with olive oil and salt.","Season and bake chicken at 400°F 22 min.","Season and bake salmon at 400°F 12 min.","Hard-boil eggs: 10 min. Ice bath. Peel.","Portion evenly across 5 containers: grain mix, chicken (days 1-3), salmon (days 4-5), vegetables, half an egg.","Drizzle olive oil over all. Season. Add lemon and hot sauce."], storage:"5 days refrigerated. The ultimate performance week.", grocery:{ Protein:["2 lbs chicken breast","1 lb salmon fillets","5 eggs"], Produce:["2 cups broccoli","1 cup sweet potato","1 cup Brussels sprouts","1 avocado","Lemon"], Grains:["1 cup brown rice","1 cup quinoa"], Pantry:["Olive oil","Garlic powder","Smoked paprika","Hot sauce","Salt & pepper"] } },

];


function scaleIngredient(text, ratio) {
  if (ratio === 1) return text;
  return text.replace(/\b(\d+(?:\.\d+)?|\.\d+)(?:\s*\/\s*(\d+))?\b/g, (match, whole, denom) => {
    let val = denom ? parseFloat(whole) / parseFloat(denom) : parseFloat(whole);
    if (isNaN(val)) return match;
    val = val * ratio;
    const rounded = Math.round(val * 8) / 8;
    if (rounded === Math.round(rounded)) return String(Math.round(rounded));
    const frac = rounded % 1;
    const intPart = Math.floor(rounded);
    const fracs = [[1,8],[1,4],[3,8],[1,2],[5,8],[3,4],[7,8]];
    let best = fracs[0], bestDiff = Infinity;
    for (const [n,d] of fracs) { const diff = Math.abs(frac - n/d); if(diff < bestDiff){ bestDiff=diff; best=[n,d]; } }
    const [n,d] = best;
    if (n === d) return String(intPart + 1);
    if (intPart === 0) return n + "/" + d;
    return intPart + " " + n + "/" + d;
  });
}


// ── Ingredient parsing / merging / store-unit helpers ──────────
function formatQty(val) {
  const rounded = Math.round(val * 8) / 8;
  if (rounded === Math.round(rounded)) return String(Math.round(rounded));
  const frac = rounded % 1;
  const intPart = Math.floor(rounded);
  const fracs = [[1,8],[1,4],[3,8],[1,2],[5,8],[3,4],[7,8]];
  let best = fracs[0], bestDiff = Infinity;
  for (const [n,d] of fracs) { const diff = Math.abs(frac - n/d); if(diff < bestDiff){ bestDiff=diff; best=[n,d]; } }
  const [n,d] = best;
  if (n === d) return String(intPart + 1);
  if (intPart === 0) return n + "/" + d;
  return intPart + " " + n + "/" + d;
}

const MEASURE_UNITS = {
  tsp:0.25, teaspoon:0.25, teaspoons:0.25,
  tbsp:0.25, tablespoon:0.25, tablespoons:0.25,
  cup:0.25, cups:0.25,
  oz:0.5, ounce:0.5, ounces:0.5,
  lb:0.5, lbs:0.5, pound:0.5, pounds:0.5,
}
const COUNT_WORD_RE = /\b(clove|cloves|egg|eggs|onion|onions|potato|potatoes|lemon|lemons|lime|limes|avocado|avocados|banana|bananas|fillet|fillets|breast|breasts|thigh|thighs|chop|chops|steak|steaks|wing|wings|pepper|peppers|tortilla|tortillas|slice|slices|can|cans)\b/i

// Parse a leading quantity off an ingredient string. Returns {qty, unit, rest, matchLen} or null.
function parseLeadingQty(text) {
  const m = text.match(/^(\d+\s+\d+\/\d+|\d+\/\d+|\d+(?:\.\d+)?)(\s*)([a-zA-Z]*)/)
  if (!m) return null
  const qtyStr = m[1]
  let qty
  if (qtyStr.includes(" ")) {
    const [w, f] = qtyStr.split(" "); const [n, d] = f.split("/").map(Number)
    qty = parseInt(w) + n / d
  } else if (qtyStr.includes("/")) {
    const [n, d] = qtyStr.split("/").map(Number); qty = n / d
  } else qty = parseFloat(qtyStr)
  if (isNaN(qty)) return null
  const unit = (m[3] || "").toLowerCase()
  return { qty, unit, matchLen: m[0].length, rawUnit: m[3] || "" }
}

// Extract a normalized "core name" for merging/staples matching (aggressive: ignore unit + trailing modifiers after comma)
function coreIngredientName(text) {
  const parsed = parseLeadingQty(text)
  let rest = parsed ? text.slice(parsed.matchLen) : text
  rest = rest.trim().replace(/^,\s*/, "")
  // strip trailing modifier clauses like ", minced" / ", diced" / "(6 oz each)" for aggressive matching
  rest = rest.replace(/\([^)]*\)/g, "").split(",")[0].trim()
  return rest.toLowerCase()
}

// Round a scaled ingredient quantity to a sensible "store" purchase unit.
// Returns display text with rounded qty and, if different, the precise amount in parentheses.
function toStoreUnitDisplay(text) {
  const parsed = parseLeadingQty(text)
  if (!parsed) return text
  const { qty, unit, matchLen, rawUnit } = parsed
  const rest = text.slice(matchLen)
  const isCountable = COUNT_WORD_RE.test(unit) || COUNT_WORD_RE.test(rest.slice(0, 20))
  const increment = MEASURE_UNITS[unit]
  let rounded
  if (isCountable) rounded = Math.ceil(qty - 1e-9)
  else if (increment) rounded = Math.ceil((qty - 1e-9) / increment) * increment
  else return text
  if (Math.abs(rounded - qty) < 0.01) return text
  const roundedStr = formatQty(rounded)
  const preciseStr = formatQty(qty)
  const newLead = roundedStr + (rawUnit ? " " + rawUnit : "")
  const preciseLead = preciseStr + (rawUnit ? " " + rawUnit : "")
  return newLead + rest + " (" + preciseLead + rest + " needed)"
}

// Merge a flat list of {text} ingredient items that share a category into combined quantities by core name.
// Aggressive matching: groups by normalized core ingredient name regardless of minor wording differences.
function mergeIngredientItems(items, catName) {
  const groups = []
  const indexByName = {}
  for (const it of items) {
    const name = coreIngredientName(it.text)
    const parsed = parseLeadingQty(it.text)
    if (name && indexByName[name] !== undefined) {
      const gi = indexByName[name]
      const g = groups[gi]
      const gParsed = parseLeadingQty(g.text)
      if (parsed && gParsed && gParsed.unit === parsed.unit) {
        const newQty = gParsed.qty + parsed.qty
        const rest = g.text.slice(gParsed.matchLen)
        g.text = formatQty(newQty) + (gParsed.rawUnit ? " " + gParsed.rawUnit : "") + rest
        g.sourceKeys.push(it.key)
        g.key = "merged::" + catName + "::" + name
        g.manual = g.manual || it.manual
        continue
      } else if (!parsed && !gParsed) {
        // Neither has a quantity (e.g. "Salt & pepper") — just dedupe, keep existing display text.
        g.sourceKeys.push(it.key)
        g.key = "merged::" + catName + "::" + name
        g.manual = g.manual || it.manual
        continue
      }
    }
    const group = { key: it.key, text: it.text, manual: it.manual, sourceKeys: [it.key] }
    if (name) indexByName[name] = groups.length
    groups.push(group)
  }
  return groups
}

const CATS = [
  {id:"All",label:"All",em:""},
  {id:"Chicken",label:"Chicken",em:"🍗"},
  {id:"Beef",label:"Beef",em:"🥩"},
  {id:"Seafood",label:"Seafood",em:"🐟"},
  {id:"Vegetarian",label:"Vegetarian",em:"🌿"},
  {id:"Pork",label:"Pork",em:"🐷"},
  {id:"Turkey",label:"Turkey",em:"🦃"},
  {id:"Soups & Stews",label:"Soups",em:"🍲"},
  {id:"Salads",label:"Salads",em:"🥗"},
  {id:"Bowls",label:"Bowls",em:"🥣"},
]
const GR_CATS = ["Produce","Protein","Grains","Dairy","Canned","Pantry","Sauces","Frozen","Other"]
const PRESET_TAGS = ["High Protein","Low Calorie","Low Carb","Gluten-Free","Vegan","Vegetarian","Quick","Meal Prep","High Fiber","Comfort Food","Asian-Inspired","Mediterranean","Mexican","Italian","Spicy","Keto-Friendly"]
const BLANK = {title:"",emoji:"🍽️",category:"Chicken",tags:[],prep:"",cook:"",servings:4,calories:"",ingredients:[""],steps:[""],storage:"4 days refrigerated.",grocery:{Pantry:[]}}

const C = {
  bg:"#F2F2F7",surface:"#fff",surface2:"#F2F2F7",surface3:"#E5E5EA",
  border:"rgba(60,60,67,0.12)",sep:"rgba(60,60,67,0.08)",
  t1:"#000",t2:"#3C3C43",t3:"rgba(60,60,67,0.6)",t4:"rgba(60,60,67,0.36)",
  accent:"#2C7A4B",accentBg:"rgba(44,122,75,0.1)",accentLight:"rgba(44,122,75,0.06)",
  green:"#34C759",greenBg:"rgba(52,199,89,0.1)",
  orange:"#FF9500",orangeBg:"rgba(255,149,0,0.1)",
  red:"#FF3B30",redBg:"rgba(255,59,48,0.1)",
}

function PlantryLogo({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Pantry jar body */}
      <rect x="8" y="15" width="16" height="13" rx="3.5" fill={C.accent}/>
      {/* Jar lid */}
      <rect x="7" y="12" width="18" height="5" rx="2.5" fill={C.accent} opacity="0.75"/>
      {/* Jar shine */}
      <rect x="11" y="17" width="3" height="7" rx="1.5" fill="white" opacity="0.18"/>
      {/* Planning checkmark lines inside jar - representing a plan/list */}
      <line x1="14" y1="20" x2="19" y2="20" stroke="white" strokeWidth="1.2" strokeLinecap="round" opacity="0.55"/>
      <line x1="14" y1="23" x2="17" y2="23" stroke="white" strokeWidth="1.2" strokeLinecap="round" opacity="0.4"/>
      {/* Leaf / plant sprouting from lid - the "plan" growing into food */}
      <path d="M16 12 C16 12 16 6 21 4 C21 4 21 9.5 16 12Z" fill="#4CAF50"/>
      <path d="M16 12 C16 12 16 6 11 5 C11 5 11 10 16 12Z" fill="#66BB6A" opacity="0.9"/>
      <line x1="16" y1="12" x2="16" y2="7.5" stroke="white" strokeWidth="1" strokeLinecap="round" opacity="0.55"/>
    </svg>
  )
}

function SyncDot({ synced }) {
  return (
    <div title={synced ? "Synced" : "Syncing…"} style={{
      width: 8, height: 8, borderRadius: "50%",
      background: synced ? C.green : C.orange,
      flexShrink: 0,
      boxShadow: synced ? `0 0 0 2px ${C.greenBg}` : `0 0 0 2px ${C.orangeBg}`,
    }}/>
  )
}

export default function App() {
  // ── Local UI state ──────────────────────────────────────────
  const [tab, setTab]                     = useState("recipes")
  const [category, setCategory]           = useState("All")
  const [search, setSearch]               = useState("")
  const [sort, setSort]                   = useState("default")
  const [activeTags, setActiveTags]       = useState(new Set())
  const [showTagFilter, setShowTagFilter] = useState(false)
  const [selected, setSelected]           = useState(null)
  const [sheetTab, setSheetTab]           = useState("recipe")
  const [servings, setServings]           = useState(5)
  const [modalChecked, setModalChecked]   = useState({})
  const [showAdd, setShowAdd]             = useState(false)
  const [draft, setDraft]                 = useState(null)
  const [collapsedCats, setCollapsedCats] = useState({})
  const [toast, setToast]                 = useState(null)
  const toastRef                          = useRef(null)
  const nextId                            = useRef(Date.now())

  // ── Shared state (synced via Supabase) ──────────────────────
  const [groceryList,   setGroceryList,   grocerySynced]   = useSharedState("groceryList",   [])
  const [cookList,      setCookList,      cookSynced]       = useSharedState("cookList",      [])
  const [customRecipes, setCustomRecipes, customSynced]     = useSharedState("customRecipes", [])
  const [masterChecked, setMasterChecked, checkedSynced]    = useSharedState("checkedItems",  {})
  const [deletedItems,  setDeletedItems, deletedSynced]     = useSharedState("deletedGroceryItems", {})
  const [staples,       setStaples,      staplesSynced]     = useSharedState("staples", [])
  const [storeTaggingOn, setStoreTaggingOn, storeToggleSynced] = useSharedState("storeTaggingEnabled", false)
  const [itemStores,    setItemStores,   itemStoresSynced]   = useSharedState("itemStores", {})
  const [stores,        setStores,       storesListSynced]   = useSharedState("storeList", ["Costco","Trader Joe's"])
  const [showClearConfirm, setShowClearConfirm] = useState(false)
  const [showStaplesSheet, setShowStaplesSheet] = useState(false)
  const [newStaple, setNewStaple] = useState("")
  const [newStoreName, setNewStoreName] = useState("")
  const [storeFilter, setStoreFilter] = useState("All")
  const [swipeState, setSwipeState] = useState({})

  const allSynced = grocerySynced && cookSynced && customSynced && checkedSynced && deletedSynced && staplesSynced && storeToggleSynced && itemStoresSynced && storesListSynced

  const showToast = useCallback((msg) => {
    clearTimeout(toastRef.current)
    setToast(msg)
    toastRef.current = setTimeout(() => setToast(null), 2400)
  }, [])

  // ── Derived data ────────────────────────────────────────────
  const ALL = useMemo(() =>
    [...RECIPES, ...(customRecipes || [])].filter(r => r && r.category),
    [customRecipes]
  )

  const catCounts = useMemo(() => {
    const c = { All: ALL.length }
    ALL.forEach(r => { c[r.category] = (c[r.category] || 0) + 1 })
    return c
  }, [ALL])

  const allTags = useMemo(() => {
    const s = new Set()
    ALL.forEach(r => (r.tags || []).forEach(t => s.add(t)))
    return [...s].sort()
  }, [ALL])

  const filtered = useMemo(() => {
    let list = ALL
    if (category !== "All") list = list.filter(r => r.category === category)
    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter(r =>
        r.title.toLowerCase().includes(q) ||
        r.category.toLowerCase().includes(q) ||
        (r.tags || []).some(t => t.toLowerCase().includes(q)) ||
        (r.ingredients || []).some(i => i.toLowerCase().includes(q))
      )
    }
    if (activeTags.size > 0)
      list = list.filter(r => [...activeTags].every(t => (r.tags || []).includes(t)))
    if (sort === "cal-asc")  list = [...list].sort((a,b) => a.calories - b.calories)
    if (sort === "cal-desc") list = [...list].sort((a,b) => b.calories - a.calories)
    if (sort === "prep-asc") list = [...list].sort((a,b) => parseInt(a.prep) - parseInt(b.prep))
    if (sort === "alpha")    list = [...list].sort((a,b) => a.title.localeCompare(b.title))
    return list
  }, [ALL, category, search, sort, activeTags])

  // ── Actions ─────────────────────────────────────────────────
  function openRecipe(r) {
    if (!r) return
    setSelected(r)
    setSheetTab("recipe")
    setServings(r.servings || 5)
    setModalChecked({})
  }

  const inGrocery = selected && !!(groceryList || []).find(r => r.id === selected.id)
  const inCook    = selected && !!(cookList    || []).find(r => r.id === selected.id)

  function addToGrocery(recipe) {
    if (!recipe) return
    if (!(groceryList || []).find(r => r.id === recipe.id)) {
      const baseServings = recipe.servings || 5
      const ratio = servings / baseServings
      const scaledGrocery = {}
      Object.entries(recipe.grocery || {}).forEach(([cat, items]) => {
        scaledGrocery[cat] = items
          .map((i, idx) => ({ text: i, haveKey: "ms::" + recipe.id + "::" + cat + "::" + idx }))
          .filter(x => !modalChecked[x.haveKey])
          .map(x => scaleIngredient(x.text, ratio))
      })
      const recipeToAdd = { ...recipe, grocery: scaledGrocery, servings: servings, baseServings }
      setGroceryList(p => [...(p || []), recipeToAdd])
      showToast("Added to grocery list")
    } else {
      showToast("Already in grocery list")
    }
    setSelected(null)
  }

  function removeFromGrocery(id) {
    setGroceryList(p => (p || []).filter(r => r.id !== id))
    setMasterChecked(prev => {
      const n = { ...(prev || {}) }
      Object.keys(n).filter(k => k.startsWith("r" + id + "::")).forEach(k => delete n[k])
      return n
    })
  }

  function toggleCook(recipe) {
    if (!recipe) return
    const already = (cookList || []).find(r => r.id === recipe.id)
    if (already) {
      setCookList(p => (p || []).filter(r => r.id !== recipe.id))
      showToast("Removed from cook list")
    } else {
      setCookList(p => [...(p || []), {
        id: recipe.id, title: recipe.title, emoji: recipe.emoji || "🍽️",
        category: recipe.category, servings: recipe.servings || 5,
        calories: recipe.calories || 0, prep: recipe.prep || "",
        cook: recipe.cook || "", baseServings: recipe.servings || 5,
      }])
      showToast("Added to cook list")
    }
    setSelected(null)
  }

  function updCookSrv(id, d) {
    setCookList(p => (p || []).map(r => r.id === id ? { ...r, servings: Math.max(1, r.servings + d) } : r))
  }

  function saveRecipe(d) {
    const id = nextId.current++
    const ings = d.ingredients.filter(i => i.trim())
    const stps = d.steps.filter(s => s.trim())
    const recipe = {
      ...d, id,
      calories: parseInt(d.calories) || 0,
      servings: parseInt(d.servings) || 4,
      ingredients: ings,
      steps: stps,
      grocery: { Pantry: ings },
      custom: true,
    }
    if (d._editingId) {
      setCustomRecipes(p => (p || []).map(r => r.id === d._editingId ? {...recipe, id: d._editingId} : r))
      setSelected({...recipe, id: d._editingId})
      showToast("Recipe updated!")
    } else {
      setCustomRecipes(p => [...(p || []), recipe])
      showToast("Recipe saved!")
    }
    setShowAdd(false)
    setDraft(null)
  }

  function editRecipe(recipe) {
    setDraft({
      ...recipe,
      ingredients: recipe.ingredients.length ? recipe.ingredients : [""],
      steps: recipe.steps.length ? recipe.steps : [""],
      tags: recipe.tags || [],
      _editingId: recipe.id,
    })
    setShowAdd(true)
  }

  function deleteRecipe(id) {
    setCustomRecipes(p => (p || []).filter(r => r.id !== id))
    setGroceryList(p => (p || []).filter(r => r.id !== id))
    setCookList(p => (p || []).filter(r => r.id !== id))
    setSelected(null)
    showToast("Recipe deleted")
  }

  // ── Grocery helpers ──────────────────────────────────────────
  const [manualInput, setManualInput] = useState("")
  const [manualCat,   setManualCat]   = useState("Pantry")

  const masterGrocery = useMemo(() => {
    const rawCats = {}
    ;(groceryList || []).forEach(recipe => {
      Object.entries(recipe.grocery || {}).forEach(([cat, items]) => {
        if (!rawCats[cat]) rawCats[cat] = []
        items.forEach(item => {
          const key = "r" + recipe.id + "::" + cat + "::" + item
          if (!rawCats[cat].find(x => x.key === key) && !deletedItems[key])
            rawCats[cat].push({ key, text: item, manual: false })
        })
      })
    })
    // Manual items stored inline in groceryList with manual:true flag
    ;(groceryList || [])
      .filter(r => r._manual)
      .forEach(mi => {
        if (!rawCats[mi.category]) rawCats[mi.category] = []
        if (!deletedItems["m::" + mi.id])
          rawCats[mi.category].push({ key: "m::" + mi.id, text: mi.text, manual: true, mid: mi.id })
      })

    // Staples: exclude items whose core ingredient name matches a staple, in every category
    const stapleList = (staples || []).map(s => s.toLowerCase().trim()).filter(Boolean)
    if (stapleList.length) {
      Object.keys(rawCats).forEach(cat => {
        rawCats[cat] = rawCats[cat].filter(it => {
          const core = coreIngredientName(it.text)
          return !stapleList.some(s => core.includes(s) || s.includes(core))
        })
      })
    }

    // Aggressive merge by ingredient name within each category
    const cats = {}
    Object.entries(rawCats).forEach(([cat, items]) => {
      cats[cat] = mergeIngredientItems(items, cat)
    })
    return cats
  }, [groceryList, deletedItems, staples])

  function addManual() {
    const t = manualInput.trim()
    if (!t) return
    const item = { id: Date.now(), text: t, category: manualCat, _manual: true }
    setGroceryList(p => [...(p || []), item])
    setManualInput("")
    showToast("Added to " + manualCat)
  }

  function removeManual(mid) {
    setGroceryList(p => (p || []).filter(r => !(r._manual && r.id === mid)))
  }

  function deleteGroceryItem(item) {
    const keysToDelete = (item.sourceKeys && item.sourceKeys.length) ? item.sourceKeys : [item.key]
    setDeletedItems(p => { const n = {...p}; keysToDelete.forEach(k => { n[k] = true }); return n })
    setMasterChecked(p => { const n = {...(p||{})}; keysToDelete.forEach(k => delete n[k]); delete n[item.key]; return n })
  }

  function clearAllGrocery() {
    setGroceryList([])
    setMasterChecked({})
    setDeletedItems({})
    setShowClearConfirm(false)
    showToast("Grocery list cleared")
  }

  // ── Staples management ──────────────────────────────────────
  function addStaple() {
    const t = newStaple.trim()
    if (!t) return
    setStaples(p => (p || []).some(s => s.toLowerCase() === t.toLowerCase()) ? p : [...(p || []), t])
    setNewStaple("")
  }
  function removeStaple(s) {
    setStaples(p => (p || []).filter(x => x !== s))
  }

  // ── Store tagging management ────────────────────────────────
  function itemStoreKey(item) {
    return coreIngredientName(item.text) || item.key
  }
  function cycleItemStore(item) {
    const k = itemStoreKey(item)
    const list = stores || []
    setItemStores(p => {
      const cur = (p || {})[k]
      const idx = list.indexOf(cur)
      const next = idx === -1 ? list[0] : (idx + 1 < list.length ? list[idx + 1] : undefined)
      const n = { ...(p || {}) }
      if (next) n[k] = next; else delete n[k]
      return n
    })
  }
  function addStore() {
    const t = newStoreName.trim()
    if (!t) return
    setStores(p => (p || []).some(s => s.toLowerCase() === t.toLowerCase()) ? p : [...(p || []), t])
    setNewStoreName("")
  }
  function removeStore(s) {
    setStores(p => (p || []).filter(x => x !== s))
    setItemStores(p => {
      const n = { ...(p || {}) }
      Object.keys(n).forEach(k => { if (n[k] === s) delete n[k] })
      return n
    })
    if (storeFilter === s) setStoreFilter("All")
  }

  const displayGrocery = useMemo(() => {
    if (!storeTaggingOn || storeFilter === "All") return masterGrocery
    const out = {}
    Object.entries(masterGrocery).forEach(([cat, items]) => {
      const filtered = items.filter(it => (itemStores || {})[coreIngredientName(it.text) || it.key] === storeFilter)
      if (filtered.length) out[cat] = filtered
    })
    return out
  }, [masterGrocery, storeTaggingOn, storeFilter, itemStores])

  const totalItems   = useMemo(() => Object.values(masterGrocery).reduce((s, items) => s + items.length, 0), [masterGrocery])
  const checkedCount = useMemo(() => Object.values(masterChecked || {}).filter(Boolean).length, [masterChecked])
  const cookTotalSrv = useMemo(() => (cookList || []).reduce((s, r) => s + r.servings, 0), [cookList])
  const cookTotalCal = useMemo(() => (cookList || []).reduce((s, r) => s + Math.round((r.calories || 0) * (r.servings / (r.baseServings || 5))), 0), [cookList])

  function sc(ing) {
    if (!selected) return ing
    return scaleIngredient(ing, servings / (selected.servings || 5))
  }
  function toggleTag(t) {
    setActiveTags(p => { const n = new Set(p); n.has(t) ? n.delete(t) : n.add(t); return n })
  }

  // ── Style helpers ────────────────────────────────────────────
  const sheetStyle = {
    position:"fixed",bottom:0,left:0,right:0,maxHeight:"93vh",
    background:C.surface,borderRadius:"20px 20px 0 0",zIndex:201,
    overflow:"hidden",display:"flex",flexDirection:"column",
    boxShadow:"0 -4px 40px rgba(0,0,0,0.18)",
  }
  function actBtn(bg, col) {
    return {
      width:"100%",padding:15,borderRadius:14,border:"none",
      fontFamily:"inherit",fontSize:17,fontWeight:600,cursor:"pointer",
      display:"flex",alignItems:"center",justifyContent:"center",
      gap:8,background:bg,color:col,marginBottom:8,
    }
  }
  const handle = { width:36,height:5,borderRadius:3,background:C.surface3,margin:"8px auto 4px",flexShrink:0 }

  // ── Render ───────────────────────────────────────────────────
  const TABS = [
    { id:"recipes",  label:"Recipes",    icon:"📖" },
    { id:"cook",     label:"Cook List",  icon:"🍳" },
    { id:"grocery",  label:"Groceries",  icon:"🛒" },
  ]

  return (
    <div style={{fontFamily:"-apple-system,BlinkMacSystemFont,'SF Pro Text','Inter',sans-serif",background:C.bg,minHeight:"100vh",color:C.t1,WebkitFontSmoothing:"antialiased"}}>

      {/* ── GLOBAL HEADER ── */}
      <div style={{background:C.surface,borderBottom:"0.5px solid "+C.border,position:"sticky",top:0,zIndex:90}}>
        {/* Brand row */}
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 16px 0"}}>
          <div style={{display:"flex",alignItems:"center",gap:9}}>
            <PlantryLogo size={30}/>
            <span style={{fontSize:22,fontWeight:700,letterSpacing:-0.4,color:C.accent}}>Plantry</span>
            <SyncDot synced={allSynced}/>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:4}}>
            <button style={{background:"none",border:"none",color:C.accent,fontSize:24,fontWeight:300,cursor:"pointer",width:36,height:36,display:"flex",alignItems:"center",justifyContent:"center",borderRadius:"50%"}}
              onClick={() => { setDraft({...BLANK,tags:[],ingredients:[""],steps:[""]}); setShowAdd(true) }}>+</button>
            <select style={{background:"none",border:"none",color:C.t3,fontFamily:"inherit",fontSize:14,cursor:"pointer",outline:"none",padding:"4px 2px"}}
              value={sort} onChange={e => setSort(e.target.value)}>
              <option value="default">Sort</option>
              <option value="alpha">A → Z</option>
              <option value="cal-asc">Cal ↑</option>
              <option value="cal-desc">Cal ↓</option>
              <option value="prep-asc">Quickest</option>
            </select>
          </div>
        </div>
        {/* Tab row */}
        <div style={{display:"flex",padding:"8px 16px 10px",gap:6}}>
          {TABS.map(t => {
            const active = tab === t.id
            const badge = t.id==="cook" && (cookList||[]).length>0 ? (cookList||[]).length
                        : t.id==="grocery" && (totalItems-checkedCount)>0 ? (totalItems-checkedCount)
                        : 0
            return (
              <button key={t.id} onClick={() => setTab(t.id)} style={{
                flex:1,display:"flex",alignItems:"center",justifyContent:"center",gap:5,
                padding:"7px 4px",borderRadius:9,border:"none",fontFamily:"inherit",
                fontSize:13,fontWeight:active?600:400,cursor:"pointer",position:"relative",
                background:active?C.accentBg:"transparent",color:active?C.accent:C.t3,
                transition:"all 0.18s",
              }}>
                <span style={{fontSize:14}}>{t.icon}</span>
                {t.label}
                {badge>0 && <span style={{background:C.red,color:"#fff",fontSize:10,fontWeight:700,minWidth:16,height:16,borderRadius:50,display:"inline-flex",alignItems:"center",justifyContent:"center",padding:"0 3px"}}>{badge}</span>}
              </button>
            )
          })}
        </div>
      </div>

      {/* ── RECIPES TAB ── */}
      {tab === "recipes" && <>
        <div style={{padding:"8px 16px",background:C.surface,borderBottom:"0.5px solid "+C.border}}>
          <div style={{position:"relative",display:"flex",alignItems:"center"}}>
            <span style={{position:"absolute",left:9,color:C.t3,fontSize:13,pointerEvents:"none"}}>🔍</span>
            <input style={{width:"100%",background:C.surface2,border:"none",borderRadius:10,fontFamily:"inherit",fontSize:15,color:C.t1,padding:"7px 10px 7px 30px",outline:"none"}}
              placeholder="Search recipes or ingredients…" value={search} onChange={e => setSearch(e.target.value)}/>
          </div>
        </div>

        <div style={{background:C.surface,borderBottom:"0.5px solid "+C.border,overflowX:"auto",WebkitOverflowScrolling:"touch"}}>
          <div style={{display:"flex",padding:"10px 16px",gap:8,width:"max-content"}}>
            {CATS.map(cat => {
              const active = category === cat.id
              return (
                <button key={cat.id} onClick={() => setCategory(cat.id)} style={{
                  display:"inline-flex",alignItems:"center",gap:5,padding:"6px 14px",
                  borderRadius:50,fontSize:14,fontWeight:500,whiteSpace:"nowrap",cursor:"pointer",
                  border:"none",background:active?C.accent:C.surface2,color:active?"#fff":C.t2,minHeight:36,
                }}>
                  {cat.em && <span style={{fontSize:14}}>{cat.em}</span>}
                  {cat.label}
                  {cat.id!=="All" && <span style={{opacity:0.65,fontSize:12}}>{catCounts[cat.id]||0}</span>}
                </button>
              )
            })}
          </div>
        </div>

        <div style={{display:"flex",alignItems:"center",gap:6,padding:"8px 16px",background:C.surface,borderBottom:"0.5px solid "+C.border,flexWrap:"wrap",minHeight:44}}>
          <button style={{display:"inline-flex",alignItems:"center",gap:5,padding:"5px 12px",background:showTagFilter||activeTags.size>0?C.accentBg:"transparent",border:"none",borderRadius:50,fontFamily:"inherit",fontSize:13,fontWeight:500,color:showTagFilter||activeTags.size>0?C.accent:C.t3,cursor:"pointer"}}
            onClick={() => setShowTagFilter(v => !v)}>
            ⚙ Filter{activeTags.size>0?` · ${activeTags.size}`:""}
            <span style={{fontSize:10,opacity:0.6}}>{showTagFilter?"▲":"▼"}</span>
          </button>
          {[...activeTags].map(t => (
            <span key={t} style={{display:"inline-flex",alignItems:"center",padding:"4px 10px",background:C.accent,color:"#fff",borderRadius:50,fontSize:12,fontWeight:500,cursor:"pointer"}} onClick={() => toggleTag(t)}>{t} ✕</span>
          ))}
        </div>

        {showTagFilter && (
          <div style={{padding:"10px 16px 12px",background:C.surface,borderBottom:"0.5px solid "+C.border,display:"flex",flexWrap:"wrap",gap:8}}>
            {allTags.map(t => (
              <button key={t} style={{padding:"6px 14px",background:activeTags.has(t)?C.accent:"transparent",border:"0.5px solid "+(activeTags.has(t)?C.accent:C.border),borderRadius:50,fontFamily:"inherit",fontSize:13,fontWeight:500,color:activeTags.has(t)?"#fff":C.t2,cursor:"pointer"}}
                onClick={() => toggleTag(t)}>{t}</button>
            ))}
          </div>
        )}

        <div style={{padding:"16px 20px 8px",display:"flex",alignItems:"baseline",gap:8}}>
          <span style={{fontSize:22,fontWeight:700,letterSpacing:0.3}}>{category==="All"?"All Recipes":category}</span>
          <span style={{fontSize:17,color:C.t3}}>{filtered.length}</span>
        </div>

        {filtered.length === 0
          ? <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:"80px 32px",textAlign:"center"}}>
              <div style={{fontSize:48,marginBottom:12}}>🔍</div>
              <div style={{fontSize:20,fontWeight:600,marginBottom:8}}>No results</div>
              <div style={{fontSize:15,color:C.t3}}>Try a different search or category</div>
            </div>
          : <div style={{padding:"0 16px 80px"}}>
              {filtered.map(r => {
                const cooking = !!(cookList||[]).find(c => c.id === r.id)
                return (
                  <div key={r.id} style={{background:C.surface,borderRadius:12,border:"0.5px solid "+C.border,overflow:"hidden",marginBottom:10,cursor:"pointer",position:"relative"}} onClick={() => openRecipe(r)}>
                    {cooking && <span style={{position:"absolute",top:12,right:12,background:C.green,color:"#fff",fontSize:10,fontWeight:600,padding:"3px 9px",borderRadius:50}}>🍳 Cooking</span>}
                    {!cooking && r.custom && <span style={{position:"absolute",top:12,right:12,background:"rgba(175,82,222,0.12)",color:"#AF52DE",fontSize:10,fontWeight:600,padding:"3px 9px",borderRadius:50}}>My Recipe</span>}
                    <div style={{padding:"14px 16px 0"}}>
                      <div style={{display:"flex",gap:12,alignItems:"flex-start",marginBottom:10}}>
                        <div style={{width:52,height:52,background:C.surface2,borderRadius:12,display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,flexShrink:0}}>{r.emoji||"🍽️"}</div>
                        <div style={{flex:1,minWidth:0,paddingTop:2}}>
                          <div style={{fontSize:11,fontWeight:600,color:C.accent,textTransform:"uppercase",letterSpacing:0.5,marginBottom:2}}>{r.category}</div>
                          <div style={{fontSize:17,fontWeight:600,lineHeight:1.25}}>{r.title}</div>
                          <div style={{display:"flex",gap:5,flexWrap:"wrap",marginTop:4}}>
                            {(r.tags||[]).map(t => <span key={t} style={{fontSize:11,fontWeight:500,color:C.t3,background:C.surface2,padding:"2px 8px",borderRadius:50}}>{t}</span>)}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",borderTop:"0.5px solid "+C.sep}}>
                      {[["Prep",(r.prep||"").replace(" min","m")],["Cook",(r.cook||"").replace(/ min/g,"m").replace(/ hrs/g,"h").replace(/ hr/g,"h")],["Serves",r.servings||5],["Cal",r.calories||0]].map(([k,v],i) => (
                        <div key={k} style={{padding:"9px 0",textAlign:"center",borderRight:i<3?"0.5px solid "+C.sep:"none"}}>
                          <div style={{fontSize:14,fontWeight:600}}>{v}</div>
                          <div style={{fontSize:11,color:C.t3,marginTop:1}}>{k}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
        }
      </>}

      {/* ── COOK LIST TAB ── */}
      {tab === "cook" && <>
        {(cookList||[]).length === 0
          ? <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:"80px 32px",textAlign:"center"}}>
              <div style={{fontSize:48,marginBottom:12}}>🍳</div>
              <div style={{fontSize:20,fontWeight:600,marginBottom:8}}>Nothing cooking yet</div>
              <div style={{fontSize:15,color:C.t3,maxWidth:260}}>Browse recipes and add meals to plan your week</div>
              <button style={{marginTop:24,background:C.accent,color:"#fff",border:"none",borderRadius:14,fontFamily:"inherit",fontSize:16,fontWeight:600,padding:"13px 28px",cursor:"pointer"}} onClick={() => setTab("recipes")}>Browse Recipes</button>
            </div>
          : <>
              <div style={{background:C.orangeBg,borderRadius:14,padding:16,margin:"16px 16px 0",border:"0.5px solid rgba(255,149,0,0.25)"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                  <div style={{fontSize:12,fontWeight:600,color:C.orange,textTransform:"uppercase",letterSpacing:0.5}}>This Week</div>
                  <button style={{background:"none",border:"none",color:C.red,fontSize:12,fontWeight:500,cursor:"pointer",fontFamily:"inherit"}} onClick={() => { setCookList([]); showToast("Cook list cleared") }}>Clear all</button>
                </div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                  {[[cookList.length,"Recipes"],[cookTotalSrv,"Servings"],[cookTotalCal.toLocaleString(),"Total Cal"]].map(([v,k]) => (
                    <div key={k} style={{textAlign:"center"}}>
                      <div style={{fontSize:22,fontWeight:700}}>{v}</div>
                      <div style={{fontSize:11,color:C.t3,marginTop:2}}>{k}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div style={{padding:"12px 16px 80px"}}>
                {(cookList||[]).map(r => {
                  const full = ALL.find(x => x.id === r.id)
                  return (
                    <div key={r.id} style={{background:C.surface,borderRadius:12,border:"0.5px solid "+C.border,marginBottom:12,overflow:"hidden"}}>
                      <div style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px",cursor:"pointer"}} onClick={() => full && openRecipe(full)}>
                        <div style={{width:48,height:48,background:C.surface2,borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,flexShrink:0}}>{r.emoji||"🍽️"}</div>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{fontSize:16,fontWeight:600}}>{r.title}</div>
                          <div style={{fontSize:13,color:C.t3,marginTop:2}}>{r.prep} prep · {r.cook} cook · {Math.round((r.calories||0)*(r.servings/(r.baseServings||5)))} cal/serving</div>
                        </div>
                        <button style={{width:32,height:32,background:C.redBg,border:"none",borderRadius:"50%",color:C.red,fontSize:16,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}}
                          onClick={e => { e.stopPropagation(); setCookList(p => (p||[]).filter(x => x.id!==r.id)); showToast("Removed") }}>✕</button>
                      </div>
                      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 16px",borderTop:"0.5px solid "+C.sep,background:C.surface2}}>
                        <span style={{fontSize:13,color:C.t3}}>Servings</span>
                        <div style={{display:"flex",alignItems:"center",gap:14}}>
                          <button style={{width:32,height:32,background:C.surface3,border:"none",borderRadius:"50%",fontSize:18,color:C.accent,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}} disabled={r.servings<=1} onClick={() => updCookSrv(r.id,-1)}>−</button>
                          <span style={{fontSize:15,fontWeight:600,minWidth:24,textAlign:"center"}}>{r.servings}</span>
                          <button style={{width:32,height:32,background:C.surface3,border:"none",borderRadius:"50%",fontSize:18,color:C.accent,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}} onClick={() => updCookSrv(r.id,1)}>+</button>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </>
        }
      </>}

      {/* ── GROCERY TAB ── */}
      {tab === "grocery" && (
        <div style={{paddingBottom:80}}>
          <div style={{margin:"16px 16px 0",display:"flex",justifyContent:"flex-end"}}>
            <button style={{background:"none",border:"none",color:C.t3,fontSize:13,fontFamily:"inherit",cursor:"pointer",display:"flex",alignItems:"center",gap:4}}
              onClick={() => setShowStaplesSheet(true)}>⚙ Staples & Stores</button>
          </div>
          <div style={{margin:"6px 16px 0",background:C.surface,borderRadius:12,overflow:"hidden",border:"0.5px solid "+C.border}}>
            <div style={{padding:"12px 16px 8px",fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3}}>Add Custom Item</div>
            <div style={{display:"flex",alignItems:"stretch",borderTop:"0.5px solid "+C.sep,minHeight:50}}>
              <input style={{flex:1,background:"transparent",border:"none",fontFamily:"inherit",fontSize:16,color:C.t1,padding:"13px 16px",outline:"none"}}
                placeholder="Item name…" value={manualInput} onChange={e => setManualInput(e.target.value)} onKeyDown={e => e.key==="Enter"&&addManual()}/>
              <select style={{background:"transparent",border:"none",borderLeft:"0.5px solid "+C.sep,fontFamily:"inherit",fontSize:13,color:C.accent,padding:"0 12px",cursor:"pointer",outline:"none",minWidth:76}}
                value={manualCat} onChange={e => setManualCat(e.target.value)}>
                {GR_CATS.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <button style={{background:manualInput.trim()?C.accent:C.surface3,border:"none",color:manualInput.trim()?"#fff":C.t4,fontFamily:"inherit",fontSize:14,fontWeight:600,padding:"0 18px",cursor:manualInput.trim()?"pointer":"default",minWidth:56,display:"flex",alignItems:"center",justifyContent:"center",alignSelf:"stretch",letterSpacing:0.1}}
                onClick={addManual} disabled={!manualInput.trim()}>Add</button>
            </div>
          </div>

          {(groceryList||[]).filter(r => !r._manual).length > 0 && (
            <div style={{padding:"12px 16px 0",display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
              <span style={{fontSize:12,color:C.t3,fontWeight:500}}>From:</span>
              {(groceryList||[]).filter(r => !r._manual).map(r => (
                <div key={r.id} style={{display:"inline-flex",alignItems:"center",gap:5,background:C.accentBg,borderRadius:50,padding:"4px 10px",fontSize:13,fontWeight:500,color:C.accent}}>
                  {r.emoji||"🍽️"} {r.title.split(" ").slice(0,2).join(" ")}
                  <button style={{width:14,height:14,background:"rgba(44,122,75,0.2)",border:"none",borderRadius:"50%",color:C.accent,fontSize:10,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",padding:0}}
                    onClick={() => removeFromGrocery(r.id)}>✕</button>
                </div>
              ))}
            </div>
          )}

          {storeTaggingOn && (stores||[]).length > 0 && totalItems > 0 && (
            <div style={{padding:"12px 16px 0",display:"flex",gap:8,flexWrap:"wrap"}}>
              {["All", ...(stores||[])].map(s => (
                <button key={s} style={{padding:"5px 12px",borderRadius:50,fontFamily:"inherit",fontSize:13,fontWeight:500,border:"none",cursor:"pointer",background:storeFilter===s?C.accent:C.surface2,color:storeFilter===s?"#fff":C.t2}}
                  onClick={() => setStoreFilter(s)}>{s}</button>
              ))}
            </div>
          )}

          {totalItems === 0
            ? <div style={{display:"flex",flexDirection:"column",alignItems:"center",padding:"60px 32px",textAlign:"center"}}>
                <div style={{fontSize:48,marginBottom:12}}>🛒</div>
                <div style={{fontSize:20,fontWeight:600,marginBottom:8}}>Your list is empty</div>
                <div style={{fontSize:15,color:C.t3}}>Add recipes or type custom items above</div>
                <button style={{marginTop:24,background:C.accent,color:"#fff",border:"none",borderRadius:14,fontFamily:"inherit",fontSize:16,fontWeight:600,padding:"13px 28px",cursor:"pointer"}} onClick={() => setTab("recipes")}>Browse Recipes</button>
              </div>
            : <>
                <div style={{padding:"10px 16px 4px",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <span style={{fontSize:13,color:C.t3}}>{checkedCount}/{totalItems} checked</span>
                  <div style={{display:"flex",gap:12}}>
                    {checkedCount>0 && <button style={{background:"none",border:"none",color:C.accent,fontSize:13,cursor:"pointer",fontFamily:"inherit"}} onClick={() => setMasterChecked({})}>Uncheck all</button>}
                    <button style={{background:"none",border:"none",color:C.red,fontSize:13,cursor:"pointer",fontFamily:"inherit",fontWeight:500}} onClick={() => setShowClearConfirm(true)}>Delete all</button>
                  </div>
                </div>
                {Object.keys(displayGrocery).length === 0
                  ? <div style={{padding:"40px 32px",textAlign:"center",color:C.t3,fontSize:14}}>No items tagged for "{storeFilter}" yet. Tap an item's store chip to tag it.</div>
                  : <div style={{padding:"4px 16px 0",display:"flex",flexDirection:"column",gap:12}}>
                  {Object.entries(displayGrocery).map(([cat, items]) => {
                    const rem = items.filter(i => !(masterChecked||{})[i.key]).length
                    const pct = Math.round(((items.length-rem)/items.length)*100)
                    const open = collapsedCats[cat] !== true
                    return (
                      <div key={cat} style={{background:C.surface,borderRadius:12,overflow:"hidden",border:"0.5px solid "+C.border}}>
                        <div style={{display:"flex",alignItems:"center",gap:10,padding:"12px 16px",cursor:"pointer"}} onClick={() => setCollapsedCats(p => ({...p,[cat]:open}))}>
                          <div style={{fontSize:16,fontWeight:600,flex:1}}>{cat}</div>
                          <div style={{fontSize:13,color:rem===0?C.green:C.t3,fontWeight:rem===0?500:400}}>{rem===0?"Done":rem+" left"}</div>
                          <div style={{fontSize:14,color:C.t4,transform:open?"rotate(180deg)":"none",transition:"transform 0.25s"}}>▾</div>
                        </div>
                        <div style={{height:3,background:C.surface2}}>
                          <div style={{height:"100%",background:C.green,width:pct+"%",transition:"width 0.4s"}}/>
                        </div>
                        {open && items.map(item => {
                          const swipe = swipeState[item.key] || { dx: 0 }
                          const storeKey = itemStoreKey(item)
                          const assignedStore = (itemStores||{})[storeKey]
                          return (
                          <div key={item.key} style={{position:"relative",overflow:"hidden",borderTop:"0.5px solid "+C.sep}}>
                            <div style={{position:"absolute",inset:0,background:C.red,display:"flex",alignItems:"center",justifyContent:"flex-end",padding:"0 20px"}}>
                              <span style={{color:"#fff",fontSize:13,fontWeight:600}}>Delete</span>
                            </div>
                            <div
                              style={{display:"flex",alignItems:"center",gap:10,padding:"11px 16px",background:C.surface,transform:"translateX("+swipe.dx+"px)",transition:swipe.dragging?"none":"transform 0.2s"}}
                              onTouchStart={e => { const x = e.touches[0].clientX; setSwipeState(p => ({...p, [item.key]: {startX:x, dx:0, dragging:true}})) }}
                              onTouchMove={e => {
                                const s = swipeState[item.key]; if (!s) return
                                const dx = Math.max(-90, Math.min(0, e.touches[0].clientX - s.startX))
                                setSwipeState(p => ({...p, [item.key]: {...s, dx}}))
                              }}
                              onTouchEnd={() => {
                                const s = swipeState[item.key]
                                if (s && s.dx < -60) { deleteGroceryItem(item); return }
                                setSwipeState(p => ({...p, [item.key]: {dx:0, dragging:false}}))
                              }}
                            >
                              <div style={{width:22,height:22,borderRadius:"50%",border:(masterChecked||{})[item.key]?"none":"1.5px solid rgba(60,60,67,0.22)",background:(masterChecked||{})[item.key]?C.green:"none",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:12,color:"#fff",cursor:"pointer"}}
                                onClick={() => setMasterChecked(p => ({...(p||{}),[item.key]:!(p||{})[item.key]}))}>
                                {(masterChecked||{})[item.key]?"✓":""}
                              </div>
                              <div style={{fontSize:15,flex:1,textDecoration:(masterChecked||{})[item.key]?"line-through":"none",opacity:(masterChecked||{})[item.key]?0.42:1,cursor:"pointer"}}
                                onClick={() => setMasterChecked(p => ({...(p||{}),[item.key]:!(p||{})[item.key]}))}>
                                {toStoreUnitDisplay(item.text)}
                                {item.manual && <span style={{marginLeft:6,fontSize:10,fontWeight:600,color:C.orange,background:C.orangeBg,padding:"2px 6px",borderRadius:4}}>Custom</span>}
                              </div>
                              {storeTaggingOn && (
                                <button style={{fontSize:11,fontWeight:600,color:assignedStore?C.accent:C.t4,background:assignedStore?C.accentBg:C.surface2,border:"none",borderRadius:8,padding:"5px 8px",cursor:"pointer",flexShrink:0,whiteSpace:"nowrap"}}
                                  onClick={e => { e.stopPropagation(); cycleItemStore(item) }}>{assignedStore || "+ Store"}</button>
                              )}
                              <button style={{width:30,height:30,background:C.redBg,border:"none",borderRadius:"50%",color:C.red,fontSize:14,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",flexShrink:0}}
                                onClick={e => { e.stopPropagation(); deleteGroceryItem(item) }}>✕</button>
                            </div>
                          </div>
                          )
                        })}
                      </div>
                    )
                  })}
                </div>}
              </>
          }
        </div>
      )}

      {/* ── STAPLES & STORES SETTINGS SHEET ── */}
      {showStaplesSheet && (
        <>
          <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.4)",zIndex:200,backdropFilter:"blur(2px)"}} onClick={() => setShowStaplesSheet(false)}/>
          <div style={sheetStyle}>
            <div style={handle}/>
            <div style={{padding:"8px 16px 14px",borderBottom:"0.5px solid "+C.sep,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
              <div style={{fontSize:20,fontWeight:700}}>Staples & Stores</div>
              <button style={{width:32,height:32,background:C.surface2,border:"none",borderRadius:"50%",fontSize:16,color:C.t3,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}} onClick={() => setShowStaplesSheet(false)}>✕</button>
            </div>
            <div style={{overflowY:"auto",flex:1,padding:"16px 20px 32px"}}>
              <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:8}}>Always-Have Staples</div>
              <div style={{fontSize:13,color:C.t3,marginBottom:12,lineHeight:1.5}}>Items you always have on hand — they'll never show up in your grocery list, no matter which recipes call for them.</div>
              <div style={{display:"flex",gap:8,marginBottom:12}}>
                <input style={{flex:1,background:C.surface2,border:"none",borderRadius:10,fontFamily:"inherit",fontSize:15,color:C.t1,padding:"11px 14px",outline:"none"}}
                  placeholder="e.g. Olive oil, Garlic, Salt & pepper" value={newStaple} onChange={e => setNewStaple(e.target.value)} onKeyDown={e => e.key==="Enter"&&addStaple()}/>
                <button style={{background:C.accent,color:"#fff",border:"none",borderRadius:10,fontFamily:"inherit",fontSize:14,fontWeight:600,padding:"0 18px",cursor:"pointer"}} onClick={addStaple}>Add</button>
              </div>
              <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:28}}>
                {(staples||[]).length===0 && <div style={{fontSize:13,color:C.t4}}>No staples yet.</div>}
                {(staples||[]).map(s => (
                  <div key={s} style={{display:"inline-flex",alignItems:"center",gap:6,background:C.accentBg,color:C.accent,borderRadius:50,padding:"6px 10px",fontSize:13,fontWeight:500}}>
                    {s}
                    <button style={{width:16,height:16,background:"rgba(44,122,75,0.2)",border:"none",borderRadius:"50%",color:C.accent,fontSize:10,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",padding:0}} onClick={() => removeStaple(s)}>✕</button>
                  </div>
                ))}
              </div>

              <div style={{height:1,background:C.sep,margin:"8px 0 20px"}}/>

              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8}}>
                <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3}}>Tag Items By Store</div>
                <div onClick={() => setStoreTaggingOn(v => !v)} style={{width:44,height:26,borderRadius:50,background:storeTaggingOn?C.accent:C.surface3,position:"relative",cursor:"pointer",transition:"background 0.2s"}}>
                  <div style={{position:"absolute",top:2,left:storeTaggingOn?20:2,width:22,height:22,borderRadius:"50%",background:"#fff",transition:"left 0.2s",boxShadow:"0 1px 3px rgba(0,0,0,0.2)"}}/>
                </div>
              </div>
              <div style={{fontSize:13,color:C.t3,marginBottom:12,lineHeight:1.5}}>When on, you can tag grocery items with which store to buy them from, and filter your list by store. This setting is shared with your fiancée.</div>

              {storeTaggingOn && <>
                <div style={{display:"flex",gap:8,marginBottom:12}}>
                  <input style={{flex:1,background:C.surface2,border:"none",borderRadius:10,fontFamily:"inherit",fontSize:15,color:C.t1,padding:"11px 14px",outline:"none"}}
                    placeholder="e.g. Costco" value={newStoreName} onChange={e => setNewStoreName(e.target.value)} onKeyDown={e => e.key==="Enter"&&addStore()}/>
                  <button style={{background:C.accent,color:"#fff",border:"none",borderRadius:10,fontFamily:"inherit",fontSize:14,fontWeight:600,padding:"0 18px",cursor:"pointer"}} onClick={addStore}>Add</button>
                </div>
                <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
                  {(stores||[]).length===0 && <div style={{fontSize:13,color:C.t4}}>No stores yet.</div>}
                  {(stores||[]).map(s => (
                    <div key={s} style={{display:"inline-flex",alignItems:"center",gap:6,background:C.surface2,color:C.t1,borderRadius:50,padding:"6px 10px",fontSize:13,fontWeight:500}}>
                      {s}
                      <button style={{width:16,height:16,background:C.surface3,border:"none",borderRadius:"50%",color:C.t2,fontSize:10,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",padding:0}} onClick={() => removeStore(s)}>✕</button>
                    </div>
                  ))}
                </div>
              </>}
            </div>
          </div>
        </>
      )}

      {/* ── CLEAR ALL CONFIRM DIALOG ── */}
      {showClearConfirm && (
        <>
          <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",zIndex:300,backdropFilter:"blur(4px)"}} onClick={() => setShowClearConfirm(false)}/>
          <div style={{position:"fixed",left:"50%",top:"50%",transform:"translate(-50%,-50%)",zIndex:301,background:C.surface,borderRadius:20,padding:"28px 24px",width:"min(320px, calc(100vw - 48px))",boxShadow:"0 20px 60px rgba(0,0,0,0.25)"}}>
            <div style={{fontSize:40,textAlign:"center",marginBottom:12}}>🗑️</div>
            <div style={{fontSize:18,fontWeight:700,textAlign:"center",marginBottom:8}}>Delete Grocery List?</div>
            <div style={{fontSize:14,color:C.t3,textAlign:"center",marginBottom:24,lineHeight:1.5}}>This will remove all items and recipes from your grocery list. This cannot be undone.</div>
            <button style={{width:"100%",padding:"14px",borderRadius:12,border:"none",background:C.red,color:"#fff",fontFamily:"inherit",fontSize:16,fontWeight:600,cursor:"pointer",marginBottom:10}} onClick={clearAllGrocery}>Delete Everything</button>
            <button style={{width:"100%",padding:"14px",borderRadius:12,border:"none",background:C.surface2,color:C.t1,fontFamily:"inherit",fontSize:16,fontWeight:600,cursor:"pointer"}} onClick={() => setShowClearConfirm(false)}>Cancel</button>
          </div>
        </>
      )}

      {/* ── RECIPE SHEET ── */}
      {selected && <>
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.4)",zIndex:200,backdropFilter:"blur(2px)"}} onClick={() => setSelected(null)}/>
        <div style={sheetStyle}>
          <div style={handle}/>
          <div style={{padding:"8px 16px 14px",borderBottom:"0.5px solid "+C.sep,flexShrink:0,display:"flex",gap:14,alignItems:"flex-start"}}>
            <div style={{width:64,height:64,background:C.surface2,borderRadius:14,display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,flexShrink:0}}>{selected.emoji||"🍽️"}</div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:11,fontWeight:600,color:C.accent,textTransform:"uppercase",letterSpacing:0.5,marginBottom:3}}>{selected.category}</div>
              <div style={{fontSize:20,fontWeight:700,lineHeight:1.2,marginBottom:6}}>{selected.title}</div>
              <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                {(selected.tags||[]).map(t => <span key={t} style={{fontSize:11,fontWeight:500,color:C.t3,background:C.surface2,padding:"2px 8px",borderRadius:50}}>{t}</span>)}
              </div>
            </div>
            <button style={{width:32,height:32,background:C.surface2,border:"none",borderRadius:"50%",fontSize:16,color:C.t3,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",flexShrink:0}} onClick={() => setSelected(null)}>✕</button>
          </div>
          <div style={{display:"flex",background:C.surface2,borderBottom:"0.5px solid "+C.sep,flexShrink:0}}>
            {[["PREP",selected.prep||""],["COOK",selected.cook||""],["CAL",selected.calories||0],["STORE",(selected.storage||"").split(".")[0]]].map(([k,v]) => (
              <div key={k} style={{flex:1,padding:"10px 8px",textAlign:"center",borderRight:"0.5px solid "+C.border}}>
                <div style={{fontSize:14,fontWeight:600}}>{v}</div>
                <div style={{fontSize:11,color:C.t3,marginTop:1}}>{k}</div>
              </div>
            ))}
          </div>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 20px",borderBottom:"0.5px solid "+C.sep,background:C.surface,flexShrink:0}}>
            <div>
              <div style={{fontSize:15,fontWeight:500}}>Servings</div>
              {servings!==(selected.servings||5) && <div style={{fontSize:12,color:C.t3,marginTop:2}}>Scaled from {selected.servings||5}</div>}
            </div>
            <div style={{display:"flex",alignItems:"center",background:C.surface2,borderRadius:10,overflow:"hidden"}}>
              <button style={{width:44,height:38,background:"none",border:"none",fontSize:22,fontWeight:300,color:C.accent,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}} disabled={servings<=1} onClick={() => setServings(s => Math.max(1,s-1))}>−</button>
              <div style={{minWidth:50,textAlign:"center",fontSize:16,fontWeight:600,borderLeft:"0.5px solid "+C.sep,borderRight:"0.5px solid "+C.sep,height:38,display:"flex",alignItems:"center",justifyContent:"center"}}>{servings}</div>
              <button style={{width:44,height:38,background:"none",border:"none",fontSize:22,fontWeight:300,color:C.accent,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}} onClick={() => setServings(s => s+1)}>+</button>
            </div>
          </div>
          <div style={{display:"flex",background:C.surface,borderBottom:"0.5px solid "+C.sep,padding:"0 20px",flexShrink:0}}>
            {["recipe","grocery"].map(t => (
              <button key={t} style={{flex:1,padding:"10px 0",fontSize:13,fontWeight:500,color:sheetTab===t?C.accent:C.t3,background:"none",border:"none",fontFamily:"inherit",cursor:"pointer",borderBottom:sheetTab===t?"2px solid "+C.accent:"2px solid transparent"}}
                onClick={() => setSheetTab(t)}>{t==="recipe"?"Recipe":"Grocery List"}</button>
            ))}
          </div>
          <div style={{overflowY:"auto",WebkitOverflowScrolling:"touch",flex:1,paddingBottom:16}}>
            {sheetTab==="recipe" && <>
              <div style={{padding:"16px 20px 0"}}>
                <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:8}}>
                  Ingredients{servings!==(selected.servings||5)&&<span style={{color:C.accent,fontWeight:600,marginLeft:8}}>({servings} servings)</span>}
                </div>
                <div style={{background:C.surface,borderRadius:12,overflow:"hidden",border:"0.5px solid "+C.border}}>
                  {(selected.ingredients||[]).map((ing,i) => (
                    <div key={i} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 16px",borderBottom:i<(selected.ingredients||[]).length-1?"0.5px solid "+C.sep:"none",fontSize:15}}>
                      <div style={{width:6,height:6,borderRadius:"50%",background:C.accent,flexShrink:0}}/>
                      {sc(ing)}
                    </div>
                  ))}
                </div>
              </div>
              <div style={{padding:"16px 20px 0",marginTop:4}}>
                <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:8}}>Instructions</div>
                <div style={{display:"flex",flexDirection:"column",gap:8}}>
                  {(selected.steps||[]).map((step,i) => (
                    <div key={i} style={{display:"flex",gap:14,padding:"14px 16px",background:C.surface,borderRadius:12,border:"0.5px solid "+C.border}}>
                      <div style={{width:26,height:26,background:C.accent,color:"#fff",borderRadius:"50%",fontSize:13,fontWeight:600,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1}}>{i+1}</div>
                      <div style={{fontSize:15,color:C.t2,lineHeight:1.55,flex:1}}>{step}</div>
                    </div>
                  ))}
                </div>
              </div>
              {selected.storage && (
                <div style={{padding:"16px 20px 8px"}}>
                  <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:8}}>Storage</div>
                  <div style={{background:C.greenBg,borderRadius:12,padding:"14px 16px",border:"0.5px solid rgba(52,199,89,0.25)",display:"flex",gap:10,alignItems:"flex-start"}}>
                    <span style={{fontSize:16}}>📦</span>
                    <div style={{fontSize:14,color:C.t2,lineHeight:1.5}}>{selected.storage}</div>
                  </div>
                </div>
              )}
            </>}
            {sheetTab==="grocery" && (
              <div style={{padding:"16px 20px"}}>
                <div style={{fontSize:13,color:C.t3,marginBottom:14,lineHeight:1.5}}>Check off anything you already have — checked items won't be added to your grocery list.</div>
                {Object.entries(selected.grocery||{}).map(([cat,items]) => (
                  <div key={cat} style={{marginBottom:16}}>
                    <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:6,paddingLeft:4}}>{cat}</div>
                    <div style={{background:C.surface,borderRadius:12,overflow:"hidden",border:"0.5px solid "+C.border}}>
                      {items.map((item,i) => {
                        const key = "ms::"+selected.id+"::"+cat+"::"+i
                        return (
                          <div key={i} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 16px",borderTop:i>0?"0.5px solid "+C.sep:"none",cursor:"pointer",opacity:modalChecked[key]?0.42:1}}
                            onClick={() => setModalChecked(p => ({...p,[key]:!p[key]}))}>
                            <div style={{width:22,height:22,borderRadius:"50%",border:modalChecked[key]?"none":"1.5px solid rgba(60,60,67,0.22)",background:modalChecked[key]?C.green:"none",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:12,color:"#fff"}}>{modalChecked[key]?"✓":""}</div>
                            <div style={{fontSize:15,textDecoration:modalChecked[key]?"line-through":"none"}}>{sc(item)}</div>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div style={{padding:"10px 16px 12px",borderTop:"0.5px solid "+C.sep,flexShrink:0,background:C.surface}}>
            <div style={{display:"flex",gap:8,marginBottom:selected.custom?8:0}}>
              <button style={{flex:1,padding:"11px 8px",borderRadius:12,border:"none",fontFamily:"inherit",fontSize:14,fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:5,background:inCook?C.red:C.orange,color:"#fff"}} onClick={() => selected&&toggleCook(selected)}>
                {inCook?"✕ Remove":"🍳 Cook List"}
              </button>
              <button style={{flex:1,padding:"11px 8px",borderRadius:12,border:"none",fontFamily:"inherit",fontSize:14,fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:5,background:inGrocery?C.green:"#3DA35D",color:"#fff"}} onClick={() => !inGrocery&&selected&&addToGrocery(selected)}>
                {inGrocery?"✓ In List":"🛒 Grocery List"}
              </button>
            </div>
            {selected.custom && (
              <div style={{display:"flex",gap:8}}>
                <button style={{...actBtn(C.surface2,C.accent),flex:1,marginBottom:0}} onClick={() => editRecipe(selected)}>✏️ Edit</button>
                <button style={{...actBtn(C.redBg,C.red),flex:1,marginBottom:0}} onClick={() => selected&&deleteRecipe(selected.id)}>🗑 Delete</button>
              </div>
            )}
          </div>
        </div>
      </>}

      {/* ── ADD RECIPE SHEET ── */}
      {showAdd && draft && <>
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.4)",zIndex:200,backdropFilter:"blur(2px)"}} onClick={() => setShowAdd(false)}/>
        <div style={sheetStyle}>
          <div style={handle}/>
          <div style={{padding:"8px 16px 14px",borderBottom:"0.5px solid "+C.sep,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
            <div style={{fontSize:20,fontWeight:700}}>{draft._editingId ? "Edit Recipe" : "New Recipe"}</div>
            <button style={{width:32,height:32,background:C.surface2,border:"none",borderRadius:"50%",fontSize:16,color:C.t3,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}} onClick={() => setShowAdd(false)}>✕</button>
          </div>
          <div style={{overflowY:"auto",flex:1}}>
            {[["Emoji","emoji","🍽️","text",{maxWidth:64,textAlign:"center",fontSize:24}],["Recipe Name ✱","title","e.g. Garlic Butter Pasta","text",{}]].map(([lbl,field,ph,type,extra]) => (
              <div key={field} style={{padding:"12px 20px",borderBottom:"0.5px solid "+C.sep}}>
                <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:6}}>{lbl}</div>
                <input style={{background:C.surface2,border:"none",borderRadius:10,fontFamily:"inherit",fontSize:16,color:C.t1,padding:"11px 14px",outline:"none",width:"100%",...extra}}
                  type={type} value={draft[field]} onChange={e => setDraft(d => ({...d,[field]:e.target.value}))} placeholder={ph}/>
              </div>
            ))}
            <div style={{padding:"12px 20px",borderBottom:"0.5px solid "+C.sep}}>
              <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:6}}>Category</div>
              <select style={{background:C.surface2,border:"none",borderRadius:10,fontFamily:"inherit",fontSize:16,color:C.t1,padding:"11px 14px",outline:"none",width:"100%"}}
                value={draft.category} onChange={e => setDraft(d => ({...d,category:e.target.value}))}>
                {CATS.filter(c => c.id!=="All").map(c => <option key={c.id} value={c.id}>{c.label||c.id}</option>)}
              </select>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,padding:"12px 20px",borderBottom:"0.5px solid "+C.sep}}>
              {[["Prep","prep","15 min","text"],["Cook","cook","25 min","text"],["Serves","servings","4","number"],["Cal","calories","400","number"]].map(([lbl,field,ph,type]) => (
                <div key={field}>
                  <div style={{fontSize:11,fontWeight:600,textTransform:"uppercase",letterSpacing:0.4,color:C.t3,marginBottom:4}}>{lbl}</div>
                  <input style={{background:C.surface2,border:"none",borderRadius:8,fontFamily:"inherit",fontSize:15,color:C.t1,padding:"9px 10px",outline:"none",width:"100%",textAlign:"center"}}
                    type={type} value={draft[field]} onChange={e => setDraft(d => ({...d,[field]:e.target.value}))} placeholder={ph}/>
                </div>
              ))}
            </div>
            <div style={{padding:"12px 20px",borderBottom:"0.5px solid "+C.sep}}>
              <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:8}}>Tags</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
                {PRESET_TAGS.map(t => (
                  <button key={t} style={{padding:"6px 12px",background:draft.tags.includes(t)?C.accent:"transparent",border:"0.5px solid "+(draft.tags.includes(t)?C.accent:C.border),borderRadius:50,fontFamily:"inherit",fontSize:13,fontWeight:500,color:draft.tags.includes(t)?"#fff":C.t2,cursor:"pointer"}}
                    onClick={() => setDraft(d => ({...d,tags:d.tags.includes(t)?d.tags.filter(x=>x!==t):[...d.tags,t]}))}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <div style={{padding:"12px 20px",borderBottom:"0.5px solid "+C.sep}}>
              <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:8}}>Ingredients ✱</div>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {draft.ingredients.map((ing,i) => (
                  <div key={i} style={{display:"flex",alignItems:"center",gap:8}}>
                    <input style={{background:C.surface2,border:"none",borderRadius:10,fontFamily:"inherit",fontSize:16,color:C.t1,padding:"11px 14px",outline:"none",flex:1}}
                      value={ing} onChange={e => { const a=[...draft.ingredients]; a[i]=e.target.value; setDraft(d=>({...d,ingredients:a})) }} placeholder={"Ingredient "+(i+1)}/>
                    {draft.ingredients.length>1 && <button style={{width:32,height:44,background:C.redBg,border:"none",borderRadius:8,color:C.red,fontSize:18,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontWeight:300}}
                      onClick={() => setDraft(d => ({...d,ingredients:d.ingredients.filter((_,j)=>j!==i)}))}>-</button>}
                  </div>
                ))}
              </div>
              <button style={{background:"none",border:"none",color:C.accent,fontFamily:"inherit",fontSize:15,fontWeight:500,cursor:"pointer",padding:"8px 0"}}
                onClick={() => setDraft(d => ({...d,ingredients:[...d.ingredients,""]}))}>+ Add Ingredient</button>
            </div>
            <div style={{padding:"12px 20px",borderBottom:"0.5px solid "+C.sep}}>
              <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:8}}>Instructions ✱</div>
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {draft.steps.map((step,i) => (
                  <div key={i} style={{display:"flex",gap:8,alignItems:"flex-start"}}>
                    <div style={{width:26,height:26,background:C.accent,color:"#fff",borderRadius:"50%",fontSize:13,fontWeight:600,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:11}}>{i+1}</div>
                    <textarea style={{background:C.surface2,border:"none",borderRadius:10,fontFamily:"inherit",fontSize:15,color:C.t1,padding:"11px 14px",outline:"none",resize:"none",flex:1}}
                      value={step} rows={2} onChange={e => { const a=[...draft.steps]; a[i]=e.target.value; setDraft(d=>({...d,steps:a})) }} placeholder={"Step "+(i+1)}/>
                    {draft.steps.length>1 && <button style={{width:32,height:44,background:C.redBg,border:"none",borderRadius:8,color:C.red,fontSize:18,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",fontWeight:300,marginTop:2}}
                      onClick={() => setDraft(d => ({...d,steps:d.steps.filter((_,j)=>j!==i)}))}>-</button>}
                  </div>
                ))}
              </div>
              <button style={{background:"none",border:"none",color:C.accent,fontFamily:"inherit",fontSize:15,fontWeight:500,cursor:"pointer",padding:"8px 0"}}
                onClick={() => setDraft(d => ({...d,steps:[...d.steps,""]}))}>+ Add Step</button>
            </div>
            <div style={{padding:"12px 20px 24px"}}>
              <div style={{fontSize:12,fontWeight:600,textTransform:"uppercase",letterSpacing:0.5,color:C.t3,marginBottom:6}}>Storage Note</div>
              <input style={{background:C.surface2,border:"none",borderRadius:10,fontFamily:"inherit",fontSize:16,color:C.t1,padding:"11px 14px",outline:"none",width:"100%"}}
                value={draft.storage} onChange={e => setDraft(d => ({...d,storage:e.target.value}))} placeholder="e.g. 4 days refrigerated."/>
            </div>
          </div>
          <div style={{padding:"12px 20px 16px",borderTop:"0.5px solid "+C.sep,flexShrink:0,background:C.surface}}>
            <button style={{...actBtn(C.accent,"#fff"),opacity:(!draft.title.trim()||!draft.ingredients.some(i=>i.trim())||!draft.steps.some(s=>s.trim()))?0.4:1}}
              disabled={!draft.title.trim()||!draft.ingredients.some(i=>i.trim())||!draft.steps.some(s=>s.trim())}
              onClick={() => saveRecipe(draft)}>Save Recipe</button>
            <button style={actBtn(C.surface2,C.t1)} onClick={() => setShowAdd(false)}>Cancel</button>
          </div>
        </div>
      </>}

      {/* Toast */}
      {toast && <div style={{position:"fixed",bottom:24,left:"50%",transform:"translateX(-50%)",background:"rgba(30,30,30,0.92)",color:"#fff",fontSize:14,fontWeight:500,padding:"10px 18px",borderRadius:50,zIndex:999,whiteSpace:"nowrap"}}>{toast}</div>}

      <style>{`
        * { -webkit-tap-highlight-color: transparent; box-sizing: border-box; }
        body { margin: 0; overscroll-behavior: none; }
        input, textarea, select { -webkit-appearance: none; }
        button:active { opacity: 0.75; }
        ::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  )
}