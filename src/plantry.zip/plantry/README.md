# 🌿 Plantry — Shared Meal Prep App

A real-time shared meal-planning and grocery list app for you and your partner.

## Setup

1. Go to [supabase.com](https://supabase.com) and create a free account
2. Click **New Project** — pick a name like "plantry", choose a region, set a password
3. Wait ~2 minutes for it to spin up
4. Go to the **SQL Editor** (left sidebar) and run this query to create the shared data table:

```sql
create table plantry_shared (
  id text primary key,
  payload jsonb,
  updated_at timestamptz default now()
);

alter table plantry_shared enable row level security;

create policy "Public read" on plantry_shared
  for select using (true);

create policy "Public write" on plantry_shared
  for all using (true);

alter publication supabase_realtime add table plantry_shared;
```

5. Go to **Settings → API** and copy:
   - **Project URL** (looks like `https://abcdefgh.supabase.co`)
   - **anon public key** (long string starting with `eyJ...`)
6. Create a `.env` file in this project (copy `.env.example`) and paste in those two values
7. Deploy to Vercel, adding the same two values as Environment Variables

## What syncs in real time

| Action | Result |
|---|---|
| Add recipe to grocery list | ✅ Both see it instantly |
| Check off a grocery item | ✅ Both see the checkmark |
| Delete a grocery item | ✅ Gone for both, permanently |
| Add to cook list | ✅ Both see it |
| Adjust servings in cook list | ✅ Synced |
| Create a custom recipe | ✅ Both can see and use it |
| Edit or delete a custom recipe | ✅ Synced for both |
| Browse / search / filter | Local only (no need to sync) |

The small green dot in the header shows sync status.

## Folder structure

```
plantry/
├── index.html          # HTML entry point
├── vite.config.js      # Vite config
├── package.json
├── .env                # ← YOU CREATE THIS (your Supabase keys)
├── public/
│   └── icon.svg         # App icon
└── src/
    ├── main.jsx          # React entry
    ├── App.jsx            # Full app (all UI + recipes)
    ├── supabase.js         # Supabase client setup
    └── useSharedState.js   # Real-time sync hook
```
